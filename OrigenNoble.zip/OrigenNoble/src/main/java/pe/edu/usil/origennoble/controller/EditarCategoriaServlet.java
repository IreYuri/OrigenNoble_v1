
package pe.edu.usil.origennoble.controller;

import pe.edu.usil.origennoble.model.Categoria;
import pe.edu.usil.origennoble.repository.CategoriaRepository;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/editarCategoriaServlet")
public class EditarCategoriaServlet extends HttpServlet {

    private final CategoriaRepository categoriaRepository =
            new CategoriaRepository();

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null ||
                session.getAttribute("usuarioId") == null) {
            response.sendRedirect(
                    request.getContextPath() + "/login.jsp");
            return;
        }

        try {
            String idTexto = request.getParameter("id");

            if (idTexto == null || idTexto.trim().isEmpty()) {
                response.sendRedirect(
                        request.getContextPath()
                        + "/categoriasServlet");
                return;
            }

            int id = Integer.parseInt(idTexto);
            Categoria categoria = categoriaRepository.buscarPorId(id);

            if (categoria == null) {
                response.sendRedirect(
                        request.getContextPath()
                        + "/categoriasServlet?error=noEncontrada");
                return;
            }

            request.setAttribute("categoria", categoria);

            request.getRequestDispatcher(
                    "/editarCategoria.jsp").forward(request, response);

        } catch (NumberFormatException e) {
            response.sendRedirect(
                    request.getContextPath() + "/categoriasServlet");
        } catch (Exception e) {
            throw new ServletException(
                    "Error al consultar la categoría.", e);
        }
    }
}
