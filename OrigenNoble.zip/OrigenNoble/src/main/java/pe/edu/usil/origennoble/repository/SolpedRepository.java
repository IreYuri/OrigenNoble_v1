
package pe.edu.usil.origennoble.repository;

import pe.edu.usil.origennoble.config.ConexionBD;
import pe.edu.usil.origennoble.model.DetalleSolped;
import pe.edu.usil.origennoble.model.Solped;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class SolpedRepository {

    public boolean registrarSolped(Solped solped) throws SQLException {

        if (solped == null
                || solped.getDetalles() == null
                || solped.getDetalles().isEmpty()) {
            throw new IllegalArgumentException(
                    "La solicitud debe contener al menos un producto.");
        }

        String sqlSolped =
                "INSERT INTO solped "
                + "(cliente_id, usuario_id, observaciones, estado) "
                + "VALUES (?, ?, ?, 'registrada')";

        String sqlDetalle =
                "INSERT INTO detalle_solped "
                + "(solped_id, producto_id, cantidad, precio_referencial) "
                + "SELECT ?, p.producto_id, ?, p.precio_venta "
                + "FROM productos p "
                + "WHERE p.producto_id = ? "
                + "AND p.estado = 'activo'";

        try (Connection con = ConexionBD.getConnection()) {

            con.setAutoCommit(false);

            try {
                int solpedId;

                try (PreparedStatement ps = con.prepareStatement(
                        sqlSolped, Statement.RETURN_GENERATED_KEYS)) {

                    if (solped.getClienteId() == null) {
                        ps.setNull(1, Types.INTEGER);
                    } else {
                        ps.setInt(1, solped.getClienteId());
                    }

                    ps.setInt(2, solped.getUsuarioId());
                    ps.setString(3, solped.getObservaciones());

                    ps.executeUpdate();

                    try (ResultSet rs = ps.getGeneratedKeys()) {
                        if (!rs.next()) {
                            throw new SQLException(
                                    "No se pudo obtener el ID de la solicitud.");
                        }

                        solpedId = rs.getInt(1);
                    }
                }

                for (DetalleSolped detalle : solped.getDetalles()) {

                    if (detalle == null
                            || detalle.getProductoId() <= 0
                            || detalle.getCantidad() <= 0) {
                        throw new IllegalArgumentException(
                                "Selecciona productos y cantidades válidas.");
                    }

                    try (PreparedStatement ps =
                            con.prepareStatement(sqlDetalle)) {

                        ps.setInt(1, solpedId);
                        ps.setInt(2, detalle.getCantidad());
                        ps.setInt(3, detalle.getProductoId());

                        int filas = ps.executeUpdate();

                        if (filas != 1) {
                            throw new SQLException(
                                    "El producto ID "
                                    + detalle.getProductoId()
                                    + " no existe o está inactivo.");
                        }
                    }
                }

                con.commit();

                solped.setSolpedId(solpedId);
                solped.setEstado("registrada");

                return true;

            } catch (SQLException | RuntimeException e) {

                try {
                    con.rollback();
                } catch (SQLException rollbackError) {
                    e.addSuppressed(rollbackError);
                }

                throw e;

            } finally {
                try {
                    con.setAutoCommit(true);
                } catch (SQLException ignored) {
                    // La conexión se cerrará al finalizar el bloque.
                }
            }
        }
    }

    public List<Solped> listarSolped() throws SQLException {

        List<Solped> solicitudes = new ArrayList<>();

        String sql =
                "SELECT s.solped_id, s.cliente_id, s.usuario_id, "
                + "s.fecha_solicitud, s.observaciones, s.estado, "
                + "CASE "
                + "WHEN c.cliente_id IS NULL THEN 'Sin cliente' "
                + "WHEN c.razon_social IS NOT NULL "
                + "AND TRIM(c.razon_social) <> '' "
                + "THEN c.razon_social "
                + "ELSE TRIM(COALESCE(c.nombres, '') || ' ' "
                + "|| COALESCE(c.apellidos, '')) "
                + "END AS nombre_cliente, "
                + "u.nombre_usuario "
                + "FROM solped s "
                + "LEFT JOIN clientes c ON s.cliente_id = c.cliente_id "
                + "INNER JOIN usuarios u ON s.usuario_id = u.usuario_id "
                + "ORDER BY s.solped_id DESC";

        try (Connection con = ConexionBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                Solped solped = new Solped();

                solped.setSolpedId(rs.getInt("solped_id"));

                int clienteId = rs.getInt("cliente_id");

                if (rs.wasNull()) {
                    solped.setClienteId(null);
                } else {
                    solped.setClienteId(clienteId);
                }

                solped.setUsuarioId(rs.getInt("usuario_id"));
                solped.setFechaSolicitud(
                        rs.getTimestamp("fecha_solicitud"));
                solped.setObservaciones(
                        rs.getString("observaciones"));
                solped.setEstado(rs.getString("estado"));
                solped.setNombreCliente(
                        rs.getString("nombre_cliente"));
                solped.setNombreUsuario(
                        rs.getString("nombre_usuario"));

                solicitudes.add(solped);
            }
        }

        return solicitudes;
    }

    public List<DetalleSolped> listarDetalles(int solpedId)
            throws SQLException {

        List<DetalleSolped> detalles = new ArrayList<>();

        String sql =
                "SELECT d.detalle_solped_id, d.solped_id, "
                + "d.producto_id, p.nombre AS nombre_producto, "
                + "d.cantidad, d.precio_referencial "
                + "FROM detalle_solped d "
                + "INNER JOIN productos p "
                + "ON d.producto_id = p.producto_id "
                + "WHERE d.solped_id = ? "
                + "ORDER BY d.detalle_solped_id";

        try (Connection con = ConexionBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, solpedId);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {

                    DetalleSolped detalle = new DetalleSolped();

                    detalle.setDetalleSolpedId(
                            rs.getInt("detalle_solped_id"));
                    detalle.setSolpedId(rs.getInt("solped_id"));
                    detalle.setProductoId(rs.getInt("producto_id"));
                    detalle.setNombreProducto(
                            rs.getString("nombre_producto"));
                    detalle.setCantidad(rs.getInt("cantidad"));
                    detalle.setPrecioReferencial(
                            rs.getBigDecimal("precio_referencial"));

                    detalles.add(detalle);
                }
            }
        }

        return detalles;
    }
}
