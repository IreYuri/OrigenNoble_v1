
package pe.edu.usil.origennoble.controller;

import pe.edu.usil.origennoble.model.Cliente;
import pe.edu.usil.origennoble.repository.ClienteRepository;
import pe.edu.usil.origennoble.repository.UsuarioRepository;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;

@WebServlet(name = "RegistroClienteServlet", urlPatterns = {"/registroClienteServlet"})
public class RegistroClienteServlet extends HttpServlet {

    private final ClienteRepository clienteRepository = new ClienteRepository();
    private final UsuarioRepository usuarioRepository = new UsuarioRepository();


    private boolean esAdministrador(HttpServletRequest request,
                                    HttpServletResponse response)
            throws IOException {

        HttpSession session = request.getSession(false);

        if (session == null) {
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return false;
        }

        Object id = session.getAttribute("usuarioId");

        if (!(id instanceof Number)) {
            session.invalidate();
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return false;
        }

        int usuarioId = ((Number) id).intValue();

        try {
            if (!usuarioRepository.esAdministrador(usuarioId)) {
                response.sendError(
                    HttpServletResponse.SC_FORBIDDEN,
                    "No tienes permisos para registrar clientes."
                );
                return false;
            }

            return true;

        } catch (SQLException e) {
            getServletContext().log(
                "Error al verificar los permisos del usuario.", e
            );

            response.sendError(
                HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                "No se pudieron verificar los permisos."
            );

            return false;
        }
    }


    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        if (!esAdministrador(request, response)) {
            return;
        }

        request.getRequestDispatcher("/registroCliente.jsp")
               .forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        if (!esAdministrador(request, response)) {
            return;
        }

        Cliente cliente = new Cliente();

        cliente.setTipoDocumento(limpiar(request.getParameter("tipoDocumento")));
        cliente.setNumeroDocumento(limpiar(request.getParameter("numeroDocumento")));
        cliente.setNombres(limpiar(request.getParameter("nombres")));
        cliente.setApellidos(limpiar(request.getParameter("apellidos")));
        cliente.setRazonSocial(limpiar(request.getParameter("razonSocial")));
        cliente.setTelefono(limpiar(request.getParameter("telefono")));
        cliente.setEmail(limpiar(request.getParameter("email")));
        cliente.setDireccion(limpiar(request.getParameter("direccion")));

        try {
            clienteRepository.registrarCliente(cliente);

            response.sendRedirect(request.getContextPath()
                    + "/clientesServlet?mensaje=registrado");

        } catch (SQLException e) {
            if ("23505".equals(e.getSQLState())) {
                response.sendRedirect(request.getContextPath()
                        + "/registroClienteServlet?error=duplicado");
            } else if ("22001".equals(e.getSQLState())
                    || "23514".equals(e.getSQLState())
                    || "22003".equals(e.getSQLState())) {
                response.sendRedirect(request.getContextPath()
                        + "/registroClienteServlet?error=datos");
            } else {
                getServletContext().log(
                        "Error al registrar un cliente en OrigenNoble.", e);
                response.sendRedirect(request.getContextPath()
                        + "/registroClienteServlet?error=general");
            }
        }
    }

    private String limpiar(String valor) {
        if (valor == null) {
            return null;
        }

        valor = valor.trim();
        return valor.isEmpty() ? null : valor;
    }
}
