
package pe.edu.usil.origennoble.controller;

import pe.edu.usil.origennoble.repository.CategoriaRepository;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/cambiarEstadoCategoriaServlet")
public class CambiarEstadoCategoriaServlet extends HttpServlet {

    private final CategoriaRepository categoriaRepository =
            new CategoriaRepository();

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null ||
                session.getAttribute("usuarioId") == null) {
            response.sendRedirect(
                    request.getContextPath() + "/login.jsp");
            return;
        }

        String idTexto = request.getParameter("categoriaId");
        String estado = request.getParameter("estado");

        try {
            if (idTexto == null ||
                    (!"activo".equals(estado) &&
                     !"inactivo".equals(estado))) {

                response.sendRedirect(
                        request.getContextPath()
                        + "/categoriasServlet?error=estado");
                return;
            }

            int categoriaId = Integer.parseInt(idTexto);

            boolean cambiado =
                    categoriaRepository.cambiarEstadoCategoria(
                            categoriaId, estado);

            if (cambiado) {
                response.sendRedirect(
                        request.getContextPath()
                        + "/categoriasServlet?exito=estado");
            } else {
                response.sendRedirect(
                        request.getContextPath()
                        + "/categoriasServlet?error=estado");
            }

        } catch (NumberFormatException e) {
            response.sendRedirect(
                    request.getContextPath()
                    + "/categoriasServlet?error=estado");
        } catch (Exception e) {
            throw new ServletException(
                    "Error al cambiar el estado de la categoría.", e);
        }
    }
}
