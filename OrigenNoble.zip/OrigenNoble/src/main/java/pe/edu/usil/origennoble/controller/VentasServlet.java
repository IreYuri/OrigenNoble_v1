
package pe.edu.usil.origennoble.controller;

import pe.edu.usil.origennoble.model.DetalleVenta;
import pe.edu.usil.origennoble.model.Producto;
import pe.edu.usil.origennoble.model.Venta;
import pe.edu.usil.origennoble.repository.ProductoRepository;
import pe.edu.usil.origennoble.repository.VentaRepository;
import pe.edu.usil.origennoble.config.ConexionBD;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet(name = "VentasServlet", urlPatterns = {"/ventasServlet"})
public class VentasServlet extends HttpServlet {

    private final ProductoRepository productoRepository =
            new ProductoRepository();

    private final VentaRepository ventaRepository =
            new VentaRepository();

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("usuarioId") == null) {
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return;
        }

        try {
            cargarDatos(request);
            request.getRequestDispatcher("/ventas.jsp")
                    .forward(request, response);

        } catch (SQLException e) {
            throw new ServletException(
                    "Error al cargar el módulo de ventas.", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("usuarioId") == null) {
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return;
        }

        try {
            int usuarioId = Integer.parseInt(
                    session.getAttribute("usuarioId").toString());

            String clienteTexto = request.getParameter("clienteId");
            Integer clienteId = null;

            if (clienteTexto != null && !clienteTexto.isBlank()) {
                clienteId = Integer.parseInt(clienteTexto);
            }

            String[] productosIds =
                    request.getParameterValues("productoId");
            String[] cantidades =
                    request.getParameterValues("cantidad");

            if (productosIds == null || cantidades == null
                    || productosIds.length != cantidades.length) {
                throw new IllegalArgumentException(
                        "Selecciona al menos un producto y su cantidad.");
            }

            Venta venta = new Venta();
            venta.setUsuarioId(usuarioId);
            venta.setClienteId(clienteId);

            List<DetalleVenta> detalles = new ArrayList<>();

            for (int i = 0; i < productosIds.length; i++) {
                if (productosIds[i] == null
                        || productosIds[i].isBlank()
                        || cantidades[i] == null
                        || cantidades[i].isBlank()) {
                    continue;
                }

                int productoId = Integer.parseInt(productosIds[i]);
                int cantidad = Integer.parseInt(cantidades[i]);

                if (productoId <= 0 || cantidad <= 0) {
                    throw new IllegalArgumentException(
                            "Los productos y las cantidades deben ser válidos.");
                }

                DetalleVenta detalle = new DetalleVenta();
                detalle.setProductoId(productoId);
                detalle.setCantidad(cantidad);
                detalles.add(detalle);
            }

            if (detalles.isEmpty()) {
                throw new IllegalArgumentException(
                        "Agrega al menos un producto a la venta.");
            }

            venta.setDetalles(detalles);
            ventaRepository.registrarVenta(venta);

            response.sendRedirect(
                    request.getContextPath()
                    + "/ventasServlet?mensaje=exito");
            return;

        } catch (IllegalArgumentException e) {
            request.setAttribute("error", e.getMessage());

        } catch (SQLException e) {
            request.setAttribute("error",
                    "No se pudo registrar la venta: " + e.getMessage());
        }

        try {
            cargarDatos(request);
            request.getRequestDispatcher("/ventas.jsp")
                    .forward(request, response);

        } catch (SQLException e) {
            throw new ServletException(
                    "Error al recuperar los datos de ventas.", e);
        }
    }

    private void cargarDatos(HttpServletRequest request)
            throws SQLException {

        List<Producto> productos = productoRepository.listarProductos();
        List<Venta> ventas = ventaRepository.listarVentas();
        List<Map<String, Object>> clientes = new ArrayList<>();

        String sql = """
            SELECT cliente_id, nombres, apellidos
            FROM clientes
            ORDER BY nombres, apellidos
            """;

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Map<String, Object> cliente = new HashMap<>();
                cliente.put("clienteId", rs.getInt("cliente_id"));
                cliente.put("nombre",
                        rs.getString("nombres") + " "
                        + rs.getString("apellidos"));
                clientes.add(cliente);
            }
        }

        request.setAttribute("productos", productos);
        request.setAttribute("ventas", ventas);
        request.setAttribute("clientes", clientes);
    }
}
