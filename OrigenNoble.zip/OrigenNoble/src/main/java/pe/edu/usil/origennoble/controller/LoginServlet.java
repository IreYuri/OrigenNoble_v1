
package pe.edu.usil.origennoble.controller;

import pe.edu.usil.origennoble.model.Usuario;
import pe.edu.usil.origennoble.service.AuthService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;

@WebServlet(name = "LoginServlet", urlPatterns = {"/loginServlet"})
public class LoginServlet extends HttpServlet {

    private AuthService authService;

    @Override
    public void init() throws ServletException {
        authService = new AuthService();
    }

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        response.sendRedirect(
                request.getContextPath() + "/index.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String nombreUsuario = request.getParameter("usuario");
        String password = request.getParameter("password");

        try {
            Usuario usuario =
                    authService.autenticar(nombreUsuario, password);

            if (usuario != null) {
                HttpSession sesion = request.getSession(true);

                // Evitar reutilizar una sesión previa al autenticarse.
                request.changeSessionId();

                sesion.setAttribute(
                        "usuarioId", usuario.getUsuarioId());
                sesion.setAttribute(
                        "nombreUsuario", usuario.getNombreUsuario());

                response.sendRedirect(
                        request.getContextPath() + "/dashboard.jsp");

            } else {
                response.sendRedirect(
                        request.getContextPath()
                        + "/index.jsp?error=invalid");
            }

        } catch (SQLException e) {
            log("Error al procesar el inicio de sesión.", e);

            response.sendRedirect(
                    request.getContextPath()
                    + "/index.jsp?error=server");
        }
    }

    @Override
    public String getServletInfo() {
        return "Servlet de autenticación de OrigenNoble";
    }
}
