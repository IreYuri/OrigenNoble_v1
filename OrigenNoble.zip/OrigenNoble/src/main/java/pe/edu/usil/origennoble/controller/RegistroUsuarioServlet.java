/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.usil.origennoble.controller;

/**
 *
 * @author snay-
 */

import pe.edu.usil.origennoble.service.AuthService;
import pe.edu.usil.origennoble.config.ConexionBD;
import pe.edu.usil.origennoble.repository.UsuarioRepository;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet(name = "RegistroUsuarioServlet",
            urlPatterns = {"/registroUsuarioServlet"})
public class RegistroUsuarioServlet extends HttpServlet {

    private AuthService authService;
    private UsuarioRepository usuarioRepository;

    @Override
    public void init() throws ServletException {
        authService = new AuthService();
        usuarioRepository = new UsuarioRepository();
    }

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        if (!esAdmin(request, response)) {
            return;
        }

        try {
            String sql = """
                SELECT rol_id, nombre_rol
                FROM roles
                WHERE estado = 'activo'
                ORDER BY nombre_rol
                """;

            try (Connection conexion = ConexionBD.obtenerConexion();
                 PreparedStatement ps = conexion.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {

                java.util.List<java.util.Map<String, Object>> roles =
                        new java.util.ArrayList<>();

                while (rs.next()) {
                    java.util.Map<String, Object> rol =
                            new java.util.HashMap<>();
                    rol.put("id", rs.getInt("rol_id"));
                    rol.put("nombre", rs.getString("nombre_rol"));
                    roles.add(rol);
                }

                request.setAttribute("roles", roles);
            }

            request.getRequestDispatcher("/registroUsuario.jsp")
                   .forward(request, response);

        } catch (SQLException e) {
            log("Error al consultar los roles.", e);
            response.sendError(500, "No se pudieron cargar los roles.");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        if (!esAdmin(request, response)) {
            return;
        }

        String nombre = request.getParameter("nombreUsuario");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String rolTexto = request.getParameter("rolId");

        try {
            int rolId = Integer.parseInt(rolTexto);

            authService.registrarUsuario(nombre, email, password, rolId);

            response.sendRedirect(
                request.getContextPath()
                + "/usuariosServlet?registro=exitoso");

        } catch (IllegalArgumentException e) {
            response.sendRedirect(
                request.getContextPath()
                + "/registroUsuarioServlet?error=datos");

        } catch (SQLException e) {
            log("Error al registrar el usuario.", e);

            // SQLState 23505: restricción única incumplida en PostgreSQL.
            if ("23505".equals(e.getSQLState())) {
                response.sendRedirect(
                    request.getContextPath()
                    + "/registroUsuarioServlet?error=duplicado");
            } else {
                response.sendRedirect(
                    request.getContextPath()
                    + "/registroUsuarioServlet?error=servidor");
            }
        }
    }

    private boolean sesionValida(HttpServletRequest request,
                                 HttpServletResponse response)
            throws IOException {

        HttpSession sesion = request.getSession(false);

        if (sesion == null || sesion.getAttribute("usuarioId") == null) {
            response.sendRedirect(
                request.getContextPath() + "/index.jsp");
            return false;
        }

        return true;
    }
    
    private boolean esAdmin(HttpServletRequest request,
                        HttpServletResponse response)
            throws IOException {

        HttpSession sesion = request.getSession(false);

        if (sesion == null ||
            !(sesion.getAttribute("usuarioId") instanceof Number)) {
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return false;
        }

        int usuarioId = ((Number) sesion.getAttribute("usuarioId")).intValue();

        try {
            if (!usuarioRepository.esAdministrador(usuarioId)) {
                response.sendError(
                    HttpServletResponse.SC_FORBIDDEN,
                    "No tienes permisos para registrar usuarios."
                );
                return false;
            }

            return true;

        } catch (SQLException e) {
            log("Error al verificar permisos de administrador.", e);
            response.sendError(
                HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                "No se pudieron verificar los permisos."
            );
            return false;
        }
    }
}
