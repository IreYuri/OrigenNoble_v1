/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.usil.origennoble.controller;

/**
 *
 * @author snay-
 */

import pe.edu.usil.origennoble.model.Usuario;
import pe.edu.usil.origennoble.repository.UsuarioRepository;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet(name = "UsuariosServlet", urlPatterns = {"/usuariosServlet"})
public class UsuariosServlet extends HttpServlet {

    private UsuarioRepository usuarioRepository;

    @Override
    public void init() throws ServletException {
        usuarioRepository = new UsuarioRepository();
    }

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession sesion = request.getSession(false);

        // 1. Verificar que exista una sesión iniciada.
        if (sesion == null || sesion.getAttribute("usuarioId") == null) {
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return;
        }

        // 2. Obtener el identificador del usuario de la sesión.
        Object idSesion = sesion.getAttribute("usuarioId");

        if (!(idSesion instanceof Number)) {
            sesion.invalidate();
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return;
        }

        int usuarioId = ((Number) idSesion).intValue();

        try {
            // 3. Verificar que el usuario tenga el rol Administrador activo.
            if (!usuarioRepository.esAdministrador(usuarioId)) {
                response.sendError(
                        HttpServletResponse.SC_FORBIDDEN,
                        "No tienes permisos para acceder al módulo de usuarios."
                );
                return;
            }

            // 4. Si es administrador, consultar y mostrar los usuarios.
            List<Usuario> usuarios = usuarioRepository.listarUsuarios();

            request.setAttribute("usuarios", usuarios);

            request.getRequestDispatcher("/usuarios.jsp")
                   .forward(request, response);

        } catch (SQLException e) {
            log("Error al verificar permisos o consultar los usuarios.", e);

            response.sendError(
                    HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "No se pudo procesar la solicitud."
            );
        }
    }
}
