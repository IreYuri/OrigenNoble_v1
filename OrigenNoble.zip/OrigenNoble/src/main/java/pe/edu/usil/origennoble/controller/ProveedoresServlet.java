
package pe.edu.usil.origennoble.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import pe.edu.usil.origennoble.model.Proveedor;
import pe.edu.usil.origennoble.repository.ProveedorRepository;

@WebServlet(name = "ProveedoresServlet", urlPatterns = {"/proveedoresServlet"})
public class ProveedoresServlet extends HttpServlet {

    private final ProveedorRepository proveedorRepository =
            new ProveedorRepository();

    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        if (!sesionValida(request)) {
            response.sendRedirect(
                    request.getContextPath() + "/index.jsp");
            return;
        }

        String busqueda = request.getParameter("busqueda");
        String editar = request.getParameter("editar");

        try {
            // Cargar proveedor seleccionado para editar.
            if (editar != null && !editar.trim().isEmpty()) {
                int proveedorId = Integer.parseInt(editar);
                Proveedor proveedor =
                        proveedorRepository.buscarPorId(proveedorId);

                if (proveedor == null) {
                    response.sendRedirect(
                            request.getContextPath()
                            + "/proveedoresServlet?error=noEncontrado");
                    return;
                }

                request.setAttribute("proveedorEditar", proveedor);
            }

            List<Proveedor> proveedores;

            if (busqueda != null && !busqueda.trim().isEmpty()) {
                proveedores =
                        proveedorRepository.buscarProveedores(busqueda.trim());
            } else {
                proveedores = proveedorRepository.listarProveedores();
            }

            request.setAttribute("proveedores", proveedores);
            request.setAttribute("busqueda",
                    busqueda == null ? "" : busqueda.trim());

            request.getRequestDispatcher("/proveedores.jsp")
                    .forward(request, response);

        } catch (NumberFormatException ex) {
            response.sendRedirect(
                    request.getContextPath()
                    + "/proveedoresServlet?error=idInvalido");

        } catch (SQLException ex) {
            getServletContext().log(
                    "Error al consultar los proveedores", ex);

            response.sendRedirect(
                    request.getContextPath()
                    + "/proveedoresServlet?error=general");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        if (!sesionValida(request)) {
            response.sendRedirect(
                    request.getContextPath() + "/index.jsp");
            return;
        }

        String accion = request.getParameter("accion");

        try {
            if ("actualizarProveedor".equals(accion)) {

                int proveedorId = Integer.parseInt(
                        request.getParameter("proveedorId"));

                Proveedor proveedor = obtenerProveedorFormulario(
                        request, proveedorId);

                boolean actualizado =
                        proveedorRepository.actualizarProveedor(proveedor);

                redirigirResultado(response, request,
                        actualizado ? "actualizado" : "sinCambios");

            } else if ("cambiarEstado".equals(accion)) {

                int proveedorId = Integer.parseInt(
                        request.getParameter("proveedorId"));

                String nuevoEstado =
                        request.getParameter("nuevoEstado");

                boolean cambiado =
                        proveedorRepository.cambiarEstadoProveedor(
                                proveedorId, nuevoEstado);

                redirigirResultado(response, request,
                        cambiado ? "estadoActualizado" : "sinCambios");

            } else {
                response.sendRedirect(
                        request.getContextPath()
                        + "/proveedoresServlet?error=accionInvalida");
            }

        } catch (NumberFormatException ex) {
            response.sendRedirect(
                    request.getContextPath()
                    + "/proveedoresServlet?error=datosInvalidos");

        } catch (IllegalArgumentException ex) {
            response.sendRedirect(
                    request.getContextPath()
                    + "/proveedoresServlet?error=datosInvalidos");

        } catch (SQLException ex) {
            getServletContext().log(
                    "Error al procesar la operación de proveedor", ex);

            response.sendRedirect(
                    request.getContextPath()
                    + "/proveedoresServlet?error=general");
        }
    }

    private Proveedor obtenerProveedorFormulario(
            HttpServletRequest request, int proveedorId) {

        if (proveedorId <= 0) {
            throw new IllegalArgumentException(
                    "El identificador del proveedor no es válido.");
        }

        String razonSocial = request.getParameter("razonSocial");
        String ruc = request.getParameter("ruc");

        if (razonSocial == null || razonSocial.trim().isEmpty()
                || ruc == null || ruc.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "La razón social y el RUC son obligatorios.");
        }

        Proveedor proveedor = new Proveedor();
        proveedor.setProveedorId(proveedorId);
        proveedor.setRazonSocial(razonSocial.trim());
        proveedor.setRuc(ruc.trim());
        proveedor.setTelefono(valorFormulario(request, "telefono"));
        proveedor.setDireccion(valorFormulario(request, "direccion"));
        proveedor.setCorreo(valorFormulario(request, "correo"));

        return proveedor;
    }

    private String valorFormulario(
            HttpServletRequest request, String campo) {

        String valor = request.getParameter(campo);
        return valor == null ? "" : valor.trim();
    }

    private boolean sesionValida(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        return session != null
                && session.getAttribute("usuarioId") != null;
    }

    private void redirigirResultado(
            HttpServletResponse response,
            HttpServletRequest request,
            String resultado) throws IOException {

        response.sendRedirect(
                request.getContextPath()
                + "/proveedoresServlet?mensaje=" + resultado);
    }
}
