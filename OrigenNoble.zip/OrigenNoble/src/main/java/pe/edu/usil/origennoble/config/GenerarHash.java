/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.usil.origennoble.config;

/**
 *
 * @author snay-
 */


import java.util.Scanner;
import org.mindrot.jbcrypt.BCrypt;

public class GenerarHash {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.print("Escribe una contraseña de prueba: ");
        String password = teclado.nextLine();

        String hash = BCrypt.hashpw(
                password, BCrypt.gensalt(12));

        System.out.println("\nHash BCrypt generado:");
        System.out.println(hash);

        teclado.close();
    }
}
