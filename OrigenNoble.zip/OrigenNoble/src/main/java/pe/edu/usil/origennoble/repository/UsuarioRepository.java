/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author snay-
 */


/*NUEVO USUARIO CON CONTROL DE 3 INTENTOS FALLIDOS
*/


package pe.edu.usil.origennoble.repository;

import pe.edu.usil.origennoble.config.ConexionBD;
import pe.edu.usil.origennoble.model.Usuario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioRepository {

    // Buscar un usuario por su nombre de usuario.
    public Usuario buscarPorNombreUsuario(String nombreUsuario)
            throws SQLException {

        String sql = """
            SELECT usuario_id,
                   nombre_usuario,
                   email,
                   contrasena_hash,
                   estado,
                   intentos_fallidos,
                   bloqueado_hasta
            FROM usuarios
            WHERE nombre_usuario = ?
            """;

        try (Connection conexion = ConexionBD.obtenerConexion();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, nombreUsuario);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Usuario usuario = new Usuario();

                    usuario.setUsuarioId(rs.getInt("usuario_id"));
                    usuario.setNombreUsuario(
                            rs.getString("nombre_usuario"));
                    usuario.setEmail(rs.getString("email"));
                    usuario.setContrasenaHash(
                            rs.getString("contrasena_hash"));
                    usuario.setEstado(rs.getString("estado"));
                    usuario.setIntentosFallidos(
                            rs.getInt("intentos_fallidos"));

                    java.sql.Timestamp bloqueo =
                            rs.getTimestamp("bloqueado_hasta");

                    usuario.setBloqueado(
                            bloqueo != null
                            && bloqueo.toInstant().isAfter(
                                    java.time.Instant.now()));

                    return usuario;
                }
            }
        }

        return null;
    }

    // Registrar un intento fallido y bloquear durante 15 minutos
    // al alcanzar tres intentos consecutivos.
    public void registrarIntentoFallido(String nombreUsuario)
            throws SQLException {

        String actualizar = """
            UPDATE usuarios
            SET intentos_fallidos = intentos_fallidos + 1,
                bloqueado_hasta = CASE
                    WHEN intentos_fallidos + 1 >= 3
                    THEN CURRENT_TIMESTAMP + INTERVAL '15 minutes'
                    ELSE bloqueado_hasta
                END
            WHERE nombre_usuario = ?
              AND (bloqueado_hasta IS NULL
                   OR bloqueado_hasta <= CURRENT_TIMESTAMP)
            """;

        String historial = """
            INSERT INTO historial_login
                (usuario_id, nombre_usuario_ingresado,
                 exitoso, motivo)
            VALUES (
                (SELECT usuario_id
                 FROM usuarios
                 WHERE nombre_usuario = ?),
                ?, FALSE, ?
            )
            """;

        try (Connection conexion = ConexionBD.obtenerConexion()) {
            conexion.setAutoCommit(false);

            try {
                try (PreparedStatement ps =
                             conexion.prepareStatement(actualizar)) {
                    ps.setString(1, nombreUsuario);
                    ps.executeUpdate();
                }

                try (PreparedStatement ps =
                             conexion.prepareStatement(historial)) {
                    ps.setString(1, nombreUsuario);
                    ps.setString(2, nombreUsuario);
                    ps.setString(3, "Credenciales incorrectas");
                    ps.executeUpdate();
                }

                conexion.commit();

            } catch (SQLException e) {
                conexion.rollback();
                throw e;
            } finally {
                conexion.setAutoCommit(true);
            }
        }
    }

    // Registrar el inicio de sesión correcto y reiniciar
    // el contador de intentos fallidos.
    public void registrarInicioExitoso(String nombreUsuario)
            throws SQLException {

        String actualizar = """
            UPDATE usuarios
            SET intentos_fallidos = 0,
                bloqueado_hasta = NULL,
                fecha_ultimo_login = CURRENT_TIMESTAMP
            WHERE nombre_usuario = ?
              AND estado = 'activo'
              AND (bloqueado_hasta IS NULL
                   OR bloqueado_hasta <= CURRENT_TIMESTAMP)
            """;

        String historial = """
            INSERT INTO historial_login
                (usuario_id, nombre_usuario_ingresado,
                 exitoso, motivo)
            VALUES (
                (SELECT usuario_id
                 FROM usuarios
                 WHERE nombre_usuario = ?),
                ?, TRUE, ?
            )
            """;

        try (Connection conexion = ConexionBD.obtenerConexion()) {
            conexion.setAutoCommit(false);

            try {
                int filasActualizadas;

                try (PreparedStatement ps =
                             conexion.prepareStatement(actualizar)) {
                    ps.setString(1, nombreUsuario);
                    filasActualizadas = ps.executeUpdate();
                }

                if (filasActualizadas == 0) {
                    throw new SQLException(
                            "No se pudo actualizar el inicio de sesión.");
                }

                try (PreparedStatement ps =
                             conexion.prepareStatement(historial)) {
                    ps.setString(1, nombreUsuario);
                    ps.setString(2, nombreUsuario);
                    ps.setString(3, "Inicio de sesión correcto");
                    ps.executeUpdate();
                }

                conexion.commit();

            } catch (SQLException e) {
                conexion.rollback();
                throw e;
            } finally {
                conexion.setAutoCommit(true);
            }
        }
    }
    
    
    // Listar usuarios para el módulo de administración.

    public java.util.List<Usuario> listarUsuarios() throws SQLException {

        String sql = """
            SELECT u.usuario_id,
                   u.nombre_usuario,
                   u.email,
                   u.estado,
                   u.intentos_fallidos,
                   u.bloqueado_hasta,
                   r.nombre_rol
            FROM usuarios u
            INNER JOIN roles r ON u.rol_id = r.rol_id
            ORDER BY u.usuario_id ASC
            """;

        java.util.List<Usuario> usuarios = new java.util.ArrayList<>();

        try (Connection conexion = ConexionBD.obtenerConexion();
             PreparedStatement ps = conexion.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Usuario usuario = new Usuario();

                usuario.setUsuarioId(rs.getInt("usuario_id"));
                usuario.setNombreUsuario(
                        rs.getString("nombre_usuario"));
                usuario.setEmail(rs.getString("email"));
                usuario.setEstado(rs.getString("estado"));
                usuario.setNombreRol(rs.getString("nombre_rol"));
                usuario.setIntentosFallidos(
                        rs.getInt("intentos_fallidos"));

                java.sql.Timestamp bloqueo =
                        rs.getTimestamp("bloqueado_hasta");

                usuario.setBloqueado(
                        bloqueo != null
                        && bloqueo.toInstant().isAfter(
                                java.time.Instant.now()));

                usuarios.add(usuario);
            }
        }

        return usuarios;
    }

    
    // Registrar un usuario nuevo en la base de datos.
    public void registrarUsuario(
            String nombreUsuario,
            String email,
            String contrasenaHash,
            int rolId) throws SQLException {

        String sql = """
            INSERT INTO usuarios
                (nombre_usuario, email, contrasena_hash, rol_id, estado)
            SELECT ?, ?, ?, rol_id, 'activo'
            FROM roles
            WHERE rol_id = ?
              AND estado = 'activo'
            """;

        try (Connection conexion = ConexionBD.obtenerConexion();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, nombreUsuario);
            ps.setString(2, email);
            ps.setString(3, contrasenaHash);
            ps.setInt(4, rolId);

            int filasInsertadas = ps.executeUpdate();

            if (filasInsertadas == 0) {
                throw new SQLException(
                    "No se encontró un rol activo para el usuario.");
            }
        }
    }

    
    
    // Verificar si una cuenta tiene el rol Administrador activo.
    public boolean esAdministrador(int usuarioId) throws SQLException {

        String sql = """
            SELECT EXISTS (
                SELECT 1
                FROM usuarios u
                INNER JOIN roles r ON u.rol_id = r.rol_id
                WHERE u.usuario_id = ?
                  AND u.estado = 'activo'
                  AND r.estado = 'activo'
                  AND LOWER(r.nombre_rol) = 'administrador'
            )
            """;

        try (Connection conexion = ConexionBD.obtenerConexion();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setInt(1, usuarioId);

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getBoolean(1);
            }
        }
    }

    
    
    // Actualizar los datos básicos y el rol de un usuario.
    public void actualizarUsuario(
            int usuarioId,
            String nombreUsuario,
            String email,
            int rolId) throws SQLException {

        String sql = """
            UPDATE usuarios
            SET nombre_usuario = ?,
                email = ?,
                rol_id = ?
            WHERE usuario_id = ?
              AND EXISTS (
                  SELECT 1
                  FROM roles
                  WHERE roles.rol_id = ?
                    AND roles.estado = 'activo'
              )
            """;

        try (Connection conexion = ConexionBD.obtenerConexion();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, nombreUsuario);
            ps.setString(2, email);
            ps.setInt(3, rolId);
            ps.setInt(4, usuarioId);
            ps.setInt(5, rolId);

            if (ps.executeUpdate() == 0) {
                throw new SQLException(
                    "No se actualizó el usuario. Verifica el usuario y el rol activo.");
            }
        }
    }

    // Cambiar el estado de una cuenta entre activo e inactivo.
    public void cambiarEstadoUsuario(
            int usuarioId,
            String nuevoEstado) throws SQLException {

        if (!"activo".equals(nuevoEstado)
                && !"inactivo".equals(nuevoEstado)) {
            throw new IllegalArgumentException(
                "El estado solicitado no es válido.");
        }

        String sql = """
            UPDATE usuarios
            SET estado = ?
            WHERE usuario_id = ?
            """;

        try (Connection conexion = ConexionBD.obtenerConexion();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, nuevoEstado);
            ps.setInt(2, usuarioId);

            if (ps.executeUpdate() == 0) {
                throw new SQLException("No se encontró el usuario.");
            }
        }
    }

    
}



