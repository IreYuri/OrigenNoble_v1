/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.usil.origennoble.controller;

/**
 *
 * @author snay-
 */

import pe.edu.usil.origennoble.repository.UsuarioRepository;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;

@WebServlet(name = "CambiarEstadoUsuarioServlet",
            urlPatterns = {"/cambiarEstadoUsuarioServlet"})
public class CambiarEstadoUsuarioServlet extends HttpServlet {

    private UsuarioRepository usuarioRepository;

    @Override
    public void init() throws ServletException {
        usuarioRepository = new UsuarioRepository();
    }

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        response.sendError(
            HttpServletResponse.SC_METHOD_NOT_ALLOWED,
            "Esta operación debe realizarse mediante POST."
        );
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String rutaUsuarios =
                request.getContextPath() + "/usuariosServlet";

        // Verificar que exista una sesión válida.
        HttpSession sesion = request.getSession(false);

        if (sesion == null
                || !(sesion.getAttribute("usuarioId") instanceof Number)) {
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return;
        }

        int adminId = ((Number) sesion.getAttribute("usuarioId")).intValue();

        // Verificar que el usuario conectado sea administrador.
        try {
            if (!usuarioRepository.esAdministrador(adminId)) {
                response.sendError(
                    HttpServletResponse.SC_FORBIDDEN,
                    "No tienes permisos para cambiar estados de usuarios."
                );
                return;
            }
        } catch (SQLException e) {
            log("Error al verificar permisos del administrador.", e);
            response.sendError(
                HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                "No se pudieron verificar los permisos."
            );
            return;
        }

        // Validar el ID del usuario objetivo.
        int usuarioId;

        try {
            usuarioId = Integer.parseInt(
                request.getParameter("usuarioId")
            );

            if (usuarioId <= 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException | NullPointerException e) {
            response.sendRedirect(rutaUsuarios + "?estado=datos");
            return;
        }

        String nuevoEstado = request.getParameter("nuevoEstado");

        if (!"activo".equals(nuevoEstado)
                && !"inactivo".equals(nuevoEstado)) {
            response.sendRedirect(rutaUsuarios + "?estado=datos");
            return;
        }

        // Evitar que el administrador desactive su propia cuenta.
        if (usuarioId == adminId && "inactivo".equals(nuevoEstado)) {
            response.sendRedirect(rutaUsuarios + "?estado=propia");
            return;
        }

        try {
            usuarioRepository.cambiarEstadoUsuario(
                usuarioId,
                nuevoEstado
            );

            response.sendRedirect(
                rutaUsuarios + "?estado=actualizado"
            );

        } catch (SQLException e) {
            log("Error al cambiar el estado del usuario.", e);
            response.sendRedirect(
                rutaUsuarios + "?estado=error"
            );
        }
    }
}