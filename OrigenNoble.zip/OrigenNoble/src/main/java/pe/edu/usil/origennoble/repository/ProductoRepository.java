
package pe.edu.usil.origennoble.repository;
import pe.edu.usil.origennoble.config.ConexionBD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import pe.edu.usil.origennoble.model.Producto;
// Usa aquí el mismo import de ConexionBD que tienes
// en ProveedorRepository.java.

public class ProductoRepository {

    public boolean registrarProducto(Producto producto)
            throws SQLException {

        String sql = """
            INSERT INTO productos (
                nombre, descripcion, categoria_id, proveedor_id,
                precio_venta, stock, stock_minimo,
                unidad_medida
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """;

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, producto.getNombre());
            ps.setString(2, producto.getDescripcion());
            ps.setInt(3, producto.getCategoriaId());

            if (producto.getProveedorId() == null) {
                ps.setNull(4, java.sql.Types.INTEGER);
            } else {
                ps.setInt(4, producto.getProveedorId());
            }

            ps.setBigDecimal(5, producto.getPrecioVenta());
            ps.setInt(6, producto.getStock());
            ps.setInt(7, producto.getStockMinimo());
            ps.setString(8, producto.getUnidadMedida());

            return ps.executeUpdate() > 0;
        }
    }

    public List<Producto> listarProductos()
            throws SQLException {

        List<Producto> productos = new ArrayList<>();

        String sql = """
            SELECT p.*, c.nombre AS nombre_categoria,
                   pr.razon_social AS razon_social_proveedor
            FROM productos p
            INNER JOIN categorias c
                ON p.categoria_id = c.categoria_id
            LEFT JOIN proveedores pr
                ON p.proveedor_id = pr.proveedor_id
            ORDER BY p.producto_id DESC
            """;

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                productos.add(mapearProducto(rs));
            }
        }

        return productos;
    }

    public Producto buscarPorId(int productoId)
            throws SQLException {

        String sql = """
            SELECT p.*, c.nombre AS nombre_categoria,
                   pr.razon_social AS razon_social_proveedor
            FROM productos p
            INNER JOIN categorias c
                ON p.categoria_id = c.categoria_id
            LEFT JOIN proveedores pr
                ON p.proveedor_id = pr.proveedor_id
            WHERE p.producto_id = ?
            """;

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, productoId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapearProducto(rs);
                }
            }
        }

        return null;
    }

    public List<Producto> buscarProductos(String busqueda)
            throws SQLException {

        List<Producto> productos = new ArrayList<>();

        String sql = """
            SELECT p.*, c.nombre AS nombre_categoria,
                   pr.razon_social AS razon_social_proveedor
            FROM productos p
            INNER JOIN categorias c
                ON p.categoria_id = c.categoria_id
            LEFT JOIN proveedores pr
                ON p.proveedor_id = pr.proveedor_id
            WHERE p.nombre ILIKE ?
               OR c.nombre ILIKE ?
               OR COALESCE(pr.razon_social, '') ILIKE ?
            ORDER BY p.producto_id DESC
            """;

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            String filtro = "%" + busqueda.trim() + "%";

            ps.setString(1, filtro);
            ps.setString(2, filtro);
            ps.setString(3, filtro);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    productos.add(mapearProducto(rs));
                }
            }
        }

        return productos;
    }

    public boolean actualizarProducto(Producto producto)
            throws SQLException {

        String sql = """
            UPDATE productos
            SET nombre = ?,
                descripcion = ?,
                categoria_id = ?,
                proveedor_id = ?,
                precio_venta = ?,
                stock = ?,
                stock_minimo = ?,
                unidad_medida = ?
            WHERE producto_id = ?
            """;

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, producto.getNombre());
            ps.setString(2, producto.getDescripcion());
            ps.setInt(3, producto.getCategoriaId());

            if (producto.getProveedorId() == null) {
                ps.setNull(4, java.sql.Types.INTEGER);
            } else {
                ps.setInt(4, producto.getProveedorId());
            }

            ps.setBigDecimal(5, producto.getPrecioVenta());
            ps.setInt(6, producto.getStock());
            ps.setInt(7, producto.getStockMinimo());
            ps.setString(8, producto.getUnidadMedida());
            ps.setInt(9, producto.getProductoId());

            return ps.executeUpdate() > 0;
        }
    }

    public boolean cambiarEstadoProducto(
            int productoId, String nuevoEstado)
            throws SQLException {

        if (!"activo".equals(nuevoEstado)
                && !"inactivo".equals(nuevoEstado)) {
            return false;
        }

        String sql = """
            UPDATE productos
            SET estado = ?
            WHERE producto_id = ?
            """;

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, nuevoEstado);
            ps.setInt(2, productoId);

            return ps.executeUpdate() > 0;
        }
    }

    private Producto mapearProducto(ResultSet rs)
            throws SQLException {

        Producto producto = new Producto();

        producto.setProductoId(rs.getInt("producto_id"));
        producto.setNombre(rs.getString("nombre"));
        producto.setDescripcion(rs.getString("descripcion"));
        producto.setCategoriaId(rs.getInt("categoria_id"));
        producto.setNombreCategoria(
                rs.getString("nombre_categoria"));

        int proveedorId = rs.getInt("proveedor_id");

        if (rs.wasNull()) {
            producto.setProveedorId(null);
        } else {
            producto.setProveedorId(proveedorId);
        }

        producto.setRazonSocialProveedor(
                rs.getString("razon_social_proveedor"));

        producto.setPrecioVenta(rs.getBigDecimal("precio_venta"));
        producto.setStock(rs.getInt("stock"));
        producto.setStockMinimo(rs.getInt("stock_minimo"));
        producto.setUnidadMedida(rs.getString("unidad_medida"));
        producto.setEstado(rs.getString("estado"));

        return producto;
    }
}
