
package pe.edu.usil.origennoble.model;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class Solped {

    private int solpedId;
    private Integer clienteId;
    private String nombreCliente;
    private int usuarioId;
    private String nombreUsuario;
    private Timestamp fechaSolicitud;
    private String observaciones;
    private String estado;

    private List<DetalleSolped> detalles = new ArrayList<>();

    public int getSolpedId() {
        return solpedId;
    }

    public void setSolpedId(int solpedId) {
        this.solpedId = solpedId;
    }

    public Integer getClienteId() {
        return clienteId;
    }

    public void setClienteId(Integer clienteId) {
        this.clienteId = clienteId;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public int getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public Timestamp getFechaSolicitud() {
        return fechaSolicitud;
    }

    public void setFechaSolicitud(Timestamp fechaSolicitud) {
        this.fechaSolicitud = fechaSolicitud;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public List<DetalleSolped> getDetalles() {
        return detalles;
    }

    public void setDetalles(List<DetalleSolped> detalles) {
        this.detalles = detalles;
    }
}
