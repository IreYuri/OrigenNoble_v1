package pe.edu.usil.origennoble.controller;

import pe.edu.usil.origennoble.config.ConexionBD;
import pe.edu.usil.origennoble.model.Categoria;
import pe.edu.usil.origennoble.repository.CategoriaRepository;


import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

@WebServlet("/categoriasServlet")
public class CategoriasServlet extends HttpServlet {

    private final CategoriaRepository categoriaRepository =
            new CategoriaRepository();

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("usuarioId") == null) {
            response.sendRedirect(
                    request.getContextPath() + "/login.jsp");
            return;
        }

        try {
            List<Categoria> categorias =
                    categoriaRepository.listarCategorias();

            request.setAttribute("categorias", categorias);

            request.getRequestDispatcher(
                    "/categorias.jsp").forward(request, response);

        } catch (Exception e) {
            throw new ServletException(
                    "Error al cargar las categorías.", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("usuarioId") == null) {
            response.sendRedirect(
                    request.getContextPath() + "/login.jsp");
            return;
        }

        String nombre = request.getParameter("nombre");
        String descripcion = request.getParameter("descripcion");

        if (nombre == null || nombre.trim().isEmpty()) {
            response.sendRedirect(
                    request.getContextPath()
                    + "/categoriasServlet?error=nombre");
            return;
        }

        nombre = nombre.trim();

        try {
            Categoria categoria = new Categoria();
            categoria.setNombre(nombre);
            categoria.setDescripcion(
                    descripcion == null || descripcion.trim().isEmpty()
                    ? null : descripcion.trim());
            categoria.setEstado("activo");

            boolean registrada =
                    categoriaRepository.registrarCategoria(categoria);

            if (registrada) {
                response.sendRedirect(
                        request.getContextPath()
                        + "/categoriasServlet?exito=registro");
            } else {
                response.sendRedirect(
                        request.getContextPath()
                        + "/categoriasServlet?error=registro");
            }

        } catch (Exception e) {
            throw new ServletException(
                    "Error al registrar la categoría.", e);
        }
    }
    
    
}
