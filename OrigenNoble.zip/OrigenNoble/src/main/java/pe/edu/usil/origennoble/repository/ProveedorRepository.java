
package pe.edu.usil.origennoble.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import pe.edu.usil.origennoble.config.ConexionBD;
import pe.edu.usil.origennoble.model.Proveedor;

public class ProveedorRepository {

    public boolean registrarProveedor(Proveedor proveedor)
            throws SQLException {

        String sql = """
            INSERT INTO proveedores
                (razon_social, ruc, telefono, direccion, correo, estado)
            VALUES (?, ?, ?, ?, ?, 'activo')
            """;

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, proveedor.getRazonSocial().trim());
            ps.setString(2, proveedor.getRuc().trim());
            ps.setString(3, proveedor.getTelefono());
            ps.setString(4, proveedor.getDireccion());
            ps.setString(5, proveedor.getCorreo());

            return ps.executeUpdate() > 0;
        }
    }

    public List<Proveedor> listarProveedores() throws SQLException {

        List<Proveedor> lista = new ArrayList<>();

        String sql = """
            SELECT proveedor_id, razon_social, ruc, telefono,
                   direccion, correo, estado
            FROM proveedores
            ORDER BY proveedor_id DESC
            """;

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapearProveedor(rs));
            }
        }

        return lista;
    }

    public Proveedor buscarPorId(int proveedorId) throws SQLException {

        String sql = """
            SELECT proveedor_id, razon_social, ruc, telefono,
                   direccion, correo, estado
            FROM proveedores
            WHERE proveedor_id = ?
            """;

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, proveedorId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapearProveedor(rs);
                }
            }
        }

        return null;
    }

    public List<Proveedor> buscarProveedores(String busqueda)
            throws SQLException {

        List<Proveedor> lista = new ArrayList<>();

        String sql = """
            SELECT proveedor_id, razon_social, ruc, telefono,
                   direccion, correo, estado
            FROM proveedores
            WHERE razon_social ILIKE ?
               OR ruc ILIKE ?
            ORDER BY proveedor_id DESC
            """;

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            String criterio = "%" + busqueda.trim() + "%";
            ps.setString(1, criterio);
            ps.setString(2, criterio);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearProveedor(rs));
                }
            }
        }

        return lista;
    }

    public boolean actualizarProveedor(Proveedor proveedor)
            throws SQLException {

        String sql = """
            UPDATE proveedores
            SET razon_social = ?,
                ruc = ?,
                telefono = ?,
                direccion = ?,
                correo = ?
            WHERE proveedor_id = ?
            """;

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, proveedor.getRazonSocial().trim());
            ps.setString(2, proveedor.getRuc().trim());
            ps.setString(3, proveedor.getTelefono());
            ps.setString(4, proveedor.getDireccion());
            ps.setString(5, proveedor.getCorreo());
            ps.setInt(6, proveedor.getProveedorId());

            return ps.executeUpdate() > 0;
        }
    }

    public boolean cambiarEstadoProveedor(
            int proveedorId, String nuevoEstado) throws SQLException {

        if (proveedorId <= 0) {
            throw new SQLException("El identificador no es válido.");
        }

        if (!"activo".equals(nuevoEstado)
                && !"inactivo".equals(nuevoEstado)) {
            throw new SQLException("El estado indicado no es válido.");
        }

        String sql = """
            UPDATE proveedores
            SET estado = ?
            WHERE proveedor_id = ?
            """;

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, nuevoEstado);
            ps.setInt(2, proveedorId);

            return ps.executeUpdate() > 0;
        }
    }

    private Proveedor mapearProveedor(ResultSet rs)
            throws SQLException {

        Proveedor proveedor = new Proveedor();

        proveedor.setProveedorId(rs.getInt("proveedor_id"));
        proveedor.setRazonSocial(rs.getString("razon_social"));
        proveedor.setRuc(rs.getString("ruc"));
        proveedor.setTelefono(rs.getString("telefono"));
        proveedor.setDireccion(rs.getString("direccion"));
        proveedor.setCorreo(rs.getString("correo"));
        proveedor.setEstado(rs.getString("estado"));

        return proveedor;
    }
}
