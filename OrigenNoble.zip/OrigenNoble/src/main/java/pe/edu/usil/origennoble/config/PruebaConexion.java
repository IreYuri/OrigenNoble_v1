/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author snay-
 */

package pe.edu.usil.origennoble.config;

import java.sql.Connection;
import java.sql.SQLException;

public class PruebaConexion {

    public static void main(String[] args) {
        try (Connection conexion = ConexionBD.obtenerConexion()) {

            if (conexion.isValid(5)) {
                System.out.println("¡Conexión exitosa con Neon!");
                System.out.println(
                    "Base de datos: "
                    + conexion.getCatalog()
                );
            }

        } catch (SQLException e) {
            System.err.println("Error al conectar con Neon.");
            System.err.println(e.getMessage());
        }
    }
}

