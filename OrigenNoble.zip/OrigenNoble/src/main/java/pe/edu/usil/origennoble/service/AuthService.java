/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author snay-
 */

/*nuevo codigo_v2*/
package pe.edu.usil.origennoble.service;

import org.mindrot.jbcrypt.BCrypt;
import pe.edu.usil.origennoble.model.Usuario;
import pe.edu.usil.origennoble.repository.UsuarioRepository;

import java.sql.SQLException;

public class AuthService {

    private final UsuarioRepository usuarioRepository;

    public AuthService() {
        this.usuarioRepository = new UsuarioRepository();
    }

    public Usuario autenticar(String nombreUsuario, String password)
            throws SQLException {

        if (nombreUsuario == null || password == null
                || nombreUsuario.isBlank() || password.isBlank()) {
            return null;
        }

        String usuarioIngresado = nombreUsuario.trim();

        Usuario usuario =
                usuarioRepository.buscarPorNombreUsuario(
                        usuarioIngresado);

        if (usuario == null) {
            // Evitar revelar si el usuario existe.
            return null;
        }

        if (!"activo".equalsIgnoreCase(usuario.getEstado())) {
            return null;
        }

        if (usuario.isBloqueado()) {
            return null;
        }

        if (!BCrypt.checkpw(
                password, usuario.getContrasenaHash())) {

            usuarioRepository.registrarIntentoFallido(
                    usuarioIngresado);
            return null;
        }

        usuarioRepository.registrarInicioExitoso(
                usuarioIngresado);

        return usuario;
    }
    
    
    // Registrar un usuario con contraseña protegida mediante BCrypt.
    public void registrarUsuario(
            String nombreUsuario,
            String email,
            String password,
            int rolId) throws SQLException {

        if (nombreUsuario == null || email == null || password == null
                || nombreUsuario.isBlank()
                || email.isBlank()
                || password.isBlank()) {
            throw new IllegalArgumentException(
                    "Todos los campos son obligatorios.");
        }

        nombreUsuario = nombreUsuario.trim();
        email = email.trim().toLowerCase(java.util.Locale.ROOT);

        if (!nombreUsuario.matches("[a-zA-Z0-9._-]{3,50}")) {
            throw new IllegalArgumentException(
                    "El usuario debe tener entre 3 y 50 caracteres "
                    + "y usar solo letras, números, punto, guion "
                    + "o guion bajo.");
        }

        if (!email.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) {
            throw new IllegalArgumentException(
                    "Ingresa un correo electrónico válido.");
        }

        if (password.length() < 8) {
            throw new IllegalArgumentException(
                    "La contraseña debe tener al menos 8 caracteres.");
        }

        if (rolId <= 0) {
            throw new IllegalArgumentException(
                    "Selecciona un rol válido.");
        }

        String hash = BCrypt.hashpw(
                password, BCrypt.gensalt(10));

        usuarioRepository.registrarUsuario(
                nombreUsuario, email, hash, rolId);
    }

    
}
