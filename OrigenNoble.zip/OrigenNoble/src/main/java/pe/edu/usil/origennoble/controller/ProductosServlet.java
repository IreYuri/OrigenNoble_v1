
package pe.edu.usil.origennoble.controller;

import pe.edu.usil.origennoble.model.Producto;
import pe.edu.usil.origennoble.model.Categoria;
import pe.edu.usil.origennoble.repository.ProductoRepository;
import pe.edu.usil.origennoble.repository.CategoriaRepository;
import pe.edu.usil.origennoble.repository.ProveedorRepository;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

@WebServlet(name = "ProductosServlet", urlPatterns = {"/productosServlet"})
public class ProductosServlet extends HttpServlet {

    private final ProductoRepository productoRepository =
            new ProductoRepository();

    private final CategoriaRepository categoriaRepository =
            new CategoriaRepository();

    private final ProveedorRepository proveedorRepository =
            new ProveedorRepository();

    private boolean sesionIniciada(HttpServletRequest request) {
        HttpSession sesion = request.getSession(false);

        return sesion != null
                && sesion.getAttribute("usuarioId") != null;
    }

    private void redirigir(
            HttpServletRequest request,
            HttpServletResponse response,
            String parametros) throws IOException {

        response.sendRedirect(
                request.getContextPath()
                + "/productosServlet"
                + parametros);
    }

    // =====================================================
    // GET: LISTAR, BUSCAR Y CARGAR FORMULARIOS DE EDICIÓN
    // =====================================================
    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        if (!sesionIniciada(request)) {
            response.sendRedirect(
                    request.getContextPath() + "/index.jsp");
            return;
        }

        try {
            String busqueda = request.getParameter("busqueda");
            String editarId = request.getParameter("editar");
            String editarCategoriaId =
                    request.getParameter("editarCategoria");

            // EDITAR PRODUCTO
            if (editarId != null && !editarId.isBlank()) {
                int idProducto = Integer.parseInt(editarId);

                Producto productoEditar =
                        productoRepository.buscarPorId(idProducto);

                if (productoEditar == null) {
                    redirigir(
                            request, response,
                            "?error=noEncontrado");
                    return;
                }

                request.setAttribute(
                        "productoEditar", productoEditar);
            }

            // EDITAR CATEGORÍA
            if (editarCategoriaId != null
                    && !editarCategoriaId.isBlank()) {

                int idCategoria =
                        Integer.parseInt(editarCategoriaId);

                Categoria categoriaEditar =
                        categoriaRepository.buscarPorId(idCategoria);

                if (categoriaEditar == null) {
                    redirigir(
                            request, response,
                            "?error=categoriaNoEncontrada");
                    return;
                }

                request.setAttribute(
                        "categoriaEditar", categoriaEditar);
            }

            // LISTAR O BUSCAR PRODUCTOS
            List<Producto> productos;

            if (busqueda != null && !busqueda.isBlank()) {
                productos =
                        productoRepository.buscarProductos(
                                busqueda.trim());
            } else {
                productos =
                        productoRepository.listarProductos();
            }

            // CARGAR CATEGORÍAS Y PROVEEDORES
            List<Categoria> categorias =
                    categoriaRepository.listarCategorias();

            request.setAttribute("productos", productos);
            request.setAttribute("categorias", categorias);
            request.setAttribute(
                    "proveedores",
                    proveedorRepository.listarProveedores());
            request.setAttribute("busqueda", busqueda);

            request.getRequestDispatcher("/productos.jsp")
                    .forward(request, response);

        } catch (NumberFormatException e) {
            redirigir(request, response, "?error=valores");

        } catch (SQLException e) {
            getServletContext().log(
                    "Error al consultar productos, categorías o proveedores.",
                    e);

            throw new ServletException(
                    "Error de base de datos al cargar el módulo.", e);
        }
    }

    // =====================================================
    // POST: REGISTRAR, ACTUALIZAR Y CAMBIAR ESTADOS
    // =====================================================
    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        if (!sesionIniciada(request)) {
            response.sendRedirect(
                    request.getContextPath() + "/index.jsp");
            return;
        }

        String accion = request.getParameter("accion");

        try {

            // =================================================
            // REGISTRAR O ACTUALIZAR CATEGORÍA
            // =================================================
            if ("registrarCategoria".equals(accion)
                    || "actualizarCategoria".equals(accion)) {

                String nombre =
                        request.getParameter("nombreCategoria");

                String descripcion =
                        request.getParameter("descripcionCategoria");

                if (nombre == null || nombre.trim().isEmpty()) {
                    redirigir(
                            request, response, "?error=categoria");
                    return;
                }

                Categoria categoria = new Categoria();
                categoria.setNombre(nombre.trim());

                categoria.setDescripcion(
                        descripcion == null || descripcion.isBlank()
                                ? null
                                : descripcion.trim());

                boolean resultado;

                if ("actualizarCategoria".equals(accion)) {

                    String idTexto =
                            request.getParameter("categoriaId");

                    if (idTexto == null || idTexto.isBlank()) {
                        redirigir(
                                request, response, "?error=categoria");
                        return;
                    }

                    int idCategoria = Integer.parseInt(idTexto);

                    categoria.setCategoriaId(idCategoria);

                    resultado =
                            categoriaRepository.actualizarCategoria(
                                    categoria);

                    redirigir(
                            request,
                            response,
                            resultado
                                    ? "?exito=categoriaActualizada"
                                    : "?error=categoria");

                } else {

                    resultado =
                            categoriaRepository.registrarCategoria(
                                    categoria);

                    redirigir(
                            request,
                            response,
                            resultado
                                    ? "?exito=categoria"
                                    : "?error=categoria");
                }

                return;
            }

            // =================================================
            // ACTIVAR O DESACTIVAR CATEGORÍA
            // =================================================
            if ("cambiarEstadoCategoria".equals(accion)) {

                String idTexto =
                        request.getParameter("categoriaId");

                String estado =
                        request.getParameter("estado");

                if (idTexto == null || idTexto.isBlank()
                        || (!"activo".equals(estado)
                        && !"inactivo".equals(estado))) {

                    redirigir(
                            request, response,
                            "?error=estadoCategoria");
                    return;
                }

                int idCategoria = Integer.parseInt(idTexto);

                boolean resultado =
                        categoriaRepository.cambiarEstadoCategoria(
                                idCategoria, estado);

                redirigir(
                        request,
                        response,
                        resultado
                                ? "?exito=estadoCategoria"
                                : "?error=estadoCategoria");

                return;
            }

            // =================================================
            // ACTIVAR O DESACTIVAR PRODUCTO
            // =================================================
            if ("cambiarEstado".equals(accion)) {

                String idTexto =
                        request.getParameter("productoId");

                String estado =
                        request.getParameter("estado");

                if (idTexto == null || idTexto.isBlank()
                        || (!"activo".equals(estado)
                        && !"inactivo".equals(estado))) {

                    redirigir(
                            request, response, "?error=estado");
                    return;
                }

                int idProducto = Integer.parseInt(idTexto);

                boolean resultado =
                        productoRepository.cambiarEstadoProducto(
                                idProducto, estado);

                redirigir(
                        request,
                        response,
                        resultado
                                ? "?exito=estado"
                                : "?error=estado");

                return;
            }

            // =================================================
            // REGISTRAR O ACTUALIZAR PRODUCTO
            // =================================================
            if ("guardarProducto".equals(accion)
                    || "actualizarProducto".equals(accion)) {

                String nombre =
                        request.getParameter("nombre");

                String descripcion =
                        request.getParameter("descripcion");

                String categoriaTexto =
                        request.getParameter("categoriaId");

                String proveedorTexto =
                        request.getParameter("proveedorId");

                String precioTexto =
                        request.getParameter("precioVenta");

                String stockTexto =
                        request.getParameter("stock");

                String stockMinimoTexto =
                        request.getParameter("stockMinimo");

                String unidadMedida =
                        request.getParameter("unidadMedida");

                // VALIDAR CAMPOS OBLIGATORIOS
                if (nombre == null || nombre.trim().isEmpty()
                        || categoriaTexto == null
                        || categoriaTexto.isBlank()
                        || precioTexto == null
                        || precioTexto.isBlank()
                        || stockTexto == null
                        || stockTexto.isBlank()
                        || stockMinimoTexto == null
                        || stockMinimoTexto.isBlank()) {

                    redirigir(
                            request, response, "?error=datos");
                    return;
                }

                // CONVERTIR Y VALIDAR VALORES
                BigDecimal precio =
                        new BigDecimal(precioTexto);

                int stock = Integer.parseInt(stockTexto);
                int stockMinimo =
                        Integer.parseInt(stockMinimoTexto);

                int categoriaId =
                        Integer.parseInt(categoriaTexto);

                if (precio.compareTo(BigDecimal.ZERO) < 0
                        || stock < 0
                        || stockMinimo < 0) {

                    redirigir(
                            request, response, "?error=valores");
                    return;
                }

                // CONSTRUIR PRODUCTO
                Producto producto = new Producto();

                producto.setNombre(nombre.trim());

                producto.setDescripcion(
                        descripcion == null || descripcion.isBlank()
                                ? null
                                : descripcion.trim());

                producto.setCategoriaId(categoriaId);
                producto.setPrecioVenta(precio);
                producto.setStock(stock);
                producto.setStockMinimo(stockMinimo);

                producto.setUnidadMedida(
                        unidadMedida == null
                                || unidadMedida.isBlank()
                                ? "unidad"
                                : unidadMedida.trim());

                if (proveedorTexto != null
                        && !proveedorTexto.isBlank()) {

                    producto.setProveedorId(
                            Integer.parseInt(proveedorTexto));

                } else {
                    producto.setProveedorId(null);
                }

                // ACTUALIZAR PRODUCTO
                if ("actualizarProducto".equals(accion)) {

                    String idTexto =
                            request.getParameter("productoId");

                    if (idTexto == null || idTexto.isBlank()) {
                        redirigir(
                                request, response, "?error=datos");
                        return;
                    }

                    int idProducto = Integer.parseInt(idTexto);

                    producto.setProductoId(idProducto);

                    boolean resultado =
                            productoRepository.actualizarProducto(
                                    producto);

                    redirigir(
                            request,
                            response,
                            resultado
                                    ? "?exito=actualizado"
                                    : "?error=guardar");

                } else {

                    // REGISTRAR PRODUCTO
                    boolean resultado =
                            productoRepository.registrarProducto(
                                    producto);

                    redirigir(
                            request,
                            response,
                            resultado
                                    ? "?exito=producto"
                                    : "?error=guardar");
                }

                return;
            }

            // =================================================
            // ACCIÓN NO RECONOCIDA
            // =================================================
            redirigir(request, response, "?error=accion");

        } catch (NumberFormatException e) {
            redirigir(request, response, "?error=valores");

        } catch (SQLException e) {

            getServletContext().log(
                    "Error de base de datos al procesar la operación.",
                    e);

            if ("registrarCategoria".equals(accion)
                    || "actualizarCategoria".equals(accion)) {

                redirigir(
                        request, response, "?error=categoria");

            } else if ("cambiarEstadoCategoria".equals(accion)) {

                redirigir(
                        request, response, "?error=estadoCategoria");

            } else if ("cambiarEstado".equals(accion)) {

                redirigir(
                        request, response, "?error=estado");

            } else {

                redirigir(
                        request, response, "?error=guardar");
            }

        } catch (Exception e) {

            getServletContext().log(
                    "Error al procesar la operación del módulo.",
                    e);

            throw new ServletException(
                    "No se pudo completar la operación.", e);
        }
    }
}
