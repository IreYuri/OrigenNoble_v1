
package pe.edu.usil.origennoble.model;

import java.math.BigDecimal;

public class DetalleSolped {

    private int detalleSolpedId;
    private int solpedId;
    private int productoId;
    private String nombreProducto;
    private int cantidad;
    private BigDecimal precioReferencial;

    public int getDetalleSolpedId() {
        return detalleSolpedId;
    }

    public void setDetalleSolpedId(int detalleSolpedId) {
        this.detalleSolpedId = detalleSolpedId;
    }

    public int getSolpedId() {
        return solpedId;
    }

    public void setSolpedId(int solpedId) {
        this.solpedId = solpedId;
    }

    public int getProductoId() {
        return productoId;
    }

    public void setProductoId(int productoId) {
        this.productoId = productoId;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public BigDecimal getPrecioReferencial() {
        return precioReferencial;
    }

    public void setPrecioReferencial(BigDecimal precioReferencial) {
        this.precioReferencial = precioReferencial;
    }
}
