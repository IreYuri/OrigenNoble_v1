
package pe.edu.usil.origennoble.repository;

import pe.edu.usil.origennoble.config.ConexionBD;
import pe.edu.usil.origennoble.model.Categoria;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CategoriaRepository {

    public boolean registrarCategoria(Categoria categoria)
            throws SQLException {

        validarNombre(categoria.getNombre());

        String sql = """
            INSERT INTO categorias (nombre, descripcion, estado)
            VALUES (?, ?, 'activo')
            """;

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, categoria.getNombre().trim());
            ps.setString(2, categoria.getDescripcion());

            return ps.executeUpdate() > 0;
        }
    }

    public List<Categoria> listarCategorias() throws SQLException {

        List<Categoria> categorias = new ArrayList<>();

        String sql = """
            SELECT categoria_id, nombre, descripcion, estado
            FROM categorias
            ORDER BY nombre ASC
            """;

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                categorias.add(mapearCategoria(rs));
            }
        }

        return categorias;
    }

    public Categoria buscarPorId(int categoriaId) throws SQLException {

        String sql = """
            SELECT categoria_id, nombre, descripcion, estado
            FROM categorias
            WHERE categoria_id = ?
            """;

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, categoriaId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapearCategoria(rs);
                }
            }
        }

        return null;
    }

    public boolean actualizarCategoria(Categoria categoria)
            throws SQLException {

        if (categoria.getCategoriaId() <= 0) {
            throw new SQLException("El ID de la categoría no es válido.");
        }

        validarNombre(categoria.getNombre());

        String sql = """
            UPDATE categorias
            SET nombre = ?, descripcion = ?
            WHERE categoria_id = ?
            """;

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, categoria.getNombre().trim());
            ps.setString(2, categoria.getDescripcion());
            ps.setInt(3, categoria.getCategoriaId());

            return ps.executeUpdate() > 0;
        }
    }

    public boolean cambiarEstadoCategoria(
            int categoriaId, String nuevoEstado) throws SQLException {

        if (categoriaId <= 0) {
            throw new SQLException("El ID de la categoría no es válido.");
        }

        if (!"activo".equals(nuevoEstado)
                && !"inactivo".equals(nuevoEstado)) {
            throw new SQLException("El estado no es válido.");
        }

        String sql = """
            UPDATE categorias
            SET estado = ?
            WHERE categoria_id = ?
            """;

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, nuevoEstado);
            ps.setInt(2, categoriaId);

            return ps.executeUpdate() > 0;
        }
    }

    private void validarNombre(String nombre) throws SQLException {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new SQLException("El nombre de la categoría es obligatorio.");
        }

        if (nombre.trim().length() > 100) {
            throw new SQLException("El nombre supera los 100 caracteres.");
        }
    }

    private Categoria mapearCategoria(ResultSet rs)
            throws SQLException {

        Categoria categoria = new Categoria();

        categoria.setCategoriaId(rs.getInt("categoria_id"));
        categoria.setNombre(rs.getString("nombre"));
        categoria.setDescripcion(rs.getString("descripcion"));
        categoria.setEstado(rs.getString("estado"));

        return categoria;
    }
}
