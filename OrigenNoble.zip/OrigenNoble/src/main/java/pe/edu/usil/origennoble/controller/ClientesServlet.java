
package pe.edu.usil.origennoble.controller;

import pe.edu.usil.origennoble.model.Cliente;
import pe.edu.usil.origennoble.repository.ClienteRepository;
import pe.edu.usil.origennoble.repository.UsuarioRepository;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet(name = "ClientesServlet", urlPatterns = {"/clientesServlet"})
public class ClientesServlet extends HttpServlet {

    private ClienteRepository clienteRepository;
    private UsuarioRepository usuarioRepository;

    @Override
    public void init() throws ServletException {
        clienteRepository = new ClienteRepository();
        usuarioRepository = new UsuarioRepository();
    }

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession sesion = request.getSession(false);

        // 1. Verificar que exista una sesión iniciada.
        if (sesion == null || sesion.getAttribute("usuarioId") == null) {
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return;
        }

        // 2. Validar el identificador de la sesión.
        Object idSesion = sesion.getAttribute("usuarioId");

        if (!(idSesion instanceof Number)) {
            sesion.invalidate();
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return;
        }

        int usuarioId = ((Number) idSesion).intValue();

        try {
            // 3. Verificar que sea administrador activo.
            if (!usuarioRepository.esAdministrador(usuarioId)) {
                response.sendError(
                        HttpServletResponse.SC_FORBIDDEN,
                        "No tienes permisos para acceder al módulo de clientes."
                );
                return;
            }

            // 4. Listar o buscar clientes.
            String busqueda = request.getParameter("busqueda");
            List<Cliente> clientes;

            if (busqueda != null && !busqueda.trim().isEmpty()) {
                clientes = clienteRepository.buscarClientes(busqueda.trim());
            } else {
                clientes = clienteRepository.listarClientes();
            }

            request.setAttribute("clientes", clientes);
            request.setAttribute("busqueda", busqueda == null ? "" : busqueda);

            // 5. Mostrar la vista.
            request.getRequestDispatcher("/clientes.jsp")
                   .forward(request, response);

        } catch (SQLException e) {
            log("Error al consultar los clientes.", e);

            response.sendError(
                    HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "No se pudo procesar la solicitud de clientes."
            );
        }
    }
}
