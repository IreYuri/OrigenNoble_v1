
package pe.edu.usil.origennoble.repository;

import pe.edu.usil.origennoble.config.ConexionBD;
import pe.edu.usil.origennoble.model.DetalleVenta;
import pe.edu.usil.origennoble.model.Venta;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class VentaRepository {

    public boolean registrarVenta(Venta venta) throws SQLException {

        if (venta.getDetalles() == null || venta.getDetalles().isEmpty()) {
            throw new SQLException("La venta debe contener al menos un producto.");
        }

        try (Connection con = ConexionBD.obtenerConexion()) {
            con.setAutoCommit(false);

            try {
                BigDecimal total = BigDecimal.ZERO;

                String sqlVenta = """
                    INSERT INTO ventas (cliente_id, usuario_id, total, estado)
                    VALUES (?, ?, 0, 'completada')
                    """;

                try (PreparedStatement ps = con.prepareStatement(
                        sqlVenta, Statement.RETURN_GENERATED_KEYS)) {

                    if (venta.getClienteId() == null) {
                        ps.setNull(1, Types.INTEGER);
                    } else {
                        ps.setInt(1, venta.getClienteId());
                    }

                    ps.setInt(2, venta.getUsuarioId());
                    ps.executeUpdate();

                    try (ResultSet rs = ps.getGeneratedKeys()) {
                        if (rs.next()) {
                            venta.setVentaId(rs.getInt(1));
                        } else {
                            throw new SQLException(
                                "No se pudo obtener el identificador de la venta.");
                        }
                    }
                }

                String sqlProducto = """
                    SELECT precio_venta, stock
                    FROM productos
                    WHERE producto_id = ? AND estado = 'activo'
                    FOR UPDATE
                    """;

                String sqlDetalle = """
                    INSERT INTO detalle_ventas
                    (venta_id, producto_id, cantidad, precio_unitario, subtotal)
                    VALUES (?, ?, ?, ?, ?)
                    """;

                String sqlStock = """
                    UPDATE productos
                    SET stock = stock - ?
                    WHERE producto_id = ? AND stock >= ?
                    """;

                try (PreparedStatement psProducto = con.prepareStatement(sqlProducto);
                     PreparedStatement psDetalle = con.prepareStatement(sqlDetalle);
                     PreparedStatement psStock = con.prepareStatement(sqlStock)) {

                    for (DetalleVenta detalle : venta.getDetalles()) {

                        if (detalle.getCantidad() <= 0) {
                            throw new SQLException(
                                "La cantidad debe ser mayor que cero.");
                        }

                        psProducto.setInt(1, detalle.getProductoId());

                        BigDecimal precio;
                        int stock;

                        try (ResultSet rs = psProducto.executeQuery()) {
                            if (!rs.next()) {
                                throw new SQLException(
                                    "El producto " + detalle.getProductoId()
                                    + " no existe o está inactivo.");
                            }

                            precio = rs.getBigDecimal("precio_venta");
                            stock = rs.getInt("stock");
                        }

                        if (stock < detalle.getCantidad()) {
                            throw new SQLException(
                                "Stock insuficiente para el producto ID "
                                + detalle.getProductoId()
                                + ". Disponible: " + stock);
                        }

                        BigDecimal subtotal = precio.multiply(
                            BigDecimal.valueOf(detalle.getCantidad()));

                        psDetalle.setInt(1, venta.getVentaId());
                        psDetalle.setInt(2, detalle.getProductoId());
                        psDetalle.setInt(3, detalle.getCantidad());
                        psDetalle.setBigDecimal(4, precio);
                        psDetalle.setBigDecimal(5, subtotal);
                        psDetalle.executeUpdate();

                        psStock.setInt(1, detalle.getCantidad());
                        psStock.setInt(2, detalle.getProductoId());
                        psStock.setInt(3, detalle.getCantidad());

                        if (psStock.executeUpdate() != 1) {
                            throw new SQLException(
                                "No se pudo actualizar el stock del producto.");
                        }

                        detalle.setVentaId(venta.getVentaId());
                        detalle.setPrecioUnitario(precio);
                        detalle.setSubtotal(subtotal);

                        total = total.add(subtotal);
                    }
                }

                String sqlTotal =
                    "UPDATE ventas SET total = ? WHERE venta_id = ?";

                try (PreparedStatement ps = con.prepareStatement(sqlTotal)) {
                    ps.setBigDecimal(1, total);
                    ps.setInt(2, venta.getVentaId());
                    ps.executeUpdate();
                }

                con.commit();
                venta.setTotal(total);
                venta.setEstado("completada");
                return true;

            } catch (SQLException | RuntimeException e) {
                con.rollback();
                throw e;
            } finally {
                con.setAutoCommit(true);
            }
        }
    }

    public List<Venta> listarVentas() throws SQLException {

        List<Venta> ventas = new ArrayList<>();

        String sql = """
            SELECT venta_id, cliente_id, usuario_id,
                   fecha_venta, total, estado
            FROM ventas
            ORDER BY fecha_venta DESC
            """;

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Venta venta = new Venta();

                venta.setVentaId(rs.getInt("venta_id"));

                int clienteId = rs.getInt("cliente_id");
                venta.setClienteId(
                    rs.wasNull() ? null : clienteId);

                venta.setUsuarioId(rs.getInt("usuario_id"));
                venta.setFechaVenta(rs.getTimestamp("fecha_venta"));
                venta.setTotal(rs.getBigDecimal("total"));
                venta.setEstado(rs.getString("estado"));

                ventas.add(venta);
            }
        }

        return ventas;
    }

    public List<DetalleVenta> listarDetalles(int ventaId)
            throws SQLException {

        List<DetalleVenta> detalles = new ArrayList<>();

        String sql = """
            SELECT dv.detalle_venta_id, dv.venta_id,
                   dv.producto_id, p.nombre AS nombre_producto,
                   dv.cantidad, dv.precio_unitario, dv.subtotal
            FROM detalle_ventas dv
            INNER JOIN productos p
                ON dv.producto_id = p.producto_id
            WHERE dv.venta_id = ?
            ORDER BY dv.detalle_venta_id
            """;

        try (Connection con = ConexionBD.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, ventaId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    DetalleVenta detalle = new DetalleVenta();

                    detalle.setDetalleVentaId(
                        rs.getInt("detalle_venta_id"));
                    detalle.setVentaId(rs.getInt("venta_id"));
                    detalle.setProductoId(rs.getInt("producto_id"));
                    detalle.setNombreProducto(
                        rs.getString("nombre_producto"));
                    detalle.setCantidad(rs.getInt("cantidad"));
                    detalle.setPrecioUnitario(
                        rs.getBigDecimal("precio_unitario"));
                    detalle.setSubtotal(rs.getBigDecimal("subtotal"));

                    detalles.add(detalle);
                }
            }
        }

        return detalles;
    }
}
