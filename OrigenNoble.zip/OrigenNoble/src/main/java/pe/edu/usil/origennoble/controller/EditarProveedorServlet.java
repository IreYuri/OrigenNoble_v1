
package pe.edu.usil.origennoble.controller;

import java.io.IOException;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import pe.edu.usil.origennoble.model.Proveedor;
import pe.edu.usil.origennoble.repository.ProveedorRepository;

@WebServlet(
    name = "EditarProveedorServlet",
    urlPatterns = {"/editarProveedorServlet"}
)
public class EditarProveedorServlet extends HttpServlet {

    private final ProveedorRepository proveedorRepository =
            new ProveedorRepository();

    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String rutaLogin = request.getContextPath() + "/login.jsp";
        String rutaProveedores =
                request.getContextPath() + "/proveedoresServlet";

        HttpSession session = request.getSession(false);

        // Verificar que el usuario haya iniciado sesión.
        if (session == null
                || session.getAttribute("usuarioId") == null) {
            response.sendRedirect(rutaLogin);
            return;
        }

        // Validar el ID recibido por la URL.
        String idParametro = request.getParameter("id");

        if (idParametro == null || idParametro.trim().isEmpty()) {
            response.sendRedirect(
                    rutaProveedores + "?error=noencontrado");
            return;
        }

        int proveedorId;

        try {
            proveedorId = Integer.parseInt(idParametro.trim());

            if (proveedorId <= 0) {
                response.sendRedirect(
                        rutaProveedores + "?error=noencontrado");
                return;
            }

        } catch (NumberFormatException ex) {
            response.sendRedirect(
                    rutaProveedores + "?error=noencontrado");
            return;
        }

        // Buscar al proveedor en la base de datos.
        try {
            Proveedor proveedor =
                    proveedorRepository.buscarPorId(proveedorId);

            if (proveedor == null) {
                response.sendRedirect(
                        rutaProveedores + "?error=noencontrado");
                return;
            }

            request.setAttribute("proveedor", proveedor);

            request.getRequestDispatcher("/editarProveedor.jsp")
                    .forward(request, response);

        } catch (SQLException ex) {
            getServletContext().log(
                    "Error al consultar el proveedor para editar", ex);

            response.sendRedirect(
                    rutaProveedores + "?error=general");
        }
    }
}
