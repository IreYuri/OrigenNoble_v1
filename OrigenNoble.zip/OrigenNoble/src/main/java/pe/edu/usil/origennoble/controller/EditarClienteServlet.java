
package pe.edu.usil.origennoble.servlet;

import java.io.IOException;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import pe.edu.usil.origennoble.model.Cliente;
import pe.edu.usil.origennoble.repository.ClienteRepository;

@WebServlet(name = "EditarClienteServlet", urlPatterns = {"/editarClienteServlet"})
public class EditarClienteServlet extends HttpServlet {

    private final ClienteRepository clienteRepository = new ClienteRepository();

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("usuarioId") == null) {
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return;
        }

        // El módulo de clientes está restringido al administrador.
        try {
            int usuarioId = Integer.parseInt(
                session.getAttribute("usuarioId").toString()
            );

            pe.edu.usil.origennoble.repository.UsuarioRepository usuarios =
                new pe.edu.usil.origennoble.repository.UsuarioRepository();

            if (!usuarios.esAdministrador(usuarioId)) {
                response.sendError(HttpServletResponse.SC_FORBIDDEN);
                return;
            }
        } catch (SQLException | NumberFormatException ex) {
            throw new ServletException("No se pudieron verificar los permisos.", ex);
        }

        String idTexto = request.getParameter("id");

        try {
            if (idTexto == null || idTexto.trim().isEmpty()) {
                response.sendRedirect(
                    request.getContextPath() + "/clientesServlet?error=noencontrado"
                );
                return;
            }

            int id = Integer.parseInt(idTexto);
            if (id <= 0) {
                response.sendRedirect(
                    request.getContextPath() + "/clientesServlet?error=noencontrado"
                );
                return;
            }

            Cliente cliente = clienteRepository.buscarPorId(id);

            if (cliente == null) {
                response.sendRedirect(
                    request.getContextPath() + "/clientesServlet?error=noencontrado"
                );
                return;
            }

            request.setAttribute("cliente", cliente);
            request.getRequestDispatcher("/editarCliente.jsp")
                   .forward(request, response);

        } catch (NumberFormatException ex) {
            response.sendRedirect(
                request.getContextPath() + "/clientesServlet?error=noencontrado"
            );
        } catch (SQLException ex) {
            throw new ServletException("Error al consultar el cliente.", ex);
        }
    }
}
