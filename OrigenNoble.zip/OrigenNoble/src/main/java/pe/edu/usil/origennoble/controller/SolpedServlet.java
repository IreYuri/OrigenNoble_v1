
package pe.edu.usil.origennoble.controller;

import pe.edu.usil.origennoble.config.ConexionBD;
import pe.edu.usil.origennoble.model.DetalleSolped;
import pe.edu.usil.origennoble.model.Solped;
import pe.edu.usil.origennoble.repository.SolpedRepository;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@WebServlet(name = "SolpedServlet", urlPatterns = {"/solpedServlet"})
public class SolpedServlet extends HttpServlet {

    private final SolpedRepository solpedRepository =
            new SolpedRepository();

    private boolean verificarSesion(HttpServletRequest request,
                                    HttpServletResponse response)
            throws IOException {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("usuarioId") == null) {
            response.sendRedirect(
                    request.getContextPath() + "/index.jsp");
            return false;
        }

        return true;
    }

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        if (!verificarSesion(request, response)) {
            return;
        }

        try {
            cargarDatos(request);

            request.getRequestDispatcher("/solped.jsp")
                    .forward(request, response);

        } catch (SQLException e) {
            throw new ServletException(
                    "No se pudieron cargar las solicitudes de pedido.", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        if (!verificarSesion(request, response)) {
            return;
        }

        try {
            HttpSession session = request.getSession(false);

            int usuarioId = Integer.parseInt(
                    session.getAttribute("usuarioId").toString());

            String clienteTexto = request.getParameter("clienteId");
            Integer clienteId = null;

            if (clienteTexto != null && !clienteTexto.isBlank()) {
                clienteId = Integer.parseInt(clienteTexto);

                if (clienteId <= 0) {
                    throw new IllegalArgumentException(
                            "Selecciona un cliente válido.");
                }
            }

            String observaciones = request.getParameter("observaciones");

            if (observaciones != null && observaciones.length() > 500) {
                throw new IllegalArgumentException(
                        "Las observaciones no deben superar 500 caracteres.");
            }

            String[] productos = request.getParameterValues("productoId");
            String[] cantidades = request.getParameterValues("cantidad");

            if (productos == null || cantidades == null
                    || productos.length == 0
                    || productos.length != cantidades.length) {
                throw new IllegalArgumentException(
                        "Agrega al menos un producto a la solicitud.");
            }

            Solped solped = new Solped();
            solped.setClienteId(clienteId);
            solped.setUsuarioId(usuarioId);
            solped.setObservaciones(
                    observaciones == null || observaciones.isBlank()
                    ? null : observaciones.trim());

            List<DetalleSolped> detalles = new ArrayList<>();

            for (int i = 0; i < productos.length; i++) {

                int productoId = Integer.parseInt(productos[i]);
                int cantidad = Integer.parseInt(cantidades[i]);

                if (productoId <= 0 || cantidad <= 0) {
                    throw new IllegalArgumentException(
                            "Verifica los productos y las cantidades.");
                }

                DetalleSolped detalle = new DetalleSolped();
                detalle.setProductoId(productoId);
                detalle.setCantidad(cantidad);
                detalles.add(detalle);
            }

            solped.setDetalles(detalles);
            solpedRepository.registrarSolped(solped);

            response.sendRedirect(
                    request.getContextPath()
                    + "/solpedServlet?mensaje=registrada");

        } catch (NumberFormatException e) {
            mostrarError(request, response,
                    "Verifica que los identificadores y cantidades sean válidos.");

        } catch (IllegalArgumentException | SQLException e) {
            mostrarError(request, response, e.getMessage());
        }
    }

    private void cargarDatos(HttpServletRequest request)
            throws SQLException {

        request.setAttribute(
                "solpedList", solpedRepository.listarSolped());

        List<Map<String, Object>> productos = new ArrayList<>();
        List<Map<String, Object>> clientes = new ArrayList<>();

        String sqlProductos =
                "SELECT producto_id, nombre, precio_venta, stock "
                + "FROM productos "
                + "WHERE estado = 'activo' "
                + "ORDER BY nombre";

        String sqlClientes =
                "SELECT cliente_id, tipo_documento, numero_documento, "
                + "nombres, apellidos, razon_social "
                + "FROM clientes "
                + "WHERE estado = 'activo' "
                + "ORDER BY cliente_id DESC";

        try (Connection con = ConexionBD.getConnection()) {

            try (PreparedStatement ps =
                    con.prepareStatement(sqlProductos);
                 ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    Map<String, Object> p = new LinkedHashMap<>();
                    p.put("id", rs.getInt("producto_id"));
                    p.put("nombre", rs.getString("nombre"));
                    p.put("precio", rs.getBigDecimal("precio_venta"));
                    p.put("stock", rs.getInt("stock"));
                    productos.add(p);
                }
            }

            try (PreparedStatement ps =
                    con.prepareStatement(sqlClientes);
                 ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    Map<String, Object> c = new LinkedHashMap<>();
                    c.put("id", rs.getInt("cliente_id"));
                    c.put("tipoDocumento",
                            rs.getString("tipo_documento"));
                    c.put("numeroDocumento",
                            rs.getString("numero_documento"));

                    String razonSocial = rs.getString("razon_social");
                    String nombres = rs.getString("nombres");
                    String apellidos = rs.getString("apellidos");

                    String nombre = razonSocial;

                    if (nombre == null || nombre.isBlank()) {
                        nombre = ((nombres == null) ? "" : nombres)
                                + " "
                                + ((apellidos == null) ? "" : apellidos);
                    }

                    c.put("nombre", nombre.trim());
                    clientes.add(c);
                }
            }
        }

        request.setAttribute("productos", productos);
        request.setAttribute("clientes", clientes);
    }

    private void mostrarError(HttpServletRequest request,
                              HttpServletResponse response,
                              String mensaje)
            throws ServletException, IOException {

        try {
            cargarDatos(request);
            request.setAttribute("error", mensaje);

            request.getRequestDispatcher("/solped.jsp")
                    .forward(request, response);

        } catch (SQLException e) {
            throw new ServletException(
                    "No se pudo procesar la solicitud.", e);
        }
    }
}
