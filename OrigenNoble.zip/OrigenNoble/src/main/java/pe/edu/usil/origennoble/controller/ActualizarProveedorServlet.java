
package pe.edu.usil.origennoble.controller;

import java.io.IOException;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import pe.edu.usil.origennoble.model.Proveedor;
import pe.edu.usil.origennoble.repository.ProveedorRepository;

@WebServlet(
    name = "ActualizarProveedorServlet",
    urlPatterns = {"/actualizarProveedorServlet"}
)
public class ActualizarProveedorServlet extends HttpServlet {

    private final ProveedorRepository proveedorRepository =
            new ProveedorRepository();

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String rutaProveedores =
                request.getContextPath() + "/proveedoresServlet";

        String rutaEditar =
                request.getContextPath() + "/editarProveedorServlet";

        HttpSession session = request.getSession(false);

        // 1. Verificar que exista una sesión iniciada.
        if (session == null
                || session.getAttribute("usuarioId") == null) {
            response.sendRedirect(
                    request.getContextPath() + "/login.jsp");
            return;
        }

        // 2. Obtener y validar el ID del proveedor.
        int proveedorId;

        try {
            String idParametro = request.getParameter("proveedorId");

            if (idParametro == null || idParametro.trim().isEmpty()) {
                response.sendRedirect(
                        rutaProveedores + "?error=noencontrado");
                return;
            }

            proveedorId = Integer.parseInt(idParametro.trim());

            if (proveedorId <= 0) {
                response.sendRedirect(
                        rutaProveedores + "?error=noencontrado");
                return;
            }

        } catch (NumberFormatException ex) {
            response.sendRedirect(
                    rutaProveedores + "?error=noencontrado");
            return;
        }

        // 3. Leer y limpiar los campos del formulario.
        String razonSocial = limpiar(
                request.getParameter("razonSocial"));

        String ruc = limpiar(request.getParameter("ruc"));
        String telefono = limpiar(request.getParameter("telefono"));
        String direccion = limpiar(request.getParameter("direccion"));
        String correo = limpiar(request.getParameter("correo"));

        // 4. Validar los datos recibidos.
        if (razonSocial.isEmpty()
                || ruc.isEmpty()
                || !ruc.matches("[0-9]{11}")
                || razonSocial.length() > 150
                || telefono.length() > 20
                || direccion.length() > 200
                || correo.length() > 150
                || (!correo.isEmpty()
                    && !correo.matches(
                        "^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$"))) {

            response.sendRedirect(
                    rutaEditar + "?id=" + proveedorId + "&error=datos");
            return;
        }

        try {
            // 5. Recuperar el proveedor actual para conservar su estado.
            Proveedor existente =
                    proveedorRepository.buscarPorId(proveedorId);

            if (existente == null) {
                response.sendRedirect(
                        rutaProveedores + "?error=noencontrado");
                return;
            }

            // 6. Preparar los datos actualizados.
            Proveedor proveedor = new Proveedor();

            proveedor.setProveedorId(proveedorId);
            proveedor.setRazonSocial(razonSocial);
            proveedor.setRuc(ruc);
            proveedor.setTelefono(
                    telefono.isEmpty() ? null : telefono);
            proveedor.setDireccion(
                    direccion.isEmpty() ? null : direccion);
            proveedor.setCorreo(
                    correo.isEmpty() ? null : correo);

            // Mantener el estado actual del proveedor.
            proveedor.setEstado(existente.getEstado());

            // 7. Actualizar en la base de datos.
            boolean actualizado =
                    proveedorRepository.actualizarProveedor(proveedor);

            if (actualizado) {
                response.sendRedirect(
                        rutaProveedores + "?mensaje=actualizado");
            } else {
                response.sendRedirect(
                        rutaEditar + "?id=" + proveedorId
                        + "&error=general");
            }

        } catch (SQLException ex) {

            // SQLState 23505: valor duplicado, por ejemplo, el RUC.
            if ("23505".equals(ex.getSQLState())) {
                response.sendRedirect(
                        rutaEditar + "?id=" + proveedorId
                        + "&error=duplicado");
                return;
            }

            getServletContext().log(
                    "Error al actualizar el proveedor", ex);

            response.sendRedirect(
                    rutaEditar + "?id=" + proveedorId
                    + "&error=general");
        }
    }

    private String limpiar(String valor) {
        return valor == null ? "" : valor.trim();
    }
}
