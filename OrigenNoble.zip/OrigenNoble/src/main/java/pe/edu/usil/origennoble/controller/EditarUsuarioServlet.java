
package pe.edu.usil.origennoble.controller;

import pe.edu.usil.origennoble.config.ConexionBD;
import pe.edu.usil.origennoble.repository.UsuarioRepository;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet(name = "EditarUsuarioServlet",
            urlPatterns = {"/editarUsuarioServlet"})
public class EditarUsuarioServlet extends HttpServlet {

    private UsuarioRepository usuarioRepository;

    @Override
    public void init() throws ServletException {
        usuarioRepository = new UsuarioRepository();
    }

    private Integer obtenerAdminId(
            HttpServletRequest request,
            HttpServletResponse response) throws IOException {

        HttpSession sesion = request.getSession(false);

        if (sesion == null
                || !(sesion.getAttribute("usuarioId") instanceof Number)) {
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return null;
        }

        int adminId = ((Number) sesion.getAttribute("usuarioId")).intValue();

        try {
            if (!usuarioRepository.esAdministrador(adminId)) {
                response.sendError(
                    HttpServletResponse.SC_FORBIDDEN,
                    "No tienes permisos para editar usuarios."
                );
                return null;
            }

            return adminId;

        } catch (SQLException e) {
            log("Error al verificar permisos.", e);
            response.sendError(
                HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                "No se pudieron verificar los permisos."
            );
            return null;
        }
    }

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        if (obtenerAdminId(request, response) == null) {
            return;
        }

        String idTexto = request.getParameter("id");

        try {
            int id = Integer.parseInt(idTexto);

            String sqlUsuario = """
                SELECT u.usuario_id, u.nombre_usuario, u.email,
                       u.rol_id, r.nombre_rol
                FROM usuarios u
                JOIN roles r ON u.rol_id = r.rol_id
                WHERE u.usuario_id = ?
                """;

            Map<String, Object> usuario = null;
            List<Map<String, Object>> roles = new ArrayList<>();

            try (Connection conexion = ConexionBD.obtenerConexion()) {

                try (PreparedStatement ps =
                        conexion.prepareStatement(sqlUsuario)) {

                    ps.setInt(1, id);

                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            usuario = new HashMap<>();
                            usuario.put("id", rs.getInt("usuario_id"));
                            usuario.put("nombre",
                                    rs.getString("nombre_usuario"));
                            usuario.put("email", rs.getString("email"));
                            usuario.put("rolId", rs.getInt("rol_id"));
                            usuario.put("rol",
                                    rs.getString("nombre_rol"));
                        }
                    }
                }

                String sqlRoles = """
                    SELECT rol_id, nombre_rol
                    FROM roles
                    WHERE estado = 'activo'
                    ORDER BY nombre_rol
                    """;

                try (PreparedStatement ps =
                        conexion.prepareStatement(sqlRoles);
                     ResultSet rs = ps.executeQuery()) {

                    while (rs.next()) {
                        Map<String, Object> rol = new HashMap<>();
                        rol.put("id", rs.getInt("rol_id"));
                        rol.put("nombre", rs.getString("nombre_rol"));
                        roles.add(rol);
                    }
                }
            }

            if (usuario == null) {
                response.sendError(
                    HttpServletResponse.SC_NOT_FOUND,
                    "El usuario no existe."
                );
                return;
            }

            request.setAttribute("usuario", usuario);
            request.setAttribute("roles", roles);

            request.getRequestDispatcher("/editarUsuario.jsp")
                   .forward(request, response);

        } catch (NumberFormatException e) {
            response.sendError(
                HttpServletResponse.SC_BAD_REQUEST,
                "El identificador no es válido."
            );
        } catch (SQLException e) {
            log("Error al cargar el formulario de edición.", e);
            response.sendError(
                HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                "No se pudo cargar el usuario."
            );
        }
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        if (obtenerAdminId(request, response) == null) {
            return;
        }

        try {
            int id = Integer.parseInt(request.getParameter("id"));
            int rolId = Integer.parseInt(request.getParameter("rolId"));

            String nombre = request.getParameter("nombreUsuario");
            String email = request.getParameter("email");

            if (nombre == null || email == null
                    || nombre.trim().isEmpty()
                    || email.trim().isEmpty()
                    || nombre.length() > 100
                    || email.length() > 254
                    || !email.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) {

                response.sendRedirect(
                    request.getContextPath()
                    + "/editarUsuarioServlet?id=" + id + "&error=datos"
                );
                return;
            }

            usuarioRepository.actualizarUsuario(
                id, nombre.trim(), email.trim(), rolId
            );

            response.sendRedirect(
                request.getContextPath()
                + "/usuariosServlet?edicion=exitosa"
            );

        } catch (NumberFormatException e) {
            response.sendError(
                HttpServletResponse.SC_BAD_REQUEST,
                "El identificador o el rol no es válido."
            );
        } catch (IllegalArgumentException e) {
            response.sendError(
                HttpServletResponse.SC_BAD_REQUEST,
                "Los datos enviados no son válidos."
            );
        } catch (SQLException e) {
            log("Error al actualizar el usuario.", e);

            if ("23505".equals(e.getSQLState())) {
                response.sendRedirect(
                    request.getContextPath()
                    + "/usuariosServlet?error=duplicado"
                );
            } else {
                response.sendError(
                    HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "No se pudo actualizar el usuario."
                );
            }
        }
    }
}
