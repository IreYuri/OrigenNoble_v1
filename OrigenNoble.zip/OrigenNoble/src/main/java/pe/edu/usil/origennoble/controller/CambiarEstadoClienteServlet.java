
package pe.edu.usil.origennoble.controller;

import java.io.IOException;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import pe.edu.usil.origennoble.repository.ClienteRepository;
import pe.edu.usil.origennoble.repository.UsuarioRepository;

@WebServlet(
    name = "CambiarEstadoClienteServlet",
    urlPatterns = {"/cambiarEstadoClienteServlet"}
)
public class CambiarEstadoClienteServlet extends HttpServlet {

    private final ClienteRepository clienteRepository =
        new ClienteRepository();

    private final UsuarioRepository usuarioRepository =
        new UsuarioRepository();

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String rutaClientes =
            request.getContextPath() + "/clientesServlet";

        HttpSession session = request.getSession(false);

        // Verificar que el usuario haya iniciado sesión.
        if (session == null
                || session.getAttribute("usuarioId") == null) {
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return;
        }

        // Verificar permisos de administrador.
        try {
            int usuarioId = Integer.parseInt(
                session.getAttribute("usuarioId").toString()
            );

            if (!usuarioRepository.esAdministrador(usuarioId)) {
                response.sendError(HttpServletResponse.SC_FORBIDDEN);
                return;
            }

        } catch (SQLException | NumberFormatException ex) {
            throw new ServletException(
                "No se pudieron verificar los permisos.", ex
            );
        }

        String idTexto = request.getParameter("clienteId");
        String estado = request.getParameter("estado");

        int clienteId;

        try {
            clienteId = Integer.parseInt(idTexto);

            if (clienteId <= 0) {
                response.sendRedirect(rutaClientes + "?error=noencontrado");
                return;
            }

        } catch (NumberFormatException ex) {
            response.sendRedirect(rutaClientes + "?error=noencontrado");
            return;
        }

        // Solo se permiten estos dos estados.
        if (!"activo".equals(estado) && !"inactivo".equals(estado)) {
            response.sendRedirect(rutaClientes + "?error=datos");
            return;
        }

        try {
            clienteRepository.cambiarEstadoCliente(clienteId, estado);

            response.sendRedirect(rutaClientes + "?mensaje=estado");

        } catch (IllegalArgumentException ex) {
            response.sendRedirect(rutaClientes + "?error=datos");

        } catch (SQLException ex) {
            getServletContext().log(
                "Error al cambiar el estado del cliente " + clienteId,
                ex
            );

            response.sendRedirect(rutaClientes + "?error=general");
        }
    }
}
