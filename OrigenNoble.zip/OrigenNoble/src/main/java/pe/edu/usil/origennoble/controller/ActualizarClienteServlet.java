
package pe.edu.usil.origennoble.servlet;

import java.io.IOException;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import pe.edu.usil.origennoble.model.Cliente;
import pe.edu.usil.origennoble.repository.ClienteRepository;
import pe.edu.usil.origennoble.repository.UsuarioRepository;

@WebServlet(name = "ActualizarClienteServlet",
            urlPatterns = {"/actualizarClienteServlet"})
public class ActualizarClienteServlet extends HttpServlet {

    private final ClienteRepository clienteRepository = new ClienteRepository();
    private final UsuarioRepository usuarioRepository = new UsuarioRepository();

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String rutaClientes =
            request.getContextPath() + "/clientesServlet";

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("usuarioId") == null) {
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return;
        }

        int usuarioId;

        try {
            usuarioId = Integer.parseInt(
                session.getAttribute("usuarioId").toString()
            );

            if (!usuarioRepository.esAdministrador(usuarioId)) {
                response.sendError(HttpServletResponse.SC_FORBIDDEN);
                return;
            }
        } catch (SQLException | NumberFormatException ex) {
            throw new ServletException("No se pudieron verificar los permisos.", ex);
        }

        String idTexto = request.getParameter("clienteId");
        String tipoDocumento = limpiar(request.getParameter("tipoDocumento"));
        String numeroDocumento = limpiar(request.getParameter("numeroDocumento"));
        String nombres = limpiar(request.getParameter("nombres"));
        String apellidos = limpiar(request.getParameter("apellidos"));
        String razonSocial = limpiar(request.getParameter("razonSocial"));
        String telefono = limpiar(request.getParameter("telefono"));
        String email = limpiar(request.getParameter("email"));
        String direccion = limpiar(request.getParameter("direccion"));

        int clienteId;

        try {
            clienteId = Integer.parseInt(idTexto);
            if (clienteId <= 0) {
                response.sendRedirect(rutaClientes + "?error=noencontrado");
                return;
            }
        } catch (NumberFormatException ex) {
            response.sendRedirect(rutaClientes + "?error=noencontrado");
            return;
        }

        // El documento es obligatorio y debe respetar las opciones de la tabla.
        if (numeroDocumento.isEmpty()
                || !(tipoDocumento.isEmpty()
                    || tipoDocumento.equals("DNI")
                    || tipoDocumento.equals("RUC")
                    || tipoDocumento.equals("CE")
                    || tipoDocumento.equals("OTRO"))
                || (nombres.isEmpty() && razonSocial.isEmpty())
                || excede(tipoDocumento, 20)
                || excede(numeroDocumento, 20)
                || excede(nombres, 100)
                || excede(apellidos, 100)
                || excede(razonSocial, 150)
                || excede(telefono, 20)
                || excede(email, 150)
                || excede(direccion, 200)
                || (!email.isEmpty()
                    && !email.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$"))) {

            response.sendRedirect(
                request.getContextPath()
                + "/editarClienteServlet?id=" + clienteId + "&error=datos"
            );
            return;
        }

        try {
            Cliente cliente = clienteRepository.buscarPorId(clienteId);

            if (cliente == null) {
                response.sendRedirect(rutaClientes + "?error=noencontrado");
                return;
            }

            cliente.setTipoDocumento(nuloSiVacio(tipoDocumento));
            cliente.setNumeroDocumento(numeroDocumento);
            cliente.setNombres(nuloSiVacio(nombres));
            cliente.setApellidos(nuloSiVacio(apellidos));
            cliente.setRazonSocial(nuloSiVacio(razonSocial));
            cliente.setTelefono(nuloSiVacio(telefono));
            cliente.setEmail(nuloSiVacio(email));
            cliente.setDireccion(nuloSiVacio(direccion));

            clienteRepository.actualizarCliente(cliente);

            response.sendRedirect(rutaClientes + "?mensaje=actualizado");

        } catch (SQLException ex) {
            // PostgreSQL: 23505 = violación de restricción UNIQUE.
            if ("23505".equals(ex.getSQLState())) {
                response.sendRedirect(
                    request.getContextPath()
                    + "/editarClienteServlet?id=" + clienteId
                    + "&error=duplicado"
                );
            } else {
                getServletContext().log(
                    "Error al actualizar el cliente " + clienteId, ex
                );

                response.sendRedirect(
                    request.getContextPath()
                    + "/editarClienteServlet?id=" + clienteId
                    + "&error=general"
                );
            }
        }
    }

    private String limpiar(String valor) {
        return valor == null ? "" : valor.trim();
    }

    private boolean excede(String valor, int maximo) {
        return valor.length() > maximo;
    }

    private String nuloSiVacio(String valor) {
        return valor == null || valor.isEmpty() ? null : valor;
    }
}
