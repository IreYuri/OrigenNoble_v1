/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.usil.origennoble.repository;

/**
 *
 * @author snay-
 */

import pe.edu.usil.origennoble.config.ConexionBD;
import pe.edu.usil.origennoble.model.Cliente;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

public class ClienteRepository {

    public List<Cliente> listarClientes() throws SQLException {
        List<Cliente> clientes = new ArrayList<>();

        String sql = """
            SELECT cliente_id, tipo_documento, numero_documento,
                   nombres, apellidos, razon_social, telefono,
                   email, direccion, estado, fecha_creacion
            FROM clientes
            ORDER BY cliente_id DESC
            """;

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                clientes.add(mapearCliente(rs));
            }
        }

        return clientes;
    }

    public Cliente buscarPorId(int clienteId) throws SQLException {
        String sql = """
            SELECT cliente_id, tipo_documento, numero_documento,
                   nombres, apellidos, razon_social, telefono,
                   email, direccion, estado, fecha_creacion
            FROM clientes
            WHERE cliente_id = ?
            """;

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, clienteId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapearCliente(rs);
                }
            }
        }

        return null;
    }

    public List<Cliente> buscarClientes(String termino)
            throws SQLException {

        List<Cliente> clientes = new ArrayList<>();

        String sql = """
            SELECT cliente_id, tipo_documento, numero_documento,
                   nombres, apellidos, razon_social, telefono,
                   email, direccion, estado, fecha_creacion
            FROM clientes
            WHERE COALESCE(nombres, '') ILIKE ?
               OR COALESCE(apellidos, '') ILIKE ?
               OR COALESCE(razon_social, '') ILIKE ?
               OR COALESCE(numero_documento, '') ILIKE ?
            ORDER BY cliente_id DESC
            """;

        String filtro = "%" + (termino == null ? "" : termino.trim()) + "%";

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            for (int i = 1; i <= 4; i++) {
                ps.setString(i, filtro);
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    clientes.add(mapearCliente(rs));
                }
            }
        }

        return clientes;
    }

    public int registrarCliente(Cliente cliente) throws SQLException {
        validarCliente(cliente);

        String sql = """
            INSERT INTO clientes (
                tipo_documento, numero_documento, nombres,
                apellidos, razon_social, telefono, email,
                direccion, estado
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'activo')
            """;

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement ps = conn.prepareStatement(
                     sql, Statement.RETURN_GENERATED_KEYS)) {

            establecerDatos(ps, cliente, false);

            int filas = ps.executeUpdate();

            if (filas == 0) {
                throw new SQLException("No se pudo registrar el cliente.");
            }

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }

        throw new SQLException(
                "El cliente se registró, pero no se obtuvo su identificador.");
    }

    public boolean actualizarCliente(Cliente cliente) throws SQLException {
        validarCliente(cliente);

        if (cliente.getClienteId() <= 0) {
            throw new SQLException("El identificador del cliente no es válido.");
        }

        String sql = """
            UPDATE clientes
            SET tipo_documento = ?,
                numero_documento = ?,
                nombres = ?,
                apellidos = ?,
                razon_social = ?,
                telefono = ?,
                email = ?,
                direccion = ?
            WHERE cliente_id = ?
            """;

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            establecerDatos(ps, cliente, false);
            ps.setInt(9, cliente.getClienteId());

            return ps.executeUpdate() > 0;
        }
    }

    public boolean cambiarEstadoCliente(
            int clienteId, String nuevoEstado) throws SQLException {

        if (clienteId <= 0) {
            throw new SQLException("El identificador del cliente no es válido.");
        }

        if (!"activo".equals(nuevoEstado)
                && !"inactivo".equals(nuevoEstado)) {
            throw new SQLException("El estado indicado no es válido.");
        }

        String sql = """
            UPDATE clientes
            SET estado = ?
            WHERE cliente_id = ?
            """;

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, nuevoEstado);
            ps.setInt(2, clienteId);

            return ps.executeUpdate() > 0;
        }
    }

    private void validarCliente(Cliente cliente) throws SQLException {
        if (cliente == null) {
            throw new SQLException("Los datos del cliente son obligatorios.");
        }

        String tipo = limpiar(cliente.getTipoDocumento());
        String numero = limpiar(cliente.getNumeroDocumento());
        String nombres = limpiar(cliente.getNombres());
        String apellidos = limpiar(cliente.getApellidos());
        String razonSocial = limpiar(cliente.getRazonSocial());

        if (tipo != null
                && !tipo.equals("DNI")
                && !tipo.equals("RUC")
                && !tipo.equals("CE")
                && !tipo.equals("OTRO")) {
            throw new SQLException("El tipo de documento no es válido.");
        }

        if (numero != null && numero.length() > 20) {
            throw new SQLException("El número de documento es demasiado largo.");
        }

        if (nombres != null && nombres.length() > 100) {
            throw new SQLException("Los nombres superan los 100 caracteres.");
        }

        if (apellidos != null && apellidos.length() > 100) {
            throw new SQLException("Los apellidos superan los 100 caracteres.");
        }

        if (razonSocial != null && razonSocial.length() > 150) {
            throw new SQLException("La razón social supera los 150 caracteres.");
        }

        if (tipo != null && numero == null) {
            throw new SQLException(
                    "Ingresa el número del documento seleccionado.");
        }

        if (numero != null && tipo == null) {
            throw new SQLException(
                    "Selecciona el tipo de documento.");
        }

        if ((nombres == null || apellidos == null)
                && razonSocial == null) {
            throw new SQLException(
                    "Ingresa los nombres y apellidos del cliente "
                    + "o su razón social.");
        }

        validarLongitud(cliente.getTelefono(), 20, "El teléfono");
        validarLongitud(cliente.getEmail(), 150, "El correo electrónico");
        validarLongitud(cliente.getDireccion(), 200, "La dirección");
    }

    private void validarLongitud(
            String valor, int maximo, String campo) throws SQLException {

        if (valor != null && valor.trim().length() > maximo) {
            throw new SQLException(campo + " supera los " + maximo + " caracteres.");
        }
    }

    private String limpiar(String valor) {
        if (valor == null || valor.trim().isEmpty()) {
            return null;
        }

        return valor.trim();
    }

    private void establecerDatos(
            PreparedStatement ps, Cliente cliente, boolean incluirId)
            throws SQLException {

        establecerTexto(ps, 1, cliente.getTipoDocumento());
        establecerTexto(ps, 2, cliente.getNumeroDocumento());
        establecerTexto(ps, 3, cliente.getNombres());
        establecerTexto(ps, 4, cliente.getApellidos());
        establecerTexto(ps, 5, cliente.getRazonSocial());
        establecerTexto(ps, 6, cliente.getTelefono());
        establecerTexto(ps, 7, cliente.getEmail());
        establecerTexto(ps, 8, cliente.getDireccion());
    }

    private void establecerTexto(
            PreparedStatement ps, int indice, String valor)
            throws SQLException {

        String limpio = limpiar(valor);

        if (limpio == null) {
            ps.setNull(indice, Types.VARCHAR);
        } else {
            ps.setString(indice, limpio);
        }
    }

    private Cliente mapearCliente(ResultSet rs) throws SQLException {
        Cliente cliente = new Cliente();

        cliente.setClienteId(rs.getInt("cliente_id"));
        cliente.setTipoDocumento(rs.getString("tipo_documento"));
        cliente.setNumeroDocumento(rs.getString("numero_documento"));
        cliente.setNombres(rs.getString("nombres"));
        cliente.setApellidos(rs.getString("apellidos"));
        cliente.setRazonSocial(rs.getString("razon_social"));
        cliente.setTelefono(rs.getString("telefono"));
        cliente.setEmail(rs.getString("email"));
        cliente.setDireccion(rs.getString("direccion"));
        cliente.setEstado(rs.getString("estado"));

        Timestamp fecha = rs.getTimestamp("fecha_creacion");
        if (fecha != null) {
            cliente.setFechaCreacion(
                    fecha.toInstant().atOffset(OffsetDateTime.now().getOffset()));
        }

        return cliente;
    }
    
    
    

}
