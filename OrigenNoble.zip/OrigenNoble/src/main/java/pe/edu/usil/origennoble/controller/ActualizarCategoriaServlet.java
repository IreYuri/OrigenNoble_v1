
package pe.edu.usil.origennoble.controller;

import pe.edu.usil.origennoble.model.Categoria;
import pe.edu.usil.origennoble.repository.CategoriaRepository;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/actualizarCategoriaServlet")
public class ActualizarCategoriaServlet extends HttpServlet {

    private final CategoriaRepository categoriaRepository =
            new CategoriaRepository();

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession(false);

        if (session == null ||
                session.getAttribute("usuarioId") == null) {
            response.sendRedirect(
                    request.getContextPath() + "/login.jsp");
            return;
        }

        String idTexto = request.getParameter("categoriaId");
        String nombre = request.getParameter("nombre");
        String descripcion = request.getParameter("descripcion");

        try {
            if (idTexto == null || nombre == null ||
                    nombre.trim().isEmpty()) {
                response.sendRedirect(
                        request.getContextPath()
                        + "/categoriasServlet?error=datos");
                return;
            }

            Categoria categoria = new Categoria();
            categoria.setCategoriaId(Integer.parseInt(idTexto));
            categoria.setNombre(nombre.trim());
            categoria.setDescripcion(
                    descripcion == null || descripcion.trim().isEmpty()
                    ? null : descripcion.trim());

            boolean actualizado =
                    categoriaRepository.actualizarCategoria(categoria);

            if (actualizado) {
                response.sendRedirect(
                        request.getContextPath()
                        + "/categoriasServlet?exito=actualizacion");
            } else {
                response.sendRedirect(
                        request.getContextPath()
                        + "/categoriasServlet?error=actualizacion");
            }

        } catch (NumberFormatException e) {
            response.sendRedirect(
                    request.getContextPath()
                    + "/categoriasServlet?error=datos");
        } catch (Exception e) {
            throw new ServletException(
                    "No se pudo actualizar la categoría.", e);
        }
    }
}
