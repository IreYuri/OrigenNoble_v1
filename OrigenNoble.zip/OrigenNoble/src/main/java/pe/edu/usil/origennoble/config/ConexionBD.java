
package pe.edu.usil.origennoble.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {

    private static final String URL =
            System.getenv("ORIGENNOBLE_DB_URL");

    private static final String USUARIO =
            System.getenv("ORIGENNOBLE_DB_USER");

    private static final String CLAVE =
            System.getenv("ORIGENNOBLE_DB_PASSWORD");

    private ConexionBD() {
    }

    public static Connection getConnection() throws SQLException {
        return obtenerConexion();
    }

    public static Connection obtenerConexion() throws SQLException {

        if (URL == null || URL.isBlank()
                || USUARIO == null || USUARIO.isBlank()
                || CLAVE == null || CLAVE.isBlank()) {

            throw new SQLException(
                    "Faltan las variables de entorno de la base de datos."
            );
        }

        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException(
                    "No se encuentra el controlador JDBC de PostgreSQL en la aplicación.",
                    e
            );
        }

        return DriverManager.getConnection(URL, USUARIO, CLAVE);
    }
}
