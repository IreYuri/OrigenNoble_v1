
package pe.edu.usil.origennoble.controller;

import java.io.IOException;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import pe.edu.usil.origennoble.model.Proveedor;
import pe.edu.usil.origennoble.repository.ProveedorRepository;
import pe.edu.usil.origennoble.repository.UsuarioRepository;

@WebServlet(
    name = "RegistroProveedorServlet",
    urlPatterns = {"/registroProveedorServlet"}
)
public class RegistroProveedorServlet extends HttpServlet {

    private final ProveedorRepository proveedorRepository =
            new ProveedorRepository();

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String rutaProveedores =
                request.getContextPath() + "/proveedoresServlet";

        HttpSession session = request.getSession(false);

        if (session == null
                || session.getAttribute("usuarioId") == null) {
            response.sendRedirect(
                    request.getContextPath() + "/login.jsp");
            return;
        }

        Object usuarioSesion = session.getAttribute("usuarioId");

        int usuarioId;
        try {
            usuarioId = Integer.parseInt(usuarioSesion.toString());
        } catch (NumberFormatException ex) {
            response.sendError(
                    HttpServletResponse.SC_UNAUTHORIZED);
            return;
        }

        try {
            UsuarioRepository usuarioRepository = new UsuarioRepository();

            if (!usuarioRepository.esAdministrador(usuarioId)) {
                response.sendError(
                        HttpServletResponse.SC_FORBIDDEN,
                        "No tienes permiso para registrar proveedores.");
                return;
            }
        } catch (SQLException ex) {
            getServletContext().log(
                    "Error al verificar los permisos del usuario", ex);
            response.sendRedirect(rutaProveedores + "?error=general");
            return;
        }

        String razonSocial = limpiar(
                request.getParameter("razonSocial"));
        String ruc = limpiar(request.getParameter("ruc"));
        String telefono = limpiar(request.getParameter("telefono"));
        String direccion = limpiar(request.getParameter("direccion"));
        String correo = limpiar(request.getParameter("correo"));

        if (razonSocial.isEmpty()
                || ruc.isEmpty()
                || !ruc.matches("[0-9]{11}")
                || razonSocial.length() > 150
                || telefono.length() > 20
                || direccion.length() > 200
                || correo.length() > 150
                || (!correo.isEmpty()
                    && !correo.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$"))) {

            response.sendRedirect(
                    request.getContextPath()
                    + "/registroProveedor.jsp?error=datos");
            return;
        }

        Proveedor proveedor = new Proveedor();
        proveedor.setRazonSocial(razonSocial);
        proveedor.setRuc(ruc);
        proveedor.setTelefono(telefono.isEmpty() ? null : telefono);
        proveedor.setDireccion(direccion.isEmpty() ? null : direccion);
        proveedor.setCorreo(correo.isEmpty() ? null : correo);

        try {
            boolean registrado =
                    proveedorRepository.registrarProveedor(proveedor);

            if (registrado) {
                response.sendRedirect(
                        rutaProveedores + "?mensaje=registrado");
            } else {
                response.sendRedirect(
                        request.getContextPath()
                        + "/registroProveedor.jsp?error=general");
            }

        } catch (SQLException ex) {

            if ("23505".equals(ex.getSQLState())) {
                response.sendRedirect(
                        request.getContextPath()
                        + "/registroProveedor.jsp?error=duplicado");
                return;
            }

            getServletContext().log(
                    "Error al registrar un proveedor", ex);

            response.sendRedirect(
                    request.getContextPath()
                    + "/registroProveedor.jsp?error=general");
        }
    }

    private String limpiar(String valor) {
        return valor == null ? "" : valor.trim();
    }
}
