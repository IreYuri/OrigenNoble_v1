
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="pe.edu.usil.origennoble.model.Cliente"%>

<%!
    private String escaparHTML(String texto) {
        if (texto == null) return "";
        return texto.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }
%>

<%
    if (session.getAttribute("usuarioId") == null) {
        response.sendRedirect(request.getContextPath() + "/index.jsp");
        return;
    }

    List<Cliente> clientes =
        (List<Cliente>) request.getAttribute("clientes");

    String busqueda = (String) request.getAttribute("busqueda");
    if (busqueda == null) busqueda = "";

    String mensaje = request.getParameter("mensaje");
    String error = request.getParameter("error");
%>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clientes | OrigenNoble</title>

    <style>
        :root {
            --cafe: #49352a;
            --crema: #faf6ef;
            --oliva: #78805a;
            --borde: #e8dfd3;
            --texto: #332a25;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: var(--crema);
            color: var(--texto);
        }

        header {
            background: var(--cafe);
            color: white;
            padding: 22px 5%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
            flex-wrap: wrap;
        }

        header h1 { margin: 0; font-size: 24px; }
        header p { margin: 6px 0 0; color: #eee1d4; font-size: 13px; }

        .contenedor {
            max-width: 1400px;
            margin: 30px auto;
            padding: 0 24px;
        }

        .superior {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 16px;
            margin-bottom: 24px;
        }

        .superior h2 { margin: 0 0 8px; font-size: 26px; }
        .subtitulo { color: #776b61; margin: 0; font-size: 14px; }

        .boton {
            display: inline-block;
            border: none;
            border-radius: 8px;
            padding: 10px 14px;
            text-decoration: none;
            font-size: 13px;
            cursor: pointer;
            font-weight: bold;
            text-align: center;
        }

        .boton-principal { background: var(--oliva); color: white; }
        .boton-principal:hover { background: #626b46; }

        .boton-secundario {
            background: white;
            color: var(--cafe);
            border: 1px solid var(--borde);
        }

        .panel {
            background: white;
            border: 1px solid var(--borde);
            border-radius: 12px;
            padding: 22px;
            margin-bottom: 20px;
        }

        .buscador { display: flex; gap: 10px; flex-wrap: wrap; }

        .buscador input {
            flex: 1;
            min-width: 220px;
            padding: 12px;
            border: 1px solid #d9cec1;
            border-radius: 8px;
            font-size: 14px;
        }

        .tabla-contenedor { overflow-x: auto; }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
            white-space: nowrap;
        }

        th {
            background: #f5efe7;
            color: var(--cafe);
            text-align: left;
            padding: 14px 12px;
        }

        td { padding: 14px 12px; border-bottom: 1px solid #eee7de; }
        tbody tr:hover { background: #fdfbf8; }

        .estado {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }

        .activo { background: #e5f2e4; color: #32633a; }
        .inactivo { background: #f8e6e1; color: #963f32; }

        .alerta {
            padding: 13px 15px;
            border-radius: 8px;
            margin-bottom: 18px;
            font-size: 14px;
        }

        .exito { background: #e5f2e4; color: #32633a; }
        .error { background: #f8e6e1; color: #963f32; }

        .vacio { padding: 35px; text-align: center; color: #776b61; }

        footer {
            text-align: center;
            color: #82766b;
            font-size: 12px;
            padding: 24px;
        }
        

        .boton-activar {
            background: #e5f2e4;
            color: #32633a;
            border: 1px solid #c8e2c5;
        }

        .boton-desactivar {
            background: #f8e6e1;
            color: #963f32;
            border: 1px solid #efd0c7;
        }

        .form-estado {
            display: inline;
            margin: 0;
        }

        .acciones-cliente {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        
        

        @media (max-width: 600px) {
            .contenedor { padding: 0 12px; margin-top: 20px; }
            .panel { padding: 14px; }
            header { padding: 18px; }
        }
    </style>
</head>

<body>
<header>
    <div>
        <h1>OrigenNoble</h1>
        <p>Gestión comercial y administrativa</p>
    </div>

    <a class="boton boton-secundario"
       href="<%=request.getContextPath()%>/dashboard.jsp">
        Volver al inicio
    </a>
</header>

<main class="contenedor">
    <section class="superior">
        <div>
            <h2>Gestión de clientes</h2>
            <p class="subtitulo">
                Consulta y administra la información de tus clientes.
            </p>
        </div>

        <a class="boton boton-principal"
           href="<%=request.getContextPath()%>/registroCliente.jsp">
            + Registrar cliente
        </a>
    </section>

    <% if ("registrado".equals(mensaje)) { %>
        <div class="alerta exito">Cliente registrado correctamente.</div>
    <% } %>

    <% if ("actualizado".equals(mensaje)) { %>
        <div class="alerta exito">Cliente actualizado correctamente.</div>
    <% } %>

    <% if ("estado".equals(mensaje)) { %>
        <div class="alerta exito">Estado del cliente actualizado.</div>
    <% } %>

    <% if ("duplicado".equals(error)) { %>
        <div class="alerta error">El número de documento ya está registrado.</div>
    <% } else if ("datos".equals(error)) { %>
        <div class="alerta error">Revisa los datos ingresados e inténtalo nuevamente.</div>
    <% } else if ("general".equals(error)) { %>
        <div class="alerta error">No se pudo completar la operación. Inténtalo nuevamente.</div>
    <% } else if ("noencontrado".equals(error)) { %>
        <div class="alerta error">No se encontró el cliente solicitado.</div>
    <% } %>

    <section class="panel">
        <form class="buscador"
              action="<%=request.getContextPath()%>/clientesServlet"
              method="get">

            <input type="search"
                   name="busqueda"
                   value="<%=escaparHTML(busqueda)%>"
                   placeholder="Buscar por nombre, razón social o documento">

            <button class="boton boton-principal" type="submit">Buscar</button>

            <a class="boton boton-secundario"
               href="<%=request.getContextPath()%>/clientesServlet">
                Limpiar
            </a>
        </form>
    </section>

    <section class="panel">
        <div class="tabla-contenedor">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Documento</th>
                        <th>Cliente</th>
                        <th>Teléfono</th>
                        <th>Correo</th>
                        <th>Dirección</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>

                <tbody>
                <% if (clientes != null && !clientes.isEmpty()) {
                    for (Cliente c : clientes) {
                        String nombreCliente;

                        if (c.getRazonSocial() != null
                                && !c.getRazonSocial().trim().isEmpty()) {
                            nombreCliente = c.getRazonSocial();
                        } else {
                            nombreCliente =
                                (c.getNombres() == null ? "" : c.getNombres())
                                + " "
                                + (c.getApellidos() == null ? "" : c.getApellidos());
                        }

                        String estadoCliente =
                            "activo".equals(c.getEstado()) ? "activo" : "inactivo";
                %>
                    <tr>
                        <td><%=c.getClienteId()%></td>
                        <td>
                            <%=c.getTipoDocumento() == null
                                ? "—" : escaparHTML(c.getTipoDocumento())%>
                            <br>
                            <%=c.getNumeroDocumento() == null
                                ? "—" : escaparHTML(c.getNumeroDocumento())%>
                        </td>
                        <td><%=escaparHTML(nombreCliente.trim())%></td>
                        <td><%=c.getTelefono() == null
                                ? "—" : escaparHTML(c.getTelefono())%></td>
                        <td><%=c.getEmail() == null
                                ? "—" : escaparHTML(c.getEmail())%></td>
                        <td><%=c.getDireccion() == null
                                ? "—" : escaparHTML(c.getDireccion())%></td>
                        <td>
                            <span class="estado <%=estadoCliente%>">
                                <%=escaparHTML(c.getEstado())%>
                            </span>
                        </td>
                        
                        <td>
                            <div class="acciones-cliente">

                                <a class="boton boton-secundario"
                                   href="<%=request.getContextPath()%>/editarClienteServlet?id=<%=c.getClienteId()%>">
                                    Editar
                                </a>

                                <form class="form-estado"
                                      action="<%=request.getContextPath()%>/cambiarEstadoClienteServlet"
                                      method="post"
                                      onsubmit="return confirm('¿Estás seguro de cambiar el estado de este cliente?');">

                                    <input type="hidden"
                                           name="clienteId"
                                           value="<%=c.getClienteId()%>">

                                    <% if ("activo".equals(c.getEstado())) { %>

                                        <input type="hidden" name="estado" value="inactivo">

                                        <button type="submit"
                                                class="boton boton-desactivar">
                                            Desactivar
                                        </button>

                                    <% } else { %>

                                        <input type="hidden" name="estado" value="activo">

                                        <button type="submit"
                                                class="boton boton-activar">
                                            Activar
                                        </button>

                                    <% } %>

                                </form>
                            </div>
                        </td>

                    </tr>
                <%  }
                   } else { %>
                    <tr>
                        <td colspan="8" class="vacio">
                            No se encontraron clientes registrados.
                        </td>
                    </tr>
                <% } %>
                </tbody>
            </table>
        </div>
    </section>
</main>

<footer>OrigenNoble · Sistema de gestión</footer>
</body>
</html>
