<%-- 
    Document   : registroUsuario
    Created on : 26 oct. 2026, 01:16:03
    Author     : snay-
--%>


<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="java.util.Map"%>
<%
    if (session.getAttribute("usuarioId") == null) {
        response.sendRedirect(request.getContextPath() + "/index.jsp");
        return;
    }

    List<Map<String, Object>> roles =
        (List<Map<String, Object>>) request.getAttribute("roles");

    String error = request.getParameter("error");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuevo usuario | OrigenNoble</title>
    <style>
        * { box-sizing: border-box; }

        body {
            margin: 0;
            padding: 35px 18px;
            background: #f7f5ef;
            color: #34271f;
            font-family: Arial, sans-serif;
        }

        .contenedor { max-width: 650px; margin: auto; }

        .volver {
            display: inline-block;
            margin-bottom: 22px;
            color: #657047;
            text-decoration: none;
        }

        .panel {
            background: white;
            padding: 32px;
            border-radius: 16px;
            box-shadow: 0 5px 25px #34271f0d;
        }

        h1 { margin: 0 0 10px; font-size: 29px; }

        .descripcion {
            color: #777;
            margin-bottom: 28px;
            line-height: 1.5;
        }

        .campo { margin-bottom: 20px; }

        label {
            display: block;
            margin-bottom: 8px;
            font-size: 14px;
            font-weight: bold;
        }

        input, select {
            width: 100%;
            padding: 12px 13px;
            border: 1px solid #dedbd2;
            border-radius: 8px;
            background: white;
            color: #34271f;
            font-size: 15px;
        }

        input:focus, select:focus {
            outline: 2px solid #78805a;
            border-color: transparent;
        }

        .ayuda {
            margin-top: 7px;
            color: #888;
            font-size: 12px;
        }

        .error {
            padding: 12px;
            margin-bottom: 20px;
            border-radius: 8px;
            background: #f8e9e5;
            color: #944b3c;
            font-size: 14px;
        }

        .acciones {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            margin-top: 28px;
            flex-wrap: wrap;
        }

        .boton {
            display: inline-block;
            padding: 12px 17px;
            border: none;
            border-radius: 8px;
            text-decoration: none;
            cursor: pointer;
            font-size: 14px;
        }

        .cancelar { background: #eeeae2; color: #34271f; }
        .guardar { background: #78805a; color: white; }

        @media (max-width: 480px) {
            .panel { padding: 22px; }
            .acciones { flex-direction: column; }
            .acciones .boton { text-align: center; }
        }
    </style>
</head>
<body>
<div class="contenedor">

    <a class="volver"
       href="<%= request.getContextPath() %>/usuariosServlet">
        ← Volver a usuarios
    </a>

    <main class="panel">
        <h1>Registrar usuario</h1>
        <p class="descripcion">
            Crea una cuenta para acceder a las funciones autorizadas
            de OrigenNoble.
        </p>

        <% if ("datos".equals(error)) { %>
            <div class="error">
                Revisa los datos ingresados. Verifica el nombre de usuario,
                el correo, la contraseña y el rol seleccionado.
            </div>
        <% } else if ("duplicado".equals(error)) { %>
            <div class="error">
                El nombre de usuario o el correo ya están registrados.
            </div>
        <% } else if ("servidor".equals(error)) { %>
            <div class="error">
                No se pudo registrar la cuenta. Inténtalo nuevamente.
            </div>
        <% } %>

        <% if (roles == null || roles.isEmpty()) { %>
            <div class="error">
                No hay roles activos disponibles. Contacta con administración.
            </div>
        <% } else { %>
        <form method="post"
              action="<%= request.getContextPath() %>/registroUsuarioServlet">

            <div class="campo">
                <label for="nombreUsuario">Nombre de usuario</label>
                <input type="text" id="nombreUsuario"
                       name="nombreUsuario"
                       minlength="3" maxlength="50"
                       pattern="[a-zA-Z0-9._-]{3,50}"
                       autocomplete="username"
                       placeholder="Ej. maria.cafe" required>
                <div class="ayuda">
                    Usa de 3 a 50 letras, números, puntos, guiones
                    o guiones bajos.
                </div>
            </div>

            <div class="campo">
                <label for="email">Correo electrónico</label>
                <input type="email" id="email" name="email"
                       maxlength="150"
                       autocomplete="email"
                       placeholder="usuario@correo.com" required>
            </div>

            <div class="campo">
                <label for="password">Contraseña</label>
                <input type="password" id="password" name="password"
                       minlength="8" maxlength="72"
                       autocomplete="new-password" required>
                <div class="ayuda">
                    Mínimo 8 caracteres. El límite de 72 evita problemas
                    con BCrypt.
                </div>
            </div>

            <div class="campo">
                <label for="rolId">Rol</label>
                <select id="rolId" name="rolId" required>
                    <option value="">Selecciona un rol</option>
                    <% for (Map<String, Object> rol : roles) { %>
                        <option value="<%= rol.get("id") %>">
                            <%= rol.get("nombre") %>
                        </option>
                    <% } %>
                </select>
            </div>

            <div class="acciones">
                <a class="boton cancelar"
                   href="<%= request.getContextPath() %>/usuariosServlet">
                    Cancelar
                </a>
                <button class="boton guardar" type="submit">
                    Registrar usuario
                </button>
            </div>
        </form>
        <% } %>
    </main>
</div>
</body>
</html>
