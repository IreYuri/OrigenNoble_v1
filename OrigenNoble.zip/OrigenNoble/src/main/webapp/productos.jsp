
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="pe.edu.usil.origennoble.model.Producto"%>
<%@page import="pe.edu.usil.origennoble.model.Categoria"%>
<%@page import="pe.edu.usil.origennoble.model.Proveedor"%>

<%
    if (session.getAttribute("usuarioId") == null) {
        response.sendRedirect(request.getContextPath() + "/index.jsp");
        return;
    }

    String contexto = request.getContextPath();

    List<Producto> productos =
            (List<Producto>) request.getAttribute("productos");

    List<Categoria> categorias =
            (List<Categoria>) request.getAttribute("categorias");

    List<Proveedor> proveedores =
            (List<Proveedor>) request.getAttribute("proveedores");

    Producto productoEditar =
            (Producto) request.getAttribute("productoEditar");

    Categoria categoriaEditar =
            (Categoria) request.getAttribute("categoriaEditar");

    boolean editando = productoEditar != null;
    boolean editandoCategoria = categoriaEditar != null;

    String busqueda = request.getParameter("busqueda");
    String exito = request.getParameter("exito");
    String error = request.getParameter("error");

    if (productos == null) productos = new java.util.ArrayList<>();
    if (categorias == null) categorias = new java.util.ArrayList<>();
    if (proveedores == null) proveedores = new java.util.ArrayList<>();
%>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Productos e inventario | OrigenNoble</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 25px;
            background: #f5f3ef;
            color: #302b27;
            font-family: Arial, sans-serif;
        }

        .contenedor {
            max-width: 1250px;
            margin: auto;
        }

        h1, h2 {
            color: #49372b;
        }

        h1 {
            margin-bottom: 8px;
        }

        .subtitulo {
            color: #766b62;
            margin-bottom: 25px;
        }

        .seccion {
            background: white;
            padding: 24px;
            margin: 22px 0;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, .06);
        }

        .formulario-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 16px;
        }

        .campo {
            display: flex;
            flex-direction: column;
            gap: 7px;
        }

        .campo-completo {
            grid-column: 1 / -1;
        }

        label {
            font-weight: bold;
            font-size: 14px;
        }

        input, select, textarea {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #d8d0c8;
            border-radius: 7px;
            font: inherit;
            background: white;
        }

        textarea {
            min-height: 75px;
            resize: vertical;
        }

        .boton {
            display: inline-block;
            padding: 10px 14px;
            border: none;
            border-radius: 7px;
            background: #65452f;
            color: white;
            text-decoration: none;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
            text-align: center;
        }

        .boton:hover {
            background: #4e3525;
        }

        .boton-secundario {
            background: #e7e1db;
            color: #40352d;
        }

        .boton-secundario:hover {
            background: #d8cec4;
        }

        .boton-peligro {
            background: #a63d35;
        }

        .boton-peligro:hover {
            background: #852e28;
        }

        .acciones {
            display: flex;
            align-items: center;
            gap: 7px;
            flex-wrap: wrap;
        }

        .acciones form {
            margin: 0;
        }

        .acciones .boton {
            white-space: nowrap;
        }

        .mensaje {
            padding: 13px 16px;
            border-radius: 7px;
            margin: 15px 0;
        }

        .exito {
            background: #e5f4e8;
            color: #246437;
        }

        .error {
            background: #fbe8e6;
            color: #8b2822;
        }

        .aviso {
            background: #fff3d8;
            color: #79561a;
        }

        .tabla-contenedor {
            width: 100%;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        th, td {
            padding: 12px 10px;
            border-bottom: 1px solid #e9e3dd;
            text-align: left;
            vertical-align: middle;
        }

        th {
            background: #f4f0eb;
            color: #49372b;
            white-space: nowrap;
        }

        .estado {
            display: inline-block;
            padding: 5px 9px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            text-transform: capitalize;
        }

        .activo {
            background: #e1f3e5;
            color: #246437;
        }

        .inactivo {
            background: #f8e3e1;
            color: #8b2822;
        }

        .barra-busqueda {
            display: flex;
            gap: 10px;
            align-items: center;
            margin-top: 15px;
        }

        .barra-busqueda input {
            flex: 1;
        }

        .barra-busqueda form {
            display: flex;
            width: 100%;
            gap: 10px;
        }

        .botones-formulario {
            display: flex;
            gap: 10px;
            align-items: center;
            flex-wrap: wrap;
            margin-top: 8px;
        }

        .sin-resultados {
            text-align: center;
            color: #766b62;
            padding: 22px;
        }

        .volver {
            display: inline-block;
            margin-bottom: 15px;
            color: #65452f;
            text-decoration: none;
            font-weight: bold;
        }

        @media (max-width: 700px) {
            body {
                padding: 12px;
            }

            .seccion {
                padding: 16px;
            }

            .formulario-grid {
                grid-template-columns: 1fr;
            }

            .campo-completo {
                grid-column: auto;
            }

            .barra-busqueda form {
                flex-direction: column;
            }
        }
    </style>
</head>

<body>
<div class="contenedor">

    <a class="volver" href="<%= contexto %>/dashboard.jsp">
        ← Volver al panel principal
    </a>

    <h1>Productos e inventario</h1>
    <p class="subtitulo">
        Administra las categorías, los productos y las existencias de OrigenNoble.
    </p>

    <!-- MENSAJES DEL SISTEMA -->
    <% if ("categoria".equals(exito)) { %>
        <div class="mensaje exito">
            Categoría registrada correctamente.
        </div>
    <% } else if ("categoriaActualizada".equals(exito)) { %>
        <div class="mensaje exito">
            Categoría actualizada correctamente.
        </div>
    <% } else if ("estadoCategoria".equals(exito)) { %>
        <div class="mensaje exito">
            Estado de la categoría actualizado correctamente.
        </div>
    <% } else if ("producto".equals(exito)) { %>
        <div class="mensaje exito">
            Producto registrado correctamente.
        </div>
    <% } else if ("actualizado".equals(exito)) { %>
        <div class="mensaje exito">
            Producto actualizado correctamente.
        </div>
    <% } else if ("estado".equals(exito)) { %>
        <div class="mensaje exito">
            Estado del producto actualizado correctamente.
        </div>
    <% } %>

    <% if ("datos".equals(error)) { %>
        <div class="mensaje error">
            Completa todos los campos obligatorios.
        </div>
    <% } else if ("valores".equals(error)) { %>
        <div class="mensaje error">
            Revisa los valores ingresados. El precio y las cantidades
            no pueden ser negativos.
        </div>
    <% } else if ("categoria".equals(error)) { %>
        <div class="mensaje error">
            No se pudo registrar o actualizar la categoría.
            Verifica que el nombre no esté repetido.
        </div>
    <% } else if ("categoriaNoEncontrada".equals(error)) { %>
        <div class="mensaje error">
            No se encontró la categoría seleccionada.
        </div>
    <% } else if ("estadoCategoria".equals(error)) { %>
        <div class="mensaje error">
            No se pudo cambiar el estado de la categoría.
        </div>
    <% } else if ("guardar".equals(error)) { %>
        <div class="mensaje error">
            No se pudo guardar el producto. Revisa los datos ingresados.
        </div>
    <% } else if ("estado".equals(error)) { %>
        <div class="mensaje error">
            No se pudo cambiar el estado del producto.
        </div>
    <% } else if ("noEncontrado".equals(error)) { %>
        <div class="mensaje error">
            No se encontró el producto seleccionado.
        </div>
    <% } else if ("accion".equals(error)) { %>
        <div class="mensaje error">
            La operación solicitada no es válida.
        </div>
    <% } %>

    <!-- ====================================== -->
    <!-- GESTIÓN DE CATEGORÍAS                  -->
    <!-- ====================================== -->
    <section class="seccion">
        <h2>Gestión de categorías</h2>

        <p>
            Registra las categorías de los productos y administra su estado.
        </p>

        <form action="<%= contexto %>/productosServlet" method="post">
            <input type="hidden" name="accion"
                   value="<%= editandoCategoria
                           ? "actualizarCategoria"
                           : "registrarCategoria" %>">

            <% if (editandoCategoria) { %>
                <input type="hidden" name="categoriaId"
                       value="<%= categoriaEditar.getCategoriaId() %>">
            <% } %>

            <div class="formulario-grid">
                <div class="campo">
                    <label for="nombreCategoria">Nombre *</label>
                    <input type="text"
                           id="nombreCategoria"
                           name="nombreCategoria"
                           maxlength="100"
                           required
                           value="<%= editandoCategoria
                                   ? categoriaEditar.getNombre() : "" %>"
                           placeholder="Ej. Cafés">
                </div>

                <div class="campo">
                    <label for="descripcionCategoria">Descripción</label>
                    <input type="text"
                           id="descripcionCategoria"
                           name="descripcionCategoria"
                           maxlength="250"
                           value="<%= editandoCategoria
                                   && categoriaEditar.getDescripcion() != null
                                   ? categoriaEditar.getDescripcion() : "" %>"
                           placeholder="Descripción de la categoría">
                </div>

                <div class="campo campo-completo">
                    <div class="botones-formulario">
                        <button type="submit" class="boton">
                            <%= editandoCategoria
                                    ? "Guardar cambios"
                                    : "Registrar categoría" %>
                        </button>

                        <% if (editandoCategoria) { %>
                            <a href="<%= contexto %>/productosServlet"
                               class="boton boton-secundario">
                                Cancelar edición
                            </a>
                        <% } %>
                    </div>
                </div>
            </div>
        </form>

        <h3>Categorías registradas</h3>

        <div class="tabla-contenedor">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Descripción</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>

                <tbody>
                <% if (categorias.isEmpty()) { %>
                    <tr>
                        <td colspan="5" class="sin-resultados">
                            No hay categorías registradas.
                        </td>
                    </tr>
                <% } else {
                    for (Categoria c : categorias) {
                        boolean categoriaActiva =
                                "activo".equals(c.getEstado());
                %>
                    <tr>
                        <td><%= c.getCategoriaId() %></td>
                        <td><%= c.getNombre() %></td>
                        <td><%= c.getDescripcion() == null
                                || c.getDescripcion().isBlank()
                                ? "—" : c.getDescripcion() %></td>
                        <td>
                            <span class="estado <%= categoriaActiva
                                    ? "activo" : "inactivo" %>">
                                <%= c.getEstado() %>
                            </span>
                        </td>
                        <td>
                            <div class="acciones">
                                <a class="boton"
                                   href="<%= contexto %>/productosServlet?editarCategoria=<%= c.getCategoriaId() %>">
                                    Editar
                                </a>

                                <form action="<%= contexto %>/productosServlet"
                                      method="post"
                                      onsubmit="return confirm('¿Deseas cambiar el estado de esta categoría?');">

                                    <input type="hidden" name="accion"
                                           value="cambiarEstadoCategoria">

                                    <input type="hidden" name="categoriaId"
                                           value="<%= c.getCategoriaId() %>">

                                    <% if (categoriaActiva) { %>
                                        <input type="hidden" name="estado"
                                               value="inactivo">

                                        <button type="submit"
                                                class="boton boton-peligro">
                                            Desactivar
                                        </button>
                                    <% } else { %>
                                        <input type="hidden" name="estado"
                                               value="activo">

                                        <button type="submit" class="boton">
                                            Activar
                                        </button>
                                    <% } %>
                                </form>
                            </div>
                        </td>
                    </tr>
                <%  }
                   }
                %>
                </tbody>
            </table>
        </div>

        <div class="mensaje aviso">
            Las categorías inactivas no deberían utilizarse para registrar
            productos nuevos. Si una categoría ya está asociada a productos,
            desactivarla no elimina esos registros.
        </div>
    </section>

    <!-- ====================================== -->
    <!-- REGISTRO Y EDICIÓN DE PRODUCTOS        -->
    <!-- ====================================== -->
    <section class="seccion">
        <h2>
            <%= editando ? "Editar producto" : "Registrar producto" %>
        </h2>

        <form action="<%= contexto %>/productosServlet" method="post">
            <input type="hidden" name="accion"
                   value="<%= editando
                           ? "actualizarProducto"
                           : "guardarProducto" %>">

            <% if (editando) { %>
                <input type="hidden" name="productoId"
                       value="<%= productoEditar.getProductoId() %>">
            <% } %>

            <div class="formulario-grid">
                <div class="campo">
                    <label for="nombre">Nombre del producto *</label>
                    <input type="text"
                           id="nombre"
                           name="nombre"
                           maxlength="150"
                           required
                           value="<%= editando
                                   ? productoEditar.getNombre() : "" %>"
                           placeholder="Nombre del producto">
                </div>

                <div class="campo">
                    <label for="categoriaId">Categoría *</label>
                    <select id="categoriaId" name="categoriaId" required>
                        <option value="">Selecciona una categoría</option>

                        <% for (Categoria c : categorias) {
                            if ("activo".equals(c.getEstado())) {
                                boolean seleccionada = editando
                                        && productoEditar.getCategoriaId()
                                        == c.getCategoriaId();
                        %>
                            <option value="<%= c.getCategoriaId() %>"
                                    <%= seleccionada ? "selected" : "" %>>
                                <%= c.getNombre() %>
                            </option>
                        <%  }
                           }
                        %>
                    </select>
                </div>

                <div class="campo">
                    <label for="proveedorId">Proveedor</label>
                    <select id="proveedorId" name="proveedorId">
                        <option value="">Sin proveedor</option>

                        <% for (Proveedor p : proveedores) {
                            if ("activo".equals(p.getEstado())) {
                                boolean seleccionado = editando
                                        && productoEditar.getProveedorId() != null
                                        && productoEditar.getProveedorId()
                                        == p.getProveedorId();
                        %>
                            <option value="<%= p.getProveedorId() %>"
                                    <%= seleccionado ? "selected" : "" %>>
                                <%= p.getRazonSocial() %>
                            </option>
                        <%  }
                           }
                        %>
                    </select>
                </div>

                <div class="campo">
                    <label for="precioVenta">Precio de venta *</label>
                    <input type="number"
                           id="precioVenta"
                           name="precioVenta"
                           min="0"
                           step="0.01"
                           required
                           value="<%= editando
                                   ? productoEditar.getPrecioVenta() : "" %>"
                           placeholder="0.00">
                </div>

                <div class="campo">
                    <label for="stock">Stock *</label>
                    <input type="number"
                           id="stock"
                           name="stock"
                           min="0"
                           step="1"
                           required
                           value="<%= editando
                                   ? productoEditar.getStock() : "0" %>">
                </div>

                <div class="campo">
                    <label for="stockMinimo">Stock mínimo *</label>
                    <input type="number"
                           id="stockMinimo"
                           name="stockMinimo"
                           min="0"
                           step="1"
                           required
                           value="<%= editando
                                   ? productoEditar.getStockMinimo() : "5" %>">
                </div>

                <div class="campo">
                    <label for="unidadMedida">Unidad de medida</label>
                    <input type="text"
                           id="unidadMedida"
                           name="unidadMedida"
                           maxlength="30"
                           value="<%= editando
                                   ? productoEditar.getUnidadMedida()
                                   : "unidad" %>">
                </div>

                <div class="campo campo-completo">
                    <label for="descripcion">Descripción</label>
                    <textarea id="descripcion"
                              name="descripcion"
                              maxlength="250"
                              placeholder="Descripción del producto"><%= editando
                                      && productoEditar.getDescripcion() != null
                                      ? productoEditar.getDescripcion() : "" %></textarea>
                </div>

                <div class="campo campo-completo">
                    <div class="botones-formulario">
                        <button type="submit" class="boton">
                            <%= editando
                                    ? "Guardar cambios"
                                    : "Registrar producto" %>
                        </button>

                        <% if (editando) { %>
                            <a href="<%= contexto %>/productosServlet"
                               class="boton boton-secundario">
                                Cancelar edición
                            </a>
                        <% } %>
                    </div>
                </div>
            </div>
        </form>
    </section>

    <!-- ====================================== -->
    <!-- LISTADO DE PRODUCTOS                   -->
    <!-- ====================================== -->
    <section class="seccion">
        <h2>Productos registrados</h2>

        <div class="barra-busqueda">
            <form action="<%= contexto %>/productosServlet" method="get">
                <input type="text"
                       name="busqueda"
                       value="<%= busqueda == null ? "" : busqueda %>"
                       placeholder="Buscar producto...">

                <button type="submit" class="boton">Buscar</button>

                <a href="<%= contexto %>/productosServlet"
                   class="boton boton-secundario">
                    Limpiar
                </a>
            </form>
        </div>

        <div class="tabla-contenedor">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Producto</th>
                        <th>Categoría</th>
                        <th>Precio</th>
                        <th>Stock</th>
                        <th>Stock mínimo</th>
                        <th>Unidad</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>

                <tbody>
                <% if (productos.isEmpty()) { %>
                    <tr>
                        <td colspan="9" class="sin-resultados">
                            No se encontraron productos.
                        </td>
                    </tr>
                <% } else {
                    for (Producto p : productos) {
                        boolean productoActivo =
                                "activo".equals(p.getEstado());
                %>
                    <tr>
                        <td><%= p.getProductoId() %></td>
                        <td><%= p.getNombre() %></td>
                        <td><%= p.getNombreCategoria() == null
                                ? "—" : p.getNombreCategoria() %></td>
                        <td>S/ <%= p.getPrecioVenta() %></td>
                        <td><%= p.getStock() %></td>
                        <td><%= p.getStockMinimo() %></td>
                        <td><%= p.getUnidadMedida() == null
                                ? "unidad" : p.getUnidadMedida() %></td>
                        <td>
                            <span class="estado <%= productoActivo
                                    ? "activo" : "inactivo" %>">
                                <%= p.getEstado() %>
                            </span>
                        </td>
                        <td>
                            <div class="acciones">
                                <a class="boton"
                                   href="<%= contexto %>/productosServlet?editar=<%= p.getProductoId() %>">
                                    Editar
                                </a>

                                <form action="<%= contexto %>/productosServlet"
                                      method="post"
                                      onsubmit="return confirm('¿Deseas cambiar el estado de este producto?');">

                                    <input type="hidden" name="accion"
                                           value="cambiarEstado">

                                    <input type="hidden" name="productoId"
                                           value="<%= p.getProductoId() %>">

                                    <% if (productoActivo) { %>
                                        <input type="hidden" name="estado"
                                               value="inactivo">

                                        <button type="submit"
                                                class="boton boton-peligro">
                                            Desactivar
                                        </button>
                                    <% } else { %>
                                        <input type="hidden" name="estado"
                                               value="activo">

                                        <button type="submit" class="boton">
                                            Activar
                                        </button>
                                    <% } %>
                                </form>
                            </div>
                        </td>
                    </tr>
                <%  }
                   }
                %>
                </tbody>
            </table>
        </div>
    </section>

</div>
</body>
</html>
