
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="java.util.Map"%>
<%@page import="java.math.BigDecimal"%>
<%@page import="pe.edu.usil.origennoble.model.Producto"%>
<%@page import="pe.edu.usil.origennoble.model.Venta"%>

<%!
    private String escapar(String texto) {
        if (texto == null) return "";
        return texto.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }
%>

<%
    List<Producto> productos =
        (List<Producto>) request.getAttribute("productos");

    List<Venta> ventas =
        (List<Venta>) request.getAttribute("ventas");

    List<Map<String, Object>> clientes =
        (List<Map<String, Object>>) request.getAttribute("clientes");

    String mensaje = request.getParameter("mensaje");
    String error = (String) request.getAttribute("error");
%>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ventas | OrigenNoble</title>

    <style>
        * { box-sizing: border-box; }

        body {
            margin: 0;
            padding: 25px;
            background: #f5f3ef;
            color: #302b25;
            font-family: Arial, sans-serif;
        }

        .contenedor {
            max-width: 1200px;
            margin: auto;
        }

        h1 { color: #4c3528; }

        .panel {
            background: white;
            padding: 24px;
            border-radius: 12px;
            margin-bottom: 25px;
            box-shadow: 0 2px 8px #0000000d;
        }

        .fila {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            align-items: end;
        }

        .campo {
            display: flex;
            flex-direction: column;
            gap: 7px;
            flex: 1;
            min-width: 150px;
        }

        input, select {
            padding: 10px;
            border: 1px solid #d8d0c8;
            border-radius: 6px;
            width: 100%;
        }

        button, .enlace {
            background: #654832;
            color: white;
            border: none;
            border-radius: 6px;
            padding: 10px 15px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }

        button.secundario { background: #77716a; }

        button:disabled {
            opacity: .5;
            cursor: not-allowed;
        }

        .tabla-contenedor { overflow-x: auto; }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        th, td {
            padding: 12px;
            border-bottom: 1px solid #eee8e2;
            text-align: left;
            white-space: nowrap;
        }

        th { background: #f4eee8; }

        .total {
            font-size: 22px;
            font-weight: bold;
            color: #4c3528;
            text-align: right;
            margin: 20px 0;
        }

        .mensaje {
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 18px;
        }

        .exito { background: #e4f4e7; color: #216b32; }
        .error { background: #fbe8e6; color: #a12820; }
        .aviso { color: #756b61; font-size: 13px; }

        .producto-fila {
            border-bottom: 1px solid #eee8e2;
            padding: 12px 0;
        }

        .acciones {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
    </style>
</head>

<body>
<div class="contenedor">

    <p><a class="enlace" href="<%=request.getContextPath()%>/index.jsp">
        ← Volver al menú
    </a></p>

    <h1>Gestión de ventas</h1>
    <p>Registra operaciones comerciales y consulta el historial de ventas.</p>

    <% if ("exito".equals(mensaje)) { %>
        <div class="mensaje exito">
            La venta se registró correctamente y el inventario fue actualizado.
        </div>
    <% } %>

    <% if (error != null) { %>
        <div class="mensaje error"><%= escapar(error) %></div>
    <% } %>

    <section class="panel">
        <h2>Registrar nueva venta</h2>

        <form action="<%=request.getContextPath()%>/ventasServlet"
              method="post" id="formVenta">

            <div class="campo" style="max-width:400px; margin-bottom:20px;">
                <label for="clienteId">Cliente (opcional)</label>
                <select id="clienteId" name="clienteId">
                    <option value="">Venta sin cliente registrado</option>
                    <% if (clientes != null) {
                        for (Map<String, Object> cliente : clientes) { %>
                            <option value="<%=cliente.get("clienteId")%>">
                                <%=escapar(String.valueOf(cliente.get("nombre")))%>
                            </option>
                    <%  }
                    } %>
                </select>
            </div>

            <h3>Productos</h3>

            <div id="productosVenta">
                <div class="fila producto-fila">
                    <div class="campo">
                        <label>Producto</label>
                        <select name="productoId" class="producto-select" required>
                            <option value="">Seleccionar producto</option>

                            <% if (productos != null) {
                                for (Producto p : productos) {
                                    if ("activo".equalsIgnoreCase(p.getEstado())
                                            && p.getStock() > 0) { %>

                                        <option
                                            value="<%=p.getProductoId()%>"
                                            data-precio="<%=p.getPrecioVenta()%>"
                                            data-stock="<%=p.getStock()%>">
                                            <%=escapar(p.getNombre())%>
                                            — S/ <%=p.getPrecioVenta()%>
                                            (Stock: <%=p.getStock()%>)
                                        </option>

                            <%      }
                                }
                            } %>
                        </select>
                    </div>

                    <div class="campo" style="max-width:130px;">
                        <label>Cantidad</label>
                        <input type="number" name="cantidad"
                               class="cantidad" min="1" value="1" required>
                    </div>

                    <div class="campo" style="max-width:150px;">
                        <label>Subtotal</label>
                        <input type="text" class="subtotal" value="S/ 0.00"
                               readonly>
                    </div>

                    <div>
                        <button type="button" class="secundario quitar">
                            Quitar
                        </button>
                    </div>
                </div>
            </div>

            <div class="acciones" style="margin-top:15px;">
                <button type="button" id="agregarProducto"
                        class="secundario">+ Agregar producto</button>
            </div>

            <p class="aviso">
                Los importes mostrados son referenciales hasta confirmar la venta.
                El servidor valida nuevamente los precios y el stock.
            </p>

            <div class="total">
                Total: <span id="totalVenta">S/ 0.00</span>
            </div>

            <button type="submit">Confirmar venta</button>
        </form>
    </section>

    <section class="panel">
        <h2>Historial de ventas</h2>

        <div class="tabla-contenedor">
            <table>
                <thead>
                    <tr>
                        <th>N.º</th>
                        <th>Fecha</th>
                        <th>Cliente ID</th>
                        <th>Usuario ID</th>
                        <th>Total</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody>
                <% if (ventas != null && !ventas.isEmpty()) {
                    for (Venta v : ventas) { %>
                        <tr>
                            <td><%=v.getVentaId()%></td>
                            <td><%=v.getFechaVenta() != null
                                    ? v.getFechaVenta() : "—"%></td>
                            <td><%=v.getClienteId() != null
                                    ? v.getClienteId() : "Sin cliente"%></td>
                            <td><%=v.getUsuarioId()%></td>
                            <td>S/ <%=v.getTotal() != null
                                    ? v.getTotal() : BigDecimal.ZERO%></td>
                            <td><%=escapar(v.getEstado())%></td>
                        </tr>
                <%  }
                   } else { %>
                    <tr>
                        <td colspan="6">Todavía no hay ventas registradas.</td>
                    </tr>
                <% } %>
                </tbody>
            </table>
        </div>
    </section>
</div>

<script>
    const contenedor = document.getElementById("productosVenta");
    const botonAgregar = document.getElementById("agregarProducto");
    const formulario = document.getElementById("formVenta");

    function actualizarTotales() {
        let total = 0;

        contenedor.querySelectorAll(".producto-fila").forEach(fila => {
            const select = fila.querySelector(".producto-select");
            const cantidadInput = fila.querySelector(".cantidad");
            const subtotalInput = fila.querySelector(".subtotal");
            const opcion = select.options[select.selectedIndex];

            const precio = opcion && opcion.dataset.precio
                ? Number(opcion.dataset.precio) : 0;
            const stock = opcion && opcion.dataset.stock
                ? Number(opcion.dataset.stock) : 0;

            let cantidad = Number(cantidadInput.value) || 0;

            cantidadInput.max = stock > 0 ? stock : 1;

            if (stock > 0 && cantidad > stock) {
                cantidadInput.setCustomValidity(
                    "La cantidad supera el stock disponible (" + stock + ").");
            } else {
                cantidadInput.setCustomValidity("");
            }

            const subtotal = precio * cantidad;
            subtotalInput.value = "S/ " + subtotal.toFixed(2);

            if (select.value && cantidad > 0 && cantidad <= stock) {
                total += subtotal;
            }
        });

        document.getElementById("totalVenta").textContent =
            "S/ " + total.toFixed(2);
    }

    function conectarFila(fila) {
        fila.querySelector(".producto-select")
            .addEventListener("change", actualizarTotales);

        fila.querySelector(".cantidad")
            .addEventListener("input", actualizarTotales);

        fila.querySelector(".quitar").addEventListener("click", () => {
            if (contenedor.querySelectorAll(".producto-fila").length > 1) {
                fila.remove();
                actualizarTotales();
            } else {
                fila.querySelector(".producto-select").value = "";
                fila.querySelector(".cantidad").value = 1;
                actualizarTotales();
            }
        });
    }

    conectarFila(contenedor.querySelector(".producto-fila"));

    botonAgregar.addEventListener("click", () => {
        const original = contenedor.querySelector(".producto-fila");
        const nueva = original.cloneNode(true);

        nueva.querySelector(".producto-select").value = "";
        nueva.querySelector(".cantidad").value = 1;
        nueva.querySelector(".subtotal").value = "S/ 0.00";

        contenedor.appendChild(nueva);
        conectarFila(nueva);
        actualizarTotales();
    });

    formulario.addEventListener("submit", event => {
        const filas = contenedor.querySelectorAll(".producto-fila");
        const seleccionados = [];

        for (const fila of filas) {
            const select = fila.querySelector(".producto-select");
            const cantidad = fila.querySelector(".cantidad");

            if (!select.value) {
                event.preventDefault();
                alert("Selecciona un producto en cada fila o quita la fila vacía.");
                return;
            }

            if (!cantidad.checkValidity()) {
                event.preventDefault();
                cantidad.reportValidity();
                return;
            }

            if (seleccionados.includes(select.value)) {
                event.preventDefault();
                alert("No repitas el mismo producto en varias filas. "
                    + "Puedes sumar las cantidades en una sola fila.");
                return;
            }

            seleccionados.push(select.value);
        }
    });

    actualizarTotales();
</script>
</body>
</html>
