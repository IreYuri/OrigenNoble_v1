<%-- 
    Document   : usuarios
    Created on : 26 oct. 2026
    Author     : snay-
--%>


<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="java.util.Locale"%>
<%@page import="pe.edu.usil.origennoble.model.Usuario"%>

<%
    if (session.getAttribute("usuarioId") == null) {
        response.sendRedirect(request.getContextPath() + "/index.jsp");
        return;
    }

    List<Usuario> usuarios =
        (List<Usuario>) request.getAttribute("usuarios");

    if (usuarios == null) {
        response.sendRedirect(
            request.getContextPath() + "/usuariosServlet");
        return;
    }
%>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Usuarios | OrigenNoble</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 35px;
            background: #f7f5ef;
            color: #34271f;
            font-family: Arial, sans-serif;
        }

        .contenedor {
            max-width: 1250px;
            margin: auto;
        }

        .encabezado {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
            margin-bottom: 25px;
        }

        h1 {
            margin: 0 0 8px;
            font-size: 30px;
        }

        .subtitulo {
            color: #777;
            line-height: 1.5;
        }

        .boton {
            display: inline-block;
            padding: 10px 14px;
            border-radius: 8px;
            background: #78805a;
            color: white;
            text-decoration: none;
            border: none;
            font-size: 13px;
            cursor: pointer;
            white-space: nowrap;
            text-align: center;
            transition: background 0.2s ease;
            font-family: Arial, sans-serif;
        }

        .boton:hover {
            background: #626a46;
        }

        .secundario {
            background: #34271f;
        }

        .secundario:hover {
            background: #514033;
        }

        .panel {
            background: white;
            padding: 24px;
            border-radius: 14px;
            box-shadow: 0 4px 18px #34271f0d;
            overflow-x: auto;
        }

        .resumen {
            margin-bottom: 20px;
            color: #666;
        }

        .filtros {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-bottom: 22px;
        }

        .filtros input,
        .filtros select {
            padding: 11px 12px;
            border: 1px solid #e5e0d7;
            border-radius: 8px;
            background: #fff;
            color: #34271f;
            font-size: 14px;
        }

        .filtros input {
            flex: 1;
            min-width: 210px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
            min-width: 1100px;
        }

        th,
        td {
            padding: 14px 12px;
            border-bottom: 1px solid #eeeae2;
        }

        th {
            color: #777;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: .5px;
            white-space: nowrap;
        }

        td {
            font-size: 13px;
        }

        .estado,
        .rol {
            display: inline-block;
            padding: 6px 9px;
            border-radius: 20px;
            font-size: 12px;
            white-space: nowrap;
        }

        .estado {
            background: #edf2e5;
            color: #52613b;
        }

        .estado.inactivo,
        .estado.suspendido,
        .estado.bloqueado,
        .estado.desconocido {
            background: #f8e9e5;
            color: #944b3c;
        }

        .rol {
            background: #f1ece4;
            color: #6d5744;
        }

        .si {
            color: #944b3c;
            font-weight: bold;
        }

        .no {
            color: #52613b;
        }

        .vacio {
            text-align: center;
            padding: 30px;
            color: #777;
        }

        .sin-resultados {
            display: none;
        }

        .acciones {
            white-space: nowrap;
        }

        .acciones form {
            display: inline-block;
            margin: 0;
        }

        .encabezado-usuarios {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
            margin-bottom: 24px;
            flex-wrap: wrap;
        }

        .encabezado-usuarios .boton {
            padding: 12px 20px;
            background-color: #596442;
            color: #ffffff;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            transition: background-color 0.2s ease;
        }

        .encabezado-usuarios .boton:hover {
            background-color: #424d30;
        }

        .mensaje-exito,
        .mensaje-error {
            padding: 13px 16px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-size: 14px;
            line-height: 1.5;
        }

        .mensaje-exito {
            background: #edf2e5;
            color: #52613b;
        }

        .mensaje-error {
            background: #f8e9e5;
            color: #944b3c;
        }

        .boton-desactivar {
            background: #f8e9e5;
            color: #944b3c;
            margin-left: 5px;
        }

        .boton-desactivar:hover {
            background: #efd5cf;
        }

        .boton-activar {
            background: #edf2e5;
            color: #52613b;
            margin-left: 5px;
        }

        .boton-activar:hover {
            background: #dce7ce;
        }

        @media (max-width: 600px) {
            body {
                padding: 18px;
            }

            .panel {
                padding: 14px;
            }

            h1 {
                font-size: 25px;
            }
        }
    </style>
</head>

<body>

<div class="contenedor">

    <header class="encabezado">
        <div>
            <h1>Gestión de usuarios</h1>
            <div class="subtitulo">
                Consulta las cuentas, sus roles y su estado de acceso.
            </div>
        </div>

        <a href="<%= request.getContextPath() %>/registroUsuarioServlet"
           class="boton">
            + Registrar usuario
        </a>

        <a class="boton secundario"
           href="<%= request.getContextPath() %>/dashboard.jsp">
            Volver al inicio
        </a>
    </header>

    <main class="panel">

        <%-- Mensajes de activación y desactivación --%>
        <%
            String estadoMensaje = request.getParameter("estado");
        %>

        <% if ("actualizado".equals(estadoMensaje)) { %>
            <div class="mensaje-exito">
                El estado del usuario se actualizó correctamente.
            </div>
        <% } else if ("propia".equals(estadoMensaje)) { %>
            <div class="mensaje-error">
                No puedes desactivar tu propia cuenta de administrador.
            </div>
        <% } else if ("datos".equals(estadoMensaje)) { %>
            <div class="mensaje-error">
                Los datos enviados no son válidos.
            </div>
        <% } else if ("error".equals(estadoMensaje)) { %>
            <div class="mensaje-error">
                No se pudo cambiar el estado. Verifica el usuario e inténtalo de nuevo.
            </div>
        <% } %>

        <%-- Mensajes de registro de usuarios --%>
        <%
            String registro = request.getParameter("registro");
            String mensajeError = request.getParameter("error");
        %>

        <% if ("exitoso".equals(registro)) { %>
            <div class="mensaje-exito">
                Usuario registrado correctamente.
            </div>
        <% } %>

        <% if ("duplicado".equals(mensajeError)) { %>
            <div class="mensaje-error">
                El nombre de usuario o el correo ya están registrados.
            </div>
        <% } else if ("datos".equals(mensajeError)) { %>
            <div class="mensaje-error">
                No se pudo completar la operación. Revisa los datos ingresados.
            </div>
        <% } else if ("servidor".equals(mensajeError)) { %>
            <div class="mensaje-error">
                Ocurrió un error al registrar el usuario. Inténtalo nuevamente.
            </div>
        <% } %>

        <%-- Resumen de usuarios --%>
        <div class="resumen">
            Usuarios registrados:
            <strong id="totalUsuarios"><%= usuarios.size() %></strong>
        </div>

        <%-- Buscador y filtros --%>
        <div class="filtros">

            <input type="search"
                   id="buscarUsuario"
                   placeholder="Buscar por usuario o correo..."
                   aria-label="Buscar usuarios">

            <select id="filtroRol" aria-label="Filtrar por rol">
                <option value="">Todos los roles</option>
                <option value="administrador">Administrador</option>
                <option value="editor">Editor</option>
                <option value="usuario básico">Usuario Básico</option>
                <option value="invitado">Invitado</option>
            </select>

            <select id="filtroEstado" aria-label="Filtrar por estado">
                <option value="">Todos los estados</option>
                <option value="activo">Activo</option>
                <option value="inactivo">Inactivo</option>
                <option value="suspendido">Suspendido</option>
                <option value="bloqueado">Bloqueado</option>
            </select>

        </div>

        <%-- Tabla de usuarios --%>
        <table id="tablaUsuarios">

            <thead>
                <tr>
                    <th>ID</th>
                    <th>Usuario</th>
                    <th>Correo electrónico</th>
                    <th>Rol</th>
                    <th>Estado</th>
                    <th>Intentos fallidos</th>
                    <th>Bloqueo temporal</th>
                    <th>Acciones</th>
                </tr>
            </thead>

            <tbody>

            <% if (usuarios.isEmpty()) { %>

                <tr>
                    <td colspan="8" class="vacio">
                        No hay usuarios registrados.
                    </td>
                </tr>

            <% } else {
                for (Usuario u : usuarios) {

                    String estado = u.getEstado() == null
                        ? "desconocido"
                        : u.getEstado();

                    String claseEstado =
                        estado.toLowerCase(Locale.ROOT);

                    String rol = u.getNombreRol() == null
                        ? "Sin rol"
                        : u.getNombreRol();

                    String nombreUsuario = u.getNombreUsuario() == null
                        ? ""
                        : u.getNombreUsuario();

                    String email = u.getEmail() == null
                        ? ""
                        : u.getEmail();
            %>

                <tr class="fila-usuario"
                    data-usuario="<%= nombreUsuario.toLowerCase(Locale.ROOT) %>"
                    data-email="<%= email.toLowerCase(Locale.ROOT) %>"
                    data-rol="<%= rol.toLowerCase(Locale.ROOT) %>"
                    data-estado="<%= claseEstado %>">

                    <td><%= u.getUsuarioId() %></td>

                    <td><%= nombreUsuario %></td>

                    <td><%= email %></td>

                    <td>
                        <span class="rol"><%= rol %></span>
                    </td>

                    <td>
                        <span class="estado <%= claseEstado %>">
                            <%= estado %>
                        </span>
                    </td>

                    <td><%= u.getIntentosFallidos() %></td>

                    <td>
                        <% if (u.isBloqueado()) { %>
                            <span class="si">Bloqueado</span>
                        <% } else { %>
                            <span class="no">No</span>
                        <% } %>
                    </td>

                    <%-- Acciones disponibles según el estado --%>
                    <td class="acciones">

                        <a class="boton"
                           href="<%= request.getContextPath() %>/editarUsuarioServlet?id=<%= u.getUsuarioId() %>">
                            Editar
                        </a>

                        <% if ("activo".equalsIgnoreCase(estado)) { %>

                            <form method="post"
                                  action="<%= request.getContextPath() %>/cambiarEstadoUsuarioServlet"
                                  onsubmit="return confirm('¿Seguro que deseas desactivar esta cuenta?');">

                                <input type="hidden"
                                       name="usuarioId"
                                       value="<%= u.getUsuarioId() %>">

                                <input type="hidden"
                                       name="nuevoEstado"
                                       value="inactivo">

                                <button type="submit"
                                        class="boton boton-desactivar">
                                    Desactivar
                                </button>
                            </form>

                        <% } else if ("inactivo".equalsIgnoreCase(estado)) { %>

                            <form method="post"
                                  action="<%= request.getContextPath() %>/cambiarEstadoUsuarioServlet"
                                  onsubmit="return confirm('¿Deseas volver a activar esta cuenta?');">

                                <input type="hidden"
                                       name="usuarioId"
                                       value="<%= u.getUsuarioId() %>">

                                <input type="hidden"
                                       name="nuevoEstado"
                                       value="activo">

                                <button type="submit"
                                        class="boton boton-activar">
                                    Activar
                                </button>
                            </form>

                        <% } %>

                    </td>

                </tr>

            <%  }
               } %>

                <tr id="sinResultados" class="sin-resultados">
                    <td colspan="8" class="vacio">
                        No se encontraron usuarios con esos filtros.
                    </td>
                </tr>

            </tbody>
        </table>

    </main>
</div>

<script>
    const buscar = document.getElementById("buscarUsuario");
    const filtroRol = document.getElementById("filtroRol");
    const filtroEstado = document.getElementById("filtroEstado");
    const filas = document.querySelectorAll(".fila-usuario");
    const sinResultados = document.getElementById("sinResultados");
    const totalUsuarios = document.getElementById("totalUsuarios");

    function filtrarUsuarios() {
        const texto = buscar.value.trim().toLocaleLowerCase();
        const rol = filtroRol.value.toLocaleLowerCase();
        const estado = filtroEstado.value.toLocaleLowerCase();

        let visibles = 0;

        filas.forEach(function(fila) {
            const coincideTexto =
                fila.dataset.usuario.includes(texto) ||
                fila.dataset.email.includes(texto);

            const coincideRol =
                !rol || fila.dataset.rol === rol;

            const coincideEstado =
                !estado || fila.dataset.estado === estado;

            const mostrar =
                coincideTexto && coincideRol && coincideEstado;

            fila.style.display = mostrar ? "" : "none";

            if (mostrar) {
                visibles++;
            }
        });

        sinResultados.style.display =
            filas.length > 0 && visibles === 0
                ? "table-row"
                : "none";

        totalUsuarios.textContent = visibles;
    }

    buscar.addEventListener("input", filtrarUsuarios);
    filtroRol.addEventListener("change", filtrarUsuarios);
    filtroEstado.addEventListener("change", filtrarUsuarios);

    filtrarUsuarios();
</script>

</body>
</html>
