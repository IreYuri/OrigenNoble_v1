
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="java.util.Map"%>
<%@page import="pe.edu.usil.origennoble.model.Solped"%>
<%@page import="java.math.BigDecimal"%>

<%!
    private String escapar(Object valor) {
        if (valor == null) return "";
        return valor.toString()
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }

    private String dinero(Object valor) {
        if (valor == null) return "0.00";
        return String.format(java.util.Locale.US, "%.2f",
                ((BigDecimal) valor).doubleValue());
    }
%>

<%
    if (session.getAttribute("usuarioId") == null) {
        response.sendRedirect(request.getContextPath() + "/index.jsp");
        return;
    }

    List<Map<String, Object>> productos =
            (List<Map<String, Object>>) request.getAttribute("productos");

    List<Map<String, Object>> clientes =
            (List<Map<String, Object>>) request.getAttribute("clientes");

    List<Solped> solicitudes =
            (List<Solped>) request.getAttribute("solpedList");

    String error = (String) request.getAttribute("error");
    String mensaje = request.getParameter("mensaje");
%>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Solicitudes de pedido | OrigenNoble</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: #f5f6f8;
            color: #263238;
        }

        header {
            background: #263d32;
            color: white;
            padding: 20px 5%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
        }

        header h1 {
            margin: 0;
            font-size: 23px;
        }

        header a {
            color: white;
            text-decoration: none;
        }

        main {
            max-width: 1200px;
            margin: 28px auto;
            padding: 0 18px;
        }

        .panel {
            background: white;
            padding: 24px;
            border-radius: 12px;
            margin-bottom: 25px;
            box-shadow: 0 3px 12px rgba(0, 0, 0, .06);
        }

        h2 {
            margin-top: 0;
            color: #263d32;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 7px;
        }

        input, select, textarea {
            width: 100%;
            padding: 11px;
            border: 1px solid #ccd2d0;
            border-radius: 7px;
            font-size: 14px;
            background: white;
        }

        textarea {
            resize: vertical;
        }

        .full {
            grid-column: 1 / -1;
        }

        .product-row {
            display: grid;
            grid-template-columns: minmax(180px, 2fr) minmax(90px, .7fr)
                minmax(90px, .7fr) 90px;
            gap: 12px;
            align-items: end;
            margin-bottom: 13px;
        }

        .subtotal {
            padding: 11px 4px;
            font-weight: bold;
        }

        button, .button {
            border: 0;
            border-radius: 7px;
            padding: 11px 16px;
            font-size: 14px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }

        .primary {
            background: #263d32;
            color: white;
        }

        .secondary {
            background: #e8eeea;
            color: #263d32;
        }

        .danger {
            background: #fce8e6;
            color: #a12622;
        }

        .actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 18px;
        }

        .notice {
            padding: 13px 15px;
            border-radius: 7px;
            margin-bottom: 18px;
        }

        .success {
            background: #e4f4e8;
            color: #205b32;
        }

        .error {
            background: #fde8e7;
            color: #982d28;
        }

        .table-wrap {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e5e9e7;
        }

        th {
            background: #f1f4f2;
            color: #263d32;
        }

        .status {
            display: inline-block;
            padding: 5px 9px;
            border-radius: 20px;
            background: #e8eeea;
            font-size: 12px;
            white-space: nowrap;
        }

        .empty {
            text-align: center;
            color: #697773;
            padding: 25px;
        }

        @media (max-width: 700px) {
            .form-grid {
                grid-template-columns: 1fr;
            }

            .full {
                grid-column: auto;
            }

            .product-row {
                grid-template-columns: 1fr 1fr;
                padding: 12px;
                border: 1px solid #e0e5e2;
                border-radius: 8px;
            }

            header h1 {
                font-size: 19px;
            }
        }
    </style>
</head>

<body>

<header>
    <h1>OrigenNoble | Solicitudes de pedido</h1>
    <a href="<%= request.getContextPath() %>/dashboard.jsp">
        ← Volver al dashboard
    </a>
</header>

<main>

    <% if ("registrada".equals(mensaje)) { %>
        <div class="notice success">
            La solicitud de pedido se registró correctamente.
        </div>
    <% } %>

    <% if (error != null && !error.isBlank()) { %>
        <div class="notice error">
            <%= escapar(error) %>
        </div>
    <% } %>

    <section class="panel">
        <h2>Registrar solicitud de pedido</h2>
        <p>Ingresa los datos y agrega uno o más productos a la solicitud.</p>

        <form action="<%= request.getContextPath() %>/solpedServlet"
              method="post" id="formSolped">

            <div class="form-grid">

                <div>
                    <label for="clienteId">Cliente</label>
                    <select name="clienteId" id="clienteId">
                        <option value="">Sin cliente asociado</option>

                        <% if (clientes != null) {
                            for (Map<String, Object> cliente : clientes) { %>
                                <option value="<%= cliente.get("id") %>">
                                    <%= escapar(cliente.get("nombre")) %>
                                    <% if (cliente.get("numeroDocumento") != null
                                          && !cliente.get("numeroDocumento").toString().isBlank()) { %>
                                        — <%= escapar(cliente.get("numeroDocumento")) %>
                                    <% } %>
                                </option>
                        <%  }
                           } %>
                    </select>
                </div>

                <div>
                    <label for="observaciones">Observaciones</label>
                    <input type="text" id="observaciones"
                           name="observaciones" maxlength="500"
                           placeholder="Notas adicionales (opcional)">
                </div>

                <div class="full">
                    <label>Productos solicitados</label>
                    <div id="productosContainer"></div>

                    <div class="actions">
                        <button type="button" class="secondary"
                                id="agregarProducto">
                            + Agregar producto
                        </button>
                    </div>
                </div>

                <div class="full">
                    <label for="totalReferencial">Total referencial</label>
                    <input type="text" id="totalReferencial"
                           value="S/ 0.00" readonly>
                    <small>
                        Es un cálculo referencial. El importe definitivo
                        se determinará al registrar la venta.
                    </small>
                </div>

            </div>

            <div class="actions">
                <button type="submit" class="primary">
                    Registrar solicitud
                </button>
                <button type="reset" class="secondary" id="limpiarFormulario">
                    Limpiar formulario
                </button>
            </div>
        </form>
    </section>

    <section class="panel">
        <h2>Historial de solicitudes</h2>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>N.º SOLPED</th>
                        <th>Fecha</th>
                        <th>Cliente</th>
                        <th>Registrado por</th>
                        <th>Observaciones</th>
                        <th>Estado</th>
                    </tr>
                </thead>

                <tbody>
                    <% if (solicitudes == null || solicitudes.isEmpty()) { %>
                        <tr>
                            <td colspan="6" class="empty">
                                Todavía no hay solicitudes registradas.
                            </td>
                        </tr>
                    <% } else {
                        for (Solped s : solicitudes) { %>
                            <tr>
                                <td>#<%= s.getSolpedId() %></td>
                                <td><%= s.getFechaSolicitud() == null
                                        ? "—" : escapar(s.getFechaSolicitud()) %></td>
                                <td><%= escapar(s.getNombreCliente()) %></td>
                                <td><%= escapar(s.getNombreUsuario()) %></td>
                                <td><%= escapar(s.getObservaciones()) %></td>
                                <td>
                                    <span class="status">
                                        <%= escapar(s.getEstado()) %>
                                    </span>
                                </td>
                            </tr>
                    <%  }
                       } %>
                </tbody>
            </table>
        </div>
    </section>

</main>

<script>
    const productosDisponibles = [
        <% if (productos != null) {
            for (int i = 0; i < productos.size(); i++) {
                Map<String, Object> p = productos.get(i);
        %>
        {
            id: "<%= p.get("id") %>",
            nombre: "<%= escapar(p.get("nombre")) %>",
            precio: <%= p.get("precio") == null ? "0" : p.get("precio").toString() %>,
            stock: <%= p.get("stock") %>
        }<%= i < productos.size() - 1 ? "," : "" %>
        <%  }
           } %>
    ];

    const container = document.getElementById("productosContainer");
    const totalInput = document.getElementById("totalReferencial");

    function crearFila() {
        const fila = document.createElement("div");
        fila.className = "product-row";

        const campoProducto = document.createElement("div");
        const labelProducto = document.createElement("label");
        labelProducto.textContent = "Producto";
        const select = document.createElement("select");
        select.name = "productoId";
        select.required = true;

        const opcionInicial = document.createElement("option");
        opcionInicial.value = "";
        opcionInicial.textContent = "Seleccionar producto";
        select.appendChild(opcionInicial);

        productosDisponibles.forEach(function(p) {
            const opcion = document.createElement("option");
            opcion.value = p.id;
            opcion.textContent = p.nombre + " — S/ "
                + Number(p.precio).toFixed(2)
                + " (stock: " + p.stock + ")";
            opcion.dataset.precio = p.precio;
            opcion.dataset.stock = p.stock;
            select.appendChild(opcion);
        });

        campoProducto.appendChild(labelProducto);
        campoProducto.appendChild(select);

        const campoCantidad = document.createElement("div");
        const labelCantidad = document.createElement("label");
        labelCantidad.textContent = "Cantidad";
        const cantidad = document.createElement("input");
        cantidad.type = "number";
        cantidad.name = "cantidad";
        cantidad.min = "1";
        cantidad.step = "1";
        cantidad.value = "1";
        cantidad.required = true;
        campoCantidad.appendChild(labelCantidad);
        campoCantidad.appendChild(cantidad);

        const campoSubtotal = document.createElement("div");
        const labelSubtotal = document.createElement("label");
        labelSubtotal.textContent = "Subtotal";
        const subtotal = document.createElement("div");
        subtotal.className = "subtotal";
        subtotal.textContent = "S/ 0.00";
        campoSubtotal.appendChild(labelSubtotal);
        campoSubtotal.appendChild(subtotal);

        const campoEliminar = document.createElement("div");
        const labelEliminar = document.createElement("label");
        labelEliminar.textContent = "Acción";
        const botonEliminar = document.createElement("button");
        botonEliminar.type = "button";
        botonEliminar.className = "danger";
        botonEliminar.textContent = "Quitar";
        campoEliminar.appendChild(labelEliminar);
        campoEliminar.appendChild(botonEliminar);

        fila.appendChild(campoProducto);
        fila.appendChild(campoCantidad);
        fila.appendChild(campoSubtotal);
        fila.appendChild(campoEliminar);

        select.addEventListener("change", recalcular);
        cantidad.addEventListener("input", recalcular);

        botonEliminar.addEventListener("click", function() {
            fila.remove();

            if (container.children.length === 0) {
                crearFila();
            }

            recalcular();
        });

        container.appendChild(fila);
        recalcular();
    }

    function recalcular() {
        let total = 0;
        const seleccionados = new Set();
        let duplicado = false;

        container.querySelectorAll(".product-row").forEach(function(fila) {
            const select = fila.querySelector('select[name="productoId"]');
            const cantidad = fila.querySelector('input[name="cantidad"]');
            const subtotal = fila.querySelector(".subtotal");
            const opcion = select.options[select.selectedIndex];

            const precio = opcion && opcion.dataset.precio
                ? Number(opcion.dataset.precio) : 0;

            const stock = opcion && opcion.dataset.stock
                ? Number(opcion.dataset.stock) : 0;

            const unidades = Number(cantidad.value);
            const importe = precio * (unidades > 0 ? unidades : 0);

            subtotal.textContent = "S/ " + importe.toFixed(2);
            total += importe;

            select.setCustomValidity("");
            cantidad.setCustomValidity("");

            if (select.value && seleccionados.has(select.value)) {
                select.setCustomValidity("No repitas el mismo producto.");
                duplicado = true;
            }

            if (select.value) {
                seleccionados.add(select.value);
            }

            if (select.value && unidades > stock) {
                cantidad.setCustomValidity(
                    "La cantidad supera el stock disponible.");
            }
        });

        totalInput.value = "S/ " + total.toFixed(2);
    }

    document.getElementById("agregarProducto")
        .addEventListener("click", crearFila);

    document.getElementById("limpiarFormulario")
        .addEventListener("click", function() {
            setTimeout(function() {
                container.innerHTML = "";
                crearFila();
            }, 0);
        });

    document.getElementById("formSolped")
        .addEventListener("submit", function(event) {
            if (container.children.length === 0) {
                event.preventDefault();
                alert("Agrega al menos un producto.");
                return;
            }

            const selects = container.querySelectorAll(
                'select[name="productoId"]');

            const ids = Array.from(selects).map(function(s) {
                return s.value;
            });

            if (ids.some(function(id) { return !id; })) {
                event.preventDefault();
                alert("Selecciona un producto en cada fila.");
                return;
            }

            if (new Set(ids).size !== ids.length) {
                event.preventDefault();
                alert("No repitas productos. Modifica la cantidad en su fila.");
            }
        });

    crearFila();
</script>

</body>
</html>
