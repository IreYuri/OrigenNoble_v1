
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    if (session.getAttribute("usuarioId") == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }

    String error = request.getParameter("error");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar proveedor | OrigenNoble</title>

    <style>
        * { box-sizing: border-box; }

        body {
            margin: 0;
            padding: 30px 16px;
            background: #f7f4ef;
            color: #3c3028;
            font-family: Arial, sans-serif;
        }

        .contenedor {
            max-width: 700px;
            margin: 0 auto;
        }

        .tarjeta {
            background: white;
            padding: 28px;
            border-radius: 12px;
            box-shadow: 0 3px 12px #0000000b;
        }

        h1 { margin-top: 0; }

        .subtitulo {
            color: #75675c;
            margin-bottom: 24px;
        }

        .campo { margin-bottom: 18px; }

        label {
            display: block;
            margin-bottom: 7px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 11px;
            border: 1px solid #d8cec4;
            border-radius: 6px;
            font-size: 15px;
        }

        .botones {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 24px;
        }

        .boton {
            display: inline-block;
            padding: 11px 16px;
            border: 0;
            border-radius: 6px;
            text-decoration: none;
            cursor: pointer;
            font-size: 14px;
        }

        .principal {
            background: #68452f;
            color: white;
        }

        .secundario {
            background: #eee5dc;
            color: #543b2a;
        }

        .error {
            background: #f8e6e1;
            color: #963f32;
            border-radius: 6px;
            padding: 12px;
            margin-bottom: 18px;
        }

        .nota {
            font-size: 13px;
            color: #75675c;
        }
    </style>
</head>

<body>
<div class="contenedor">
    <div class="tarjeta">
        <h1>Registrar proveedor</h1>
        <p class="subtitulo">
            Ingresa los datos del proveedor de OrigenNoble.
        </p>

        <% if ("datos".equals(error)) { %>
            <div class="error">
                Verifica los campos obligatorios y que el RUC tenga 11 dígitos.
            </div>
        <% } else if ("duplicado".equals(error)) { %>
            <div class="error">
                Ese RUC ya se encuentra registrado.
            </div>
        <% } else if ("general".equals(error)) { %>
            <div class="error">
                No se pudo registrar el proveedor. Inténtalo nuevamente.
            </div>
        <% } %>

        <form action="<%=request.getContextPath()%>/registroProveedorServlet"
              method="post">

            <div class="campo">
                <label for="razonSocial">Razón social *</label>
                <input type="text" id="razonSocial" name="razonSocial"
                       maxlength="150" required>
            </div>

            <div class="campo">
                <label for="ruc">RUC *</label>
                <input type="text" id="ruc" name="ruc"
                       inputmode="numeric" pattern="[0-9]{11}"
                       minlength="11" maxlength="11" required>
                <p class="nota">Ingresa los 11 dígitos del RUC.</p>
            </div>

            <div class="campo">
                <label for="telefono">Teléfono</label>
                <input type="text" id="telefono" name="telefono"
                       maxlength="20">
            </div>

            <div class="campo">
                <label for="direccion">Dirección</label>
                <input type="text" id="direccion" name="direccion"
                       maxlength="200">
            </div>

            <div class="campo">
                <label for="correo">Correo electrónico</label>
                <input type="email" id="correo" name="correo"
                       maxlength="150">
            </div>

            <div class="botones">
                <button type="submit" class="boton principal">
                    Guardar proveedor
                </button>

                <a class="boton secundario"
                   href="<%=request.getContextPath()%>/proveedoresServlet">
                    Cancelar
                </a>
            </div>
        </form>
    </div>
</div>
</body>
</html>
