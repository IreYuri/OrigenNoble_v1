
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="pe.edu.usil.origennoble.model.Cliente"%>

<%!
    private String escaparHTML(String texto) {
        if (texto == null) return "";
        return texto.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }
%>

<%
    if (session.getAttribute("usuarioId") == null) {
        response.sendRedirect(request.getContextPath() + "/index.jsp");
        return;
    }

    Cliente cliente = (Cliente) request.getAttribute("cliente");

    if (cliente == null) {
        response.sendRedirect(
            request.getContextPath() + "/clientesServlet?error=noencontrado"
        );
        return;
    }

    String error = request.getParameter("error");
%>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar cliente | OrigenNoble</title>

    <style>
        * { box-sizing: border-box; }

        body {
            margin: 0;
            padding: 30px 15px;
            font-family: Arial, sans-serif;
            background: #faf6ef;
            color: #332a25;
        }

        .contenedor {
            max-width: 850px;
            margin: 0 auto;
        }

        .encabezado {
            background: #49352a;
            color: white;
            padding: 22px;
            border-radius: 12px 12px 0 0;
        }

        .encabezado h1 { margin: 0; font-size: 24px; }
        .encabezado p { margin-bottom: 0; color: #eee1d4; }

        .formulario {
            background: white;
            border: 1px solid #e8dfd3;
            padding: 25px;
            border-radius: 0 0 12px 12px;
        }

        .rejilla {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
        }

        .campo { display: flex; flex-direction: column; gap: 7px; }
        .completo { grid-column: 1 / -1; }

        label { font-weight: bold; font-size: 14px; }

        input, select, textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #d9cec1;
            border-radius: 8px;
            font-size: 14px;
            font-family: inherit;
        }

        textarea { resize: vertical; min-height: 80px; }

        .acciones {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 24px;
        }

        .boton {
            display: inline-block;
            border: 0;
            border-radius: 8px;
            padding: 12px 17px;
            font-weight: bold;
            text-decoration: none;
            cursor: pointer;
            font-size: 14px;
        }

        .guardar { background: #78805a; color: white; }
        .cancelar {
            background: white;
            color: #49352a;
            border: 1px solid #e8dfd3;
        }

        .alerta {
            background: #f8e6e1;
            color: #963f32;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 18px;
        }

        .nota { font-size: 12px; color: #776b61; }

        @media (max-width: 600px) {
            .rejilla { grid-template-columns: 1fr; }
            .completo { grid-column: auto; }
            .formulario { padding: 18px; }
        }
    </style>
</head>

<body>
<div class="contenedor">
    <div class="encabezado">
        <h1>Editar cliente</h1>
        <p>Modifica la información del cliente seleccionado.</p>
    </div>

    <div class="formulario">

        <% if ("datos".equals(error)) { %>
            <div class="alerta">
                Revisa los campos obligatorios y los formatos ingresados.
            </div>
        <% } else if ("duplicado".equals(error)) { %>
            <div class="alerta">
                El número de documento ya pertenece a otro cliente.
            </div>
        <% } else if ("general".equals(error)) { %>
            <div class="alerta">
                No se pudo actualizar el cliente. Inténtalo nuevamente.
            </div>
        <% } %>

        <form action="<%=request.getContextPath()%>/actualizarClienteServlet"
              method="post">

            <input type="hidden" name="clienteId"
                   value="<%=cliente.getClienteId()%>">

            <div class="rejilla">
                <div class="campo">
                    <label for="tipoDocumento">Tipo de documento</label>
                    <select id="tipoDocumento" name="tipoDocumento">
                        <option value="">Seleccionar</option>
                        <option value="DNI" <%= "DNI".equals(cliente.getTipoDocumento()) ? "selected" : "" %>>DNI</option>
                        <option value="RUC" <%= "RUC".equals(cliente.getTipoDocumento()) ? "selected" : "" %>>RUC</option>
                        <option value="CE" <%= "CE".equals(cliente.getTipoDocumento()) ? "selected" : "" %>>CE</option>
                        <option value="OTRO" <%= "OTRO".equals(cliente.getTipoDocumento()) ? "selected" : "" %>>OTRO</option>
                    </select>
                </div>

                <div class="campo">
                    <label for="numeroDocumento">Número de documento</label>
                    <input id="numeroDocumento" name="numeroDocumento"
                           maxlength="20"
                           value="<%=escaparHTML(cliente.getNumeroDocumento())%>">
                </div>

                <div class="campo">
                    <label for="nombres">Nombres</label>
                    <input id="nombres" name="nombres" maxlength="100"
                           value="<%=escaparHTML(cliente.getNombres())%>">
                </div>

                <div class="campo">
                    <label for="apellidos">Apellidos</label>
                    <input id="apellidos" name="apellidos" maxlength="100"
                           value="<%=escaparHTML(cliente.getApellidos())%>">
                </div>

                <div class="campo completo">
                    <label for="razonSocial">Razón social (empresa)</label>
                    <input id="razonSocial" name="razonSocial" maxlength="150"
                           value="<%=escaparHTML(cliente.getRazonSocial())%>">
                    <span class="nota">
                        Completa la razón social para clientes empresariales.
                    </span>
                </div>

                <div class="campo">
                    <label for="telefono">Teléfono</label>
                    <input id="telefono" name="telefono" maxlength="20"
                           value="<%=escaparHTML(cliente.getTelefono())%>">
                </div>

                <div class="campo">
                    <label for="email">Correo electrónico</label>
                    <input id="email" name="email" type="email" maxlength="150"
                           value="<%=escaparHTML(cliente.getEmail())%>">
                </div>

                <div class="campo completo">
                    <label for="direccion">Dirección</label>
                    <textarea id="direccion" name="direccion"
                              maxlength="200"><%=escaparHTML(cliente.getDireccion())%></textarea>
                </div>
            </div>

            <div class="acciones">
                <button type="submit" class="boton guardar">
                    Guardar cambios
                </button>

                <a class="boton cancelar"
                   href="<%=request.getContextPath()%>/clientesServlet">
                    Cancelar
                </a>
            </div>
        </form>
    </div>
</div>
</body>
</html>
