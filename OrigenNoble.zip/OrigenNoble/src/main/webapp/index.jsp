<%-- 
    Document   : index
    Created on : 25 oct. 2026, 20:29:21
    Author     : snay-
--%>


<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#F7F2E8">
    <title>OrigenNoble | Sistema de Gestión</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=EB+Garamond:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/CSS/login.css">
</head>
<body>
<main class="page-shell">
    <div class="login-card">
        <section class="brand-panel" aria-labelledby="brand-heading">
            <div class="brand-photo" aria-hidden="true"></div>
            <div class="brand-shade" aria-hidden="true"></div>

            <div class="brand-inner">
                <header class="brand-header">
                    <div class="brand-mark">
                        <img src="${pageContext.request.contextPath}/images/logo.png"
                             alt="Logotipo de Origen Noble"
                             onerror="this.style.display='none'">
                    </div>
                    <div class="brand-name">
                        <span>ORIGENNOBLE</span>
                        <small>DESDE 2026</small>
                    </div>
                </header>

                <div class="brand-copy">
                    <span class="brand-tag"><i class="fa-solid fa-leaf" aria-hidden="true"></i> SISTEMA DE GESTIÓN INTEGRAL</span>
                    <h1 id="brand-heading">El origen de una <em>buena gestión.</em></h1>
                    <p>Plataforma administrativa para centralizar operaciones, inventario, proveedores, ventas y solicitudes de micropréstamos.</p>
                </div>

                <div class="brand-bottom">
                    <div class="feature-grid">
                        <div><span class="feature-check"><i class="fa-solid fa-check" aria-hidden="true"></i></span>Control de trazabilidad</div>
                        <div><span class="feature-check"><i class="fa-solid fa-check" aria-hidden="true"></i></span>Gestión de proveedores</div>
                        <div><span class="feature-check"><i class="fa-solid fa-check" aria-hidden="true"></i></span>Ventas y micropréstamos</div>
                        <div><span class="feature-check"><i class="fa-solid fa-check" aria-hidden="true"></i></span>Control de operaciones</div>
                    </div>
                    <div class="brand-footnote">
                        <span>ORIGENNOBLE</span>
                        <span>Pasión por lo auténtico.</span>
                    </div>
                </div>
            </div>
        </section>

        <section class="form-panel" aria-labelledby="login-title">
            <div class="form-inner">
                <div class="portal-row">
                    <span class="portal-badge"><i class="fa-solid fa-shield-halved" aria-hidden="true"></i> PORTAL ADMINISTRATIVO</span>
                    <span class="portal-caption"><i class="fa-solid fa-lock" aria-hidden="true"></i> Acceso seguro</span>
                </div>

                <header class="form-heading">
                    <span class="section-kicker">BIENVENIDO</span>
                    <h2 id="login-title">Inicia sesión</h2>
                    <p>Ingresa tus credenciales para acceder al sistema.</p>
                </header>

                <%-- Mensajes provenientes del servidor; aún no hay autenticación conectada. --%>
                <% String loginError = request.getParameter("error"); %>
                <% if ("invalid".equals(loginError)) { %>
                    <div class="server-alert" role="alert">
                        <i class="fa-solid fa-circle-exclamation" aria-hidden="true"></i>
                        <div><strong>No se pudo iniciar sesión</strong><p>Verifica tu usuario y contraseña e inténtalo nuevamente.</p></div>
                    </div>
                <% } else if ("blocked".equals(loginError)) { %>
                    <div class="server-alert server-alert-warning" role="alert">
                        <i class="fa-solid fa-lock" aria-hidden="true"></i>
                        <div><strong>Acceso temporalmente restringido</strong><p>Contacta al administrador del sistema para recibir asistencia.</p></div>
                    </div>
                <% } else if ("logout".equals(request.getParameter("estado"))) { %>
                    <div class="server-alert server-alert-success" role="status">
                        <i class="fa-solid fa-circle-check" aria-hidden="true"></i>
                        <div><strong>Sesión finalizada</strong><p>Has cerrado sesión correctamente.</p></div>
                    </div>
                <% } %>

                <form id="loginForm" method="post"
                      action="${pageContext.request.contextPath}/loginServlet">
                    <div class="field">
                        <div class="field-label-row">
                            <label for="txtUsuario">Usuario o correo electrónico <span>*</span></label>
                        </div>
                        <div class="input-wrap">
                            <i class="fa-regular fa-envelope input-icon" aria-hidden="true"></i>
                            <input type="text" id="txtUsuario" name="usuario"
                                   placeholder="Ingresa tu usuario institucional"
                                   autocomplete="username" maxlength="120" required>
                        </div>
                    </div>

                    <div class="field">
                        <div class="field-label-row">
                            <label for="txtPassword">Contraseña <span>*</span></label>
                        </div>
                        <div class="input-wrap">
                            <i class="fa-solid fa-lock input-icon" aria-hidden="true"></i>
                            <input type="password" id="txtPassword" name="password"
                                   placeholder="Ingresa tu contraseña"
                                   autocomplete="current-password" maxlength="128" required>
                            <button type="button" id="btnTogglePassword"
                                    class="toggle-password"
                                    aria-label="Mostrar contraseña"
                                    aria-pressed="false">
                                <i id="iconTogglePassword" class="fa-regular fa-eye" aria-hidden="true"></i>
                            </button>
                        </div>
                    </div>

                    <div class="form-meta">
                        <label class="remember-option">
                            <input type="checkbox" id="chkRecordarme" name="recordarme" value="true">
                            <span>Recordar usuario</span>
                        </label>
                    </div>

                    <button type="submit" id="btnSubmit" class="submit-button">
                        <span id="btnSubmitText">Iniciar sesión</span>
                        <i class="fa-solid fa-arrow-right-to-bracket" aria-hidden="true"></i>
                    </button>
                    <p class="form-feedback" id="formFeedback" aria-live="polite"></p>
                </form>

                <div class="security-note">
                    <i class="fa-solid fa-shield-halved" aria-hidden="true"></i>
                    <span>Acceso exclusivo para personal autorizado</span>
                </div>

                <footer class="form-footer">
                    <span>© <span id="currentYear"></span> OrigenNoble</span>
                    <span class="footer-dot">·</span>
                    <span>Sistema de gestión</span>
                </footer>
            </div>
        </section>
    </div>
</main>

<script src="${pageContext.request.contextPath}/JS/login.js" defer></script>
</body>
</html>
