
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="pe.edu.usil.origennoble.model.Proveedor"%>

<%
    if (session.getAttribute("usuarioId") == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }

    Proveedor proveedor =
        (Proveedor) request.getAttribute("proveedor");

    if (proveedor == null) {
        response.sendRedirect(
            request.getContextPath()
            + "/proveedoresServlet?error=noencontrado");
        return;
    }

    String error = request.getParameter("error");

    String razonSocial = proveedor.getRazonSocial() == null
        ? "" : proveedor.getRazonSocial();

    String ruc = proveedor.getRuc() == null
        ? "" : proveedor.getRuc();

    String telefono = proveedor.getTelefono() == null
        ? "" : proveedor.getTelefono();

    String direccion = proveedor.getDireccion() == null
        ? "" : proveedor.getDireccion();

    String correo = proveedor.getCorreo() == null
        ? "" : proveedor.getCorreo();
%>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Editar proveedor | OrigenNoble</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 30px;
            background: #f7f4ef;
            color: #3c3028;
            font-family: Arial, sans-serif;
        }

        .contenedor {
            max-width: 650px;
            margin: 25px auto;
        }

        .tarjeta {
            background: white;
            padding: 28px;
            border-radius: 12px;
            box-shadow: 0 3px 12px #0000000b;
        }

        h1 {
            margin-top: 0;
        }

        .subtitulo {
            color: #75675c;
            margin-bottom: 25px;
        }

        label {
            display: block;
            font-weight: bold;
            margin: 16px 0 7px;
        }

        input {
            width: 100%;
            padding: 11px;
            border: 1px solid #d8cec4;
            border-radius: 6px;
            font-size: 14px;
        }

        .botones {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 25px;
        }

        .boton {
            display: inline-block;
            border: none;
            border-radius: 6px;
            padding: 11px 15px;
            text-decoration: none;
            font-size: 14px;
            cursor: pointer;
        }

        .principal {
            background: #68452f;
            color: white;
        }

        .secundario {
            background: #eee5dc;
            color: #543b2a;
        }

        .aviso {
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 15px;
            background: #f8e6e1;
            color: #963f32;
        }

        @media (max-width: 600px) {
            body {
                padding: 15px;
            }
        }
    </style>
</head>

<body>
<div class="contenedor">
    <div class="tarjeta">

        <h1>Editar proveedor</h1>

        <p class="subtitulo">
            Modifica la información del proveedor registrado.
        </p>

        <% if ("datos".equals(error)) { %>
            <div class="aviso">
                Verifica los datos ingresados.
            </div>
        <% } else if ("duplicado".equals(error)) { %>
            <div class="aviso">
                El RUC ingresado pertenece a otro proveedor.
            </div>
        <% } else if ("general".equals(error)) { %>
            <div class="aviso">
                No se pudo actualizar el proveedor. Inténtalo nuevamente.
            </div>
        <% } %>

        <form action="<%=request.getContextPath()%>/actualizarProveedorServlet"
              method="post">

            <input type="hidden"
                   name="proveedorId"
                   value="<%=proveedor.getProveedorId()%>">

            <label for="razonSocial">Razón social *</label>
            <input type="text"
                   id="razonSocial"
                   name="razonSocial"
                   maxlength="150"
                   value="<%=razonSocial.replace("&", "&amp;")
                                        .replace("\"", "&quot;")
                                        .replace("<", "&lt;")
                                        .replace(">", "&gt;")%>"
                   required>

            <label for="ruc">RUC *</label>
            <input type="text"
                   id="ruc"
                   name="ruc"
                   maxlength="11"
                   minlength="11"
                   pattern="[0-9]{11}"
                   inputmode="numeric"
                   value="<%=ruc%>"
                   required>

            <label for="telefono">Teléfono</label>
            <input type="text"
                   id="telefono"
                   name="telefono"
                   maxlength="20"
                   value="<%=telefono.replace("&", "&amp;")
                                     .replace("\"", "&quot;")
                                     .replace("<", "&lt;")
                                     .replace(">", "&gt;")%>">

            <label for="direccion">Dirección</label>
            <input type="text"
                   id="direccion"
                   name="direccion"
                   maxlength="200"
                   value="<%=direccion.replace("&", "&amp;")
                                      .replace("\"", "&quot;")
                                      .replace("<", "&lt;")
                                      .replace(">", "&gt;")%>">

            <label for="correo">Correo electrónico</label>
            <input type="email"
                   id="correo"
                   name="correo"
                   maxlength="150"
                   value="<%=correo.replace("&", "&amp;")
                                   .replace("\"", "&quot;")
                                   .replace("<", "&lt;")
                                   .replace(">", "&gt;")%>">

            <div class="botones">
                <button type="submit" class="boton principal">
                    Guardar cambios
                </button>

                <a class="boton secundario"
                   href="<%=request.getContextPath()%>/proveedoresServlet">
                    Cancelar
                </a>
            </div>
        </form>

    </div>
</div>
</body>
</html>
