```jsp
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="pe.edu.usil.origennoble.model.Categoria"%>

<%
    if (session.getAttribute("usuarioId") == null) {
        response.sendRedirect(
            request.getContextPath() + "/login.jsp");
        return;
    }

    List<Categoria> categorias =
        (List<Categoria>) request.getAttribute("categorias");
%>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Categorías | OrigenNoble</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 30px;
            font-family: Arial, sans-serif;
            background: #f5f1e8;
            color: #3d2b1f;
        }

        .contenedor {
            max-width: 1100px;
            margin: auto;
        }

        .encabezado {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
            margin-bottom: 25px;
        }

        h1 {
            margin: 0 0 8px;
        }

        .panel {
            background: white;
            padding: 24px;
            margin-bottom: 25px;
            border-radius: 12px;
            box-shadow: 0 3px 12px #0000000d;
        }

        label {
            display: block;
            margin-bottom: 7px;
            font-weight: bold;
        }

        input, textarea {
            width: 100%;
            padding: 11px;
            margin-bottom: 16px;
            border: 1px solid #d4c8b8;
            border-radius: 6px;
            font: inherit;
        }

        button, .boton {
            display: inline-block;
            border: none;
            border-radius: 6px;
            padding: 10px 14px;
            background: #654321;
            color: white;
            text-decoration: none;
            cursor: pointer;
            font: inherit;
            font-size: 14px;
        }

        button:hover, .boton:hover {
            opacity: 0.88;
        }

        .mensaje {
            padding: 12px 15px;
            margin-bottom: 18px;
            border-radius: 6px;
            background: #edf6e9;
            color: #287443;
        }

        .error {
            background: #fdeaea;
            color: #a33;
        }

        .tabla-contenedor {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 13px;
            text-align: left;
            border-bottom: 1px solid #eee5d9;
            vertical-align: middle;
        }

        th {
            background: #f8f4ed;
        }

        .estado {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            background: #edf6e9;
            color: #287443;
        }

        .estado.inactivo {
            background: #fdeaea;
            color: #a33;
        }

        .volver {
            background: #8b7355;
        }

        .btn-desactivar {
            background: #a33;
        }

        .btn-activar {
            background: #287443;
        }

        .acciones {
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }

        .acciones form {
            margin: 0;
        }

        .acciones button {
            white-space: nowrap;
        }

        .vacio {
            text-align: center;
            padding: 25px;
            color: #806f5e;
        }

        @media (max-width: 600px) {
            body {
                padding: 15px;
            }

            .panel {
                padding: 16px;
            }
        }
    </style>
</head>

<body>

<div class="contenedor">

    <!-- ENCABEZADO -->
    <div class="encabezado">
        <div>
            <h1>Gestión de categorías</h1>
            <p>Organiza los productos de OrigenNoble.</p>
        </div>

        <a class="boton volver"
           href="<%= request.getContextPath() %>/dashboard.jsp">
            Volver al dashboard
        </a>
    </div>

    <!-- MENSAJES -->
    <% if ("registro".equals(request.getParameter("exito"))) { %>
        <div class="mensaje">
            Categoría registrada correctamente.
        </div>
    <% } %>

    <% if ("actualizacion".equals(request.getParameter("exito"))) { %>
        <div class="mensaje">
            Categoría actualizada correctamente.
        </div>
    <% } %>

    <% if ("estado".equals(request.getParameter("exito"))) { %>
        <div class="mensaje">
            El estado de la categoría se actualizó correctamente.
        </div>
    <% } %>

    <% if ("nombre".equals(request.getParameter("error"))) { %>
        <div class="mensaje error">
            Debes ingresar el nombre de la categoría.
        </div>
    <% } %>

    <% if ("registro".equals(request.getParameter("error"))) { %>
        <div class="mensaje error">
            No se pudo registrar la categoría.
            Verifica que el nombre no esté duplicado.
        </div>
    <% } %>

    <% if ("actualizacion".equals(request.getParameter("error"))) { %>
        <div class="mensaje error">
            No se pudo actualizar la categoría.
        </div>
    <% } %>

    <% if ("estado".equals(request.getParameter("error"))) { %>
        <div class="mensaje error">
            No se pudo cambiar el estado de la categoría.
        </div>
    <% } %>

    <% if ("datos".equals(request.getParameter("error"))) { %>
        <div class="mensaje error">
            Verifica los datos ingresados.
        </div>
    <% } %>

    <% if ("noEncontrada".equals(request.getParameter("error"))) { %>
        <div class="mensaje error">
            No se encontró la categoría solicitada.
        </div>
    <% } %>

    <!-- FORMULARIO DE REGISTRO -->
    <div class="panel">
        <h2>Nueva categoría</h2>

        <form method="post"
              action="<%= request.getContextPath() %>/categoriasServlet">

            <label for="nombre">Nombre *</label>

            <input type="text"
                   id="nombre"
                   name="nombre"
                   maxlength="100"
                   required>

            <label for="descripcion">Descripción</label>

            <textarea id="descripcion"
                      name="descripcion"
                      maxlength="250"
                      rows="3"></textarea>

            <button type="submit">
                Registrar categoría
            </button>
        </form>
    </div>

    <!-- TABLA DE CATEGORÍAS -->
    <div class="panel">

        <h2>Categorías registradas</h2>

        <div class="tabla-contenedor">
            <table>

                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Descripción</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>

                <tbody>

                <% if (categorias != null && !categorias.isEmpty()) {
                    for (Categoria c : categorias) { %>

                    <tr>
                        <td>
                            <%= c.getCategoriaId() %>
                        </td>

                        <td>
                            <%= c.getNombre() %>
                        </td>

                        <td>
                            <%= c.getDescripcion() == null
                                    ? "—" : c.getDescripcion() %>
                        </td>

                        <td>
                            <span class="estado <%= "inactivo".equals(c.getEstado())
                                    ? "inactivo" : "" %>">
                                <%= c.getEstado() %>
                            </span>
                        </td>

                        <td>
                            <div class="acciones">

                                <!-- EDITAR -->
                                <a class="boton"
                                   href="<%= request.getContextPath() %>/editarCategoriaServlet?id=<%= c.getCategoriaId() %>">
                                    Editar
                                </a>

                                <!-- ACTIVAR / DESACTIVAR -->
                                <form method="post"
                                      action="<%= request.getContextPath() %>/cambiarEstadoCategoriaServlet">

                                    <input type="hidden"
                                           name="categoriaId"
                                           value="<%= c.getCategoriaId() %>">

                                    <% if ("activo".equals(c.getEstado())) { %>

                                        <input type="hidden"
                                               name="estado"
                                               value="inactivo">

                                        <button type="submit"
                                                class="btn-desactivar">
                                            Desactivar
                                        </button>

                                    <% } else { %>

                                        <input type="hidden"
                                               name="estado"
                                               value="activo">

                                        <button type="submit"
                                                class="btn-activar">
                                            Activar
                                        </button>

                                    <% } %>

                                </form>
                            </div>
                        </td>
                    </tr>

                <%  }
                   } else { %>

                    <tr>
                        <td colspan="5" class="vacio">
                            No hay categorías registradas todavía.
                        </td>
                    </tr>

                <% } %>

                </tbody>
            </table>
        </div>
    </div>

</div>

</body>
</html>
```