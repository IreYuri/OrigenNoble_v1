
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="pe.edu.usil.origennoble.model.Proveedor"%>

<%
    if (session.getAttribute("usuarioId") == null) {
        response.sendRedirect(request.getContextPath() + "/index.jsp");
        return;
    }

    List<Proveedor> proveedores =
        (List<Proveedor>) request.getAttribute("proveedores");

    Proveedor proveedorEditar =
        (Proveedor) request.getAttribute("proveedorEditar");

    String busqueda = (String) request.getAttribute("busqueda");
    if (busqueda == null) busqueda = "";

    String mensaje = request.getParameter("mensaje");
    String error = request.getParameter("error");

    String busquedaHtml = busqueda.replace("&", "&amp;")
                                  .replace("\"", "&quot;")
                                  .replace("<", "&lt;")
                                  .replace(">", "&gt;");
%>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proveedores | OrigenNoble</title>

    <style>
        * { box-sizing: border-box; }

        body {
            margin: 0;
            padding: 30px;
            background: #f7f4ef;
            color: #3c3028;
            font-family: Arial, sans-serif;
        }

        .contenedor { max-width: 1200px; margin: auto; }

        .encabezado {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
            flex-wrap: wrap;
            margin-bottom: 24px;
        }

        h1 { margin-bottom: 6px; }
        .subtitulo { color: #75675c; }

        .boton {
            display: inline-block;
            border: none;
            border-radius: 6px;
            padding: 10px 14px;
            text-decoration: none;
            font-size: 14px;
            cursor: pointer;
        }

        .principal { background: #68452f; color: white; }
        .secundario { background: #eee5dc; color: #543b2a; }
        .activar { background: #e5f2e4; color: #32633a; }
        .desactivar { background: #f8e6e1; color: #963f32; }

        .tarjeta {
            background: white;
            border-radius: 12px;
            padding: 22px;
            margin-bottom: 20px;
            box-shadow: 0 3px 12px #0000000b;
        }

        .busqueda, .formulario {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        input[type="text"], input[type="email"] {
            width: 100%;
            padding: 11px;
            border: 1px solid #d8cec4;
            border-radius: 6px;
            font: inherit;
        }

        .busqueda input[type="text"] {
            flex: 1;
            min-width: 220px;
        }

        .campo {
            flex: 1 1 280px;
            display: flex;
            flex-direction: column;
            gap: 6px;
        }

        .tabla-contenedor { overflow-x: auto; }

        table {
            width: 100%;
            border-collapse: collapse;
            white-space: nowrap;
        }

        th, td {
            padding: 13px 10px;
            border-bottom: 1px solid #eee7e0;
            text-align: left;
        }

        th { background: #f5f0e9; }

        .acciones {
            display: flex;
            gap: 8px;
            align-items: center;
        }

        .acciones form { margin: 0; }

        .estado { font-weight: bold; }
        .activo { color: #28743a; }
        .inactivo { color: #a33b30; }

        .aviso {
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 18px;
            background: #e5f2e4;
            color: #32633a;
        }

        .error { background: #f8e6e1; color: #963f32; }
        .vacio { text-align: center; padding: 28px; color: #75675c; }

        @media (max-width: 600px) {
            body { padding: 15px; }
        }
    </style>
</head>

<body>
<div class="contenedor">

    <div class="encabezado">
        <div>
            <h1>Proveedores</h1>
            <div class="subtitulo">
                Administra los proveedores de OrigenNoble.
            </div>
        </div>

        <a class="boton principal"
           href="<%=request.getContextPath()%>/registroProveedor.jsp">
            + Registrar proveedor
        </a>
    </div>

    <% if ("registrado".equals(mensaje)) { %>
        <div class="aviso">Proveedor registrado correctamente.</div>
    <% } else if ("actualizado".equals(mensaje)) { %>
        <div class="aviso">Proveedor actualizado correctamente.</div>
    <% } else if ("estadoActualizado".equals(mensaje)
               || "estado".equals(mensaje)) { %>
        <div class="aviso">Estado del proveedor actualizado correctamente.</div>
    <% } else if ("sinCambios".equals(mensaje)) { %>
        <div class="aviso">No se realizaron cambios en el proveedor.</div>
    <% } %>

    <% if ("duplicado".equals(error)) { %>
        <div class="aviso error">El RUC ingresado ya está registrado.</div>
    <% } else if ("datos".equals(error)
               || "datosInvalidos".equals(error)) { %>
        <div class="aviso error">Verifica los datos ingresados.</div>
    <% } else if ("noencontrado".equals(error)
               || "noEncontrado".equals(error)) { %>
        <div class="aviso error">No se encontró el proveedor solicitado.</div>
    <% } else if ("idInvalido".equals(error)
               || "accionInvalida".equals(error)) { %>
        <div class="aviso error">La operación solicitada no es válida.</div>
    <% } else if ("general".equals(error)) { %>
        <div class="aviso error">
            Ocurrió un error. Revisa los datos y vuelve a intentarlo.
        </div>
    <% } %>

    <% if (proveedorEditar != null) { %>
    <div class="tarjeta">
        <h2>Editar proveedor #<%=proveedorEditar.getProveedorId()%></h2>

        <form class="formulario"
              action="<%=request.getContextPath()%>/proveedoresServlet"
              method="post">

            <input type="hidden" name="accion" value="actualizarProveedor">
            <input type="hidden" name="proveedorId"
                   value="<%=proveedorEditar.getProveedorId()%>">

            <div class="campo">
                <label for="razonSocial">Razón social *</label>
                <input type="text" id="razonSocial" name="razonSocial"
                       maxlength="150" required
                       value="<%=escapar(proveedorEditar.getRazonSocial())%>">
            </div>

            <div class="campo">
                <label for="ruc">RUC *</label>
                <input type="text" id="ruc" name="ruc"
                       maxlength="20" required
                       value="<%=escapar(proveedorEditar.getRuc())%>">
            </div>

            <div class="campo">
                <label for="telefono">Teléfono</label>
                <input type="text" id="telefono" name="telefono"
                       maxlength="30"
                       value="<%=escapar(proveedorEditar.getTelefono())%>">
            </div>

            <div class="campo">
                <label for="direccion">Dirección</label>
                <input type="text" id="direccion" name="direccion"
                       maxlength="250"
                       value="<%=escapar(proveedorEditar.getDireccion())%>">
            </div>

            <div class="campo">
                <label for="correo">Correo</label>
                <input type="email" id="correo" name="correo"
                       maxlength="150"
                       value="<%=escapar(proveedorEditar.getCorreo())%>">
            </div>

            <div style="width:100%; display:flex; gap:10px; flex-wrap:wrap;">
                <button class="boton principal" type="submit">
                    Guardar cambios
                </button>
                <a class="boton secundario"
                   href="<%=request.getContextPath()%>/proveedoresServlet">
                    Cancelar
                </a>
            </div>
        </form>
    </div>
    <% } %>

    <div class="tarjeta">
        <form class="busqueda"
              action="<%=request.getContextPath()%>/proveedoresServlet"
              method="get">

            <input type="text" name="busqueda"
                   placeholder="Buscar por razón social o RUC"
                   value="<%=busquedaHtml%>">

            <button class="boton principal" type="submit">Buscar</button>

            <a class="boton secundario"
               href="<%=request.getContextPath()%>/proveedoresServlet">
                Limpiar
            </a>
        </form>

        <div class="tabla-contenedor">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Razón social</th>
                        <th>RUC</th>
                        <th>Teléfono</th>
                        <th>Dirección</th>
                        <th>Correo</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                <% if (proveedores != null && !proveedores.isEmpty()) {
                    for (Proveedor p : proveedores) { %>
                    <tr>
                        <td><%=p.getProveedorId()%></td>
                        <td><%=escapar(p.getRazonSocial())%></td>
                        <td><%=escapar(p.getRuc())%></td>
                        <td><%=p.getTelefono() == null || p.getTelefono().isBlank()
                                ? "-" : escapar(p.getTelefono())%></td>
                        <td><%=p.getDireccion() == null || p.getDireccion().isBlank()
                                ? "-" : escapar(p.getDireccion())%></td>
                        <td><%=p.getCorreo() == null || p.getCorreo().isBlank()
                                ? "-" : escapar(p.getCorreo())%></td>
                        <td>
                            <span class="estado <%=p.getEstado()%>">
                                <%=escapar(p.getEstado())%>
                            </span>
                        </td>
                        <td>
                            <div class="acciones">
                                <a class="boton secundario"
                                   href="<%=request.getContextPath()%>/proveedoresServlet?editar=<%=p.getProveedorId()%>">
                                    Editar
                                </a>

                                <form
                                    action="<%=request.getContextPath()%>/proveedoresServlet"
                                    method="post"
                                    onsubmit="return confirm('¿Deseas cambiar el estado de este proveedor?');">

                                    <input type="hidden" name="accion"
                                           value="cambiarEstado">
                                    <input type="hidden" name="proveedorId"
                                           value="<%=p.getProveedorId()%>">

                                    <% if ("activo".equals(p.getEstado())) { %>
                                        <input type="hidden" name="nuevoEstado"
                                               value="inactivo">
                                        <button class="boton desactivar" type="submit">
                                            Desactivar
                                        </button>
                                    <% } else { %>
                                        <input type="hidden" name="nuevoEstado"
                                               value="activo">
                                        <button class="boton activar" type="submit">
                                            Activar
                                        </button>
                                    <% } %>
                                </form>
                            </div>
                        </td>
                    </tr>
                <%  }
                   } else { %>
                    <tr>
                        <td colspan="8" class="vacio">
                            No hay proveedores registrados.
                        </td>
                    </tr>
                <% } %>
                </tbody>
            </table>
        </div>
    </div>

    <p>
        <a href="<%=request.getContextPath()%>/dashboard.jsp">
            Volver al panel principal
        </a>
    </p>

</div>
</body>
</html>

<%!
    private String escapar(String valor) {
        if (valor == null) return "";
        return valor.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }
%>
