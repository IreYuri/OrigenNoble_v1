<%-- 
    Document   : editarUsuario
    Created on : 26 oct. 2026, 03:09:26
    Author     : snay-
--%>


<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.Map"%>
<%@page import="java.util.List"%>
<%
    if (session.getAttribute("usuarioId") == null) {
        response.sendRedirect(request.getContextPath() + "/index.jsp");
        return;
    }

    Map<String, Object> usuario =
        (Map<String, Object>) request.getAttribute("usuario");

    List<Map<String, Object>> roles =
        (List<Map<String, Object>>) request.getAttribute("roles");

    if (usuario == null || roles == null) {
        response.sendRedirect(
            request.getContextPath() + "/usuariosServlet");
        return;
    }

    String id = String.valueOf(usuario.get("id"));
    String nombre = String.valueOf(usuario.get("nombre"));
    String email = String.valueOf(usuario.get("email"));
    int rolActual = (Integer) usuario.get("rolId");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Editar usuario | OrigenNoble</title>
    <style>
        * { box-sizing: border-box; }

        body {
            margin: 0;
            padding: 30px 18px;
            background: #f7f5ef;
            color: #34271f;
            font-family: Arial, sans-serif;
        }

        .contenedor {
            max-width: 620px;
            margin: 35px auto;
        }

        .panel {
            background: white;
            padding: 30px;
            border-radius: 14px;
            box-shadow: 0 4px 18px #34271f0d;
        }

        h1 { margin-top: 0; }

        .subtitulo {
            color: #777;
            line-height: 1.5;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin: 17px 0 7px;
            font-size: 14px;
            font-weight: bold;
        }

        input, select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd6ca;
            border-radius: 8px;
            font-size: 15px;
            background: white;
            color: #34271f;
        }

        .acciones {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 25px;
        }

        .boton {
            display: inline-block;
            border: none;
            border-radius: 8px;
            padding: 12px 17px;
            background: #78805a;
            color: white;
            text-decoration: none;
            cursor: pointer;
            font-size: 14px;
        }

        .secundario { background: #34271f; }

        .aviso {
            padding: 12px;
            margin: 15px 0;
            border-radius: 8px;
            background: #f8e9e5;
            color: #944b3c;
        }
    </style>
</head>
<body>
<div class="contenedor">
    <main class="panel">
        <h1>Editar usuario</h1>
        <p class="subtitulo">
            Modifica los datos y el rol de la cuenta seleccionada.
        </p>

        <% if ("datos".equals(request.getParameter("error"))) { %>
            <div class="aviso">
                Revisa los datos ingresados e inténtalo nuevamente.
            </div>
        <% } %>

        <form method="post"
              action="<%= request.getContextPath() %>/editarUsuarioServlet">

            <input type="hidden" name="id" value="<%= id %>">

            <label for="nombreUsuario">Nombre de usuario</label>
            <input type="text"
                   id="nombreUsuario"
                   name="nombreUsuario"
                   maxlength="100"
                   value="<%= nombre %>"
                   required>

            <label for="email">Correo electrónico</label>
            <input type="email"
                   id="email"
                   name="email"
                   maxlength="254"
                   value="<%= email %>"
                   required>

            <label for="rolId">Rol</label>
            <select id="rolId" name="rolId" required>
                <% for (Map<String, Object> rol : roles) {
                    int idRol = (Integer) rol.get("id");
                    String nombreRol = String.valueOf(rol.get("nombre"));
                %>
                    <option value="<%= idRol %>"
                        <%= idRol == rolActual ? "selected" : "" %>>
                        <%= nombreRol %>
                    </option>
                <% } %>
            </select>

            <div class="acciones">
                <button class="boton" type="submit">
                    Guardar cambios
                </button>

                <a class="boton secundario"
                   href="<%= request.getContextPath() %>/usuariosServlet">
                    Cancelar
                </a>
            </div>
        </form>
    </main>
</div>
</body>
</html>

