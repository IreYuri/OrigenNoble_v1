
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="pe.edu.usil.origennoble.model.Categoria"%>

<%
    if (session.getAttribute("usuarioId") == null) {
        response.sendRedirect(
            request.getContextPath() + "/login.jsp");
        return;
    }

    Categoria categoria =
        (Categoria) request.getAttribute("categoria");

    if (categoria == null) {
        response.sendRedirect(
            request.getContextPath() + "/categoriasServlet");
        return;
    }
%>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar categoría | OrigenNoble</title>

    <style>
        * { box-sizing: border-box; }

        body {
            margin: 0;
            padding: 30px;
            background: #f5f1e8;
            color: #3d2b1f;
            font-family: Arial, sans-serif;
        }

        .panel {
            max-width: 600px;
            margin: 30px auto;
            padding: 28px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 3px 12px #0000000d;
        }

        label {
            display: block;
            margin: 18px 0 7px;
            font-weight: bold;
        }

        input, textarea {
            width: 100%;
            padding: 11px;
            border: 1px solid #d4c8b8;
            border-radius: 6px;
            font: inherit;
        }

        button, .boton {
            display: inline-block;
            margin-top: 20px;
            padding: 11px 16px;
            border: none;
            border-radius: 6px;
            background: #654321;
            color: white;
            text-decoration: none;
            cursor: pointer;
            font: inherit;
        }

        .secundario { background: #8b7355; }
    </style>
</head>

<body>
    <div class="panel">
        <h1>Editar categoría</h1>
        <p>Modifica la información de la categoría seleccionada.</p>

        <form method="post"
              action="<%= request.getContextPath() %>/actualizarCategoriaServlet">

            <input type="hidden" name="categoriaId"
                   value="<%= categoria.getCategoriaId() %>">

            <label for="nombre">Nombre *</label>
            <input type="text" id="nombre" name="nombre"
                   maxlength="100" required
                   value="<%= categoria.getNombre() %>">

            <label for="descripcion">Descripción</label>
            <textarea id="descripcion" name="descripcion"
                      maxlength="250" rows="4"><%= categoria.getDescripcion() == null
                      ? "" : categoria.getDescripcion() %></textarea>

            <button type="submit">Guardar cambios</button>

            <a class="boton secundario"
               href="<%= request.getContextPath() %>/categoriasServlet">
                Cancelar
            </a>
        </form>
    </div>
</body>
</html>
