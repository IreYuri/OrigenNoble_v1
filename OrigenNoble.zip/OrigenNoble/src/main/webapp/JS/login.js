/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */


document.addEventListener("DOMContentLoaded", () => {
    const year = document.getElementById("currentYear");
    const password = document.getElementById("txtPassword");
    const toggle = document.getElementById("btnTogglePassword");
    const icon = document.getElementById("iconTogglePassword");
    const form = document.getElementById("loginForm");

    if (year) year.textContent = new Date().getFullYear();

    if (password && toggle && icon) {
        toggle.addEventListener("click", () => {
            const reveal = password.type === "password";
            password.type = reveal ? "text" : "password";
            icon.classList.toggle("fa-eye", !reveal);
            icon.classList.toggle("fa-eye-slash", reveal);
            toggle.setAttribute("aria-label", reveal ? "Ocultar contraseña" : "Mostrar contraseña");
            toggle.setAttribute("aria-pressed", String(reveal));
        });
    }

    // No se simula la autenticación: el formulario se envía al servlet.
    // Validación básica del navegador; el servidor debe validar de nuevo.
    if (form) {
        form.addEventListener("submit", (event) => {
            const user = document.getElementById("txtUsuario");
            const feedback = document.getElementById("formFeedback");
            if (!user.value.trim() || !password.value) {
                event.preventDefault();
                if (feedback) feedback.textContent = "Completa tu usuario y contraseña para continuar.";
                if (!user.value.trim()) user.focus();
                else password.focus();
            } else if (feedback) {
                feedback.textContent = "";
            }
        });
    }
});
