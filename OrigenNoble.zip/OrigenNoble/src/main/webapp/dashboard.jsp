
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%
    if (session.getAttribute("usuarioId") == null) {
        response.sendRedirect(request.getContextPath() + "/index.jsp");
        return;
    }

    String nombreUsuario = (String) session.getAttribute("nombreUsuario");
    if (nombreUsuario == null || nombreUsuario.isBlank()) {
        nombreUsuario = "Usuario";
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel principal | OrigenNoble</title>
    <link rel="stylesheet"
          href="${pageContext.request.contextPath}/CSS/dashboard.css">
</head>
<body>
<div class="dashboard">

    <aside class="sidebar">
        <a class="brand" href="${pageContext.request.contextPath}/dashboard.jsp">
            <span class="brand-mark">
                <img src="${pageContext.request.contextPath}/images/logo.png"
                     alt="Logotipo de OrigenNoble">
            </span>
            <span class="brand-name">
                <strong>ORIGENNOBLE</strong>
                <small>DESDE 2026</small>
            </span>
        </a>

        <div class="menu-label">MENÚ PRINCIPAL</div>

        <nav class="menu">
            <a class="menu-item active"
               href="${pageContext.request.contextPath}/dashboard.jsp">
                <span class="menu-icon">⌂</span>
                <span>Inicio</span>
            </a>

            <a class="menu-item"
               href="${pageContext.request.contextPath}/usuariosServlet">
                <span class="menu-icon">♙</span>
                <span>Usuarios</span>
            </a>

            <a class="menu-item"
               href="${pageContext.request.contextPath}/clientesServlet">
                <span class="menu-icon">♧</span>
                <span>Clientes</span>
            </a>

            
            <a class="menu-item"
               href="${pageContext.request.contextPath}/proveedoresServlet">
                <span class="menu-icon">▤</span>
                <span>Proveedores</span>
            </a>



            <a class="menu-item"
               href="${pageContext.request.contextPath}/productosServlet">
                <span class="menu-icon">▦</span>
                <span>Inventario</span>
            </a>


            
            <a class="menu-item"
               href="${pageContext.request.contextPath}/ventasServlet">
                <span class="menu-icon">↗</span>
                <span>Ventas</span>
            </a>


            
            <a href="${pageContext.request.contextPath}/solpedServlet">
                ▣ Solicitudes SOLPED
            </a>

        </nav>

        <div class="sidebar-bottom">
            <div class="coffee-note">
                <span class="coffee-symbol">☕</span>
                <p>De nuestro origen<br>hasta tu taza.</p>
                <small>Calidad en cada detalle.</small>
            </div>

            <form action="${pageContext.request.contextPath}/logoutServlet"
                  method="post">
                <button type="submit" class="logout-button">
                    <span class="menu-icon">↪</span>
                    Cerrar sesión
                </button>
            </form>
        </div>
    </aside>

    <main class="main-content">
        <header class="topbar">
            <div>
                <span class="eyebrow">PANEL DE ADMINISTRACIÓN</span>
                <p class="topbar-subtitle">
                    Gestiona tu negocio desde un solo lugar.
                </p>
            </div>

            <div class="user-profile">
                <div class="avatar">
                    <%= nombreUsuario.substring(0, 1).toUpperCase() %>
                </div>
                <div class="user-info">
                    <strong><%= nombreUsuario %></strong>
                    <span>Sesión activa</span>
                </div>
            </div>
        </header>

        <section class="welcome-section">
            <div class="welcome-copy">
                <span class="welcome-tag">BIENVENIDO A ORIGENNOBLE</span>
                <h1>Hola, <%= nombreUsuario %> <span>☕</span></h1>
                <p>
                    Cada gran café comienza con una buena gestión.
                    Este es el espacio para organizar tus operaciones.
                </p>
            </div>

            <div class="welcome-decoration" aria-hidden="true">
                <span class="decor-circle circle-one"></span>
                <span class="decor-circle circle-two"></span>
                <span class="decor-bean">✦</span>
            </div>
        </section>

        <section class="section-heading">
            <div>
                <h2>Resumen general</h2>
                <p>Indicadores de tu negocio</p>
            </div>
            <span class="status-pill">
                <span class="status-dot"></span>
                Sesión activa
            </span>
        </section>

        <section class="stats-grid">
            <article class="stat-card">
                <div class="stat-top">
                    <span class="stat-icon icon-olive">♧</span>
                    <span class="stat-caption">GESTIÓN</span>
                </div>
                <p class="stat-title">Clientes</p>
                <div class="stat-bottom">
                    <strong>—</strong>
                    <span class="stat-description">Por registrar</span>
                </div>
            </article>

            <article class="stat-card">
                <div class="stat-top">
                    <span class="stat-icon icon-cream">▦</span>
                    <span class="stat-caption">CATÁLOGO</span>
                </div>
                <p class="stat-title">Productos</p>
                <div class="stat-bottom">
                    <strong>—</strong>
                    <span class="stat-description">Por registrar</span>
                </div>
            </article>

            <article class="stat-card">
                <div class="stat-top">
                    <span class="stat-icon icon-green">↗</span>
                    <span class="stat-caption">COMERCIAL</span>
                </div>
                <p class="stat-title">Ventas</p>
                <div class="stat-bottom">
                    <strong>—</strong>
                    <span class="stat-description">Por registrar</span>
                </div>
            </article>

            <article class="stat-card">
                <div class="stat-top">
                    <span class="stat-icon icon-brown">▤</span>
                    <span class="stat-caption">ABASTECIMIENTO</span>
                </div>
                <p class="stat-title">Insumos</p>
                <div class="stat-bottom">
                    <strong>—</strong>
                    <span class="stat-description">Por registrar</span>
                </div>
            </article>
        </section>

        <section class="content-grid">
            <article class="panel quick-panel">
                <div class="panel-heading">
                    <div>
                        <h2>Accesos rápidos</h2>
                        <p>Encuentra las áreas principales</p>
                    </div>
                    <span class="panel-heading-icon">✳</span>
                </div>

                <div class="quick-links">
                    <a href="${pageContext.request.contextPath}/usuariosServlet"
                       class="quick-link">
                        <span class="quick-icon">♙</span>
                        <span>
                            <strong>Usuarios</strong>
                            <small>Administración de cuentas</small>
                        </span>
                        <span class="quick-arrow">→</span>
                    </a>

                    <a href="${pageContext.request.contextPath}/clientesServlet"
                       class="quick-link">
                        <span class="quick-icon">♧</span>
                        <span>
                            <strong>Clientes</strong>
                            <small>Registrar y administrar clientes</small>
                        </span>
                        <span class="quick-arrow">→</span>
                    </a>

                    
                    <a href="${pageContext.request.contextPath}/productosServlet"
                       class="quick-link">
                        <span class="quick-icon">▦</span>
                        <span>
                            <strong>Inventario</strong>
                            <small>Gestionar productos y existencias</small>
                        </span>
                        <span class="quick-arrow">→</span>
                    </a>


                    
                    <a href="${pageContext.request.contextPath}/proveedoresServlet"
                       class="quick-link">
                        <span class="quick-icon">▤</span>
                        <span>
                            <strong>Proveedores</strong>
                            <small>Registrar y administrar proveedores</small>
                        </span>
                        <span class="quick-arrow">→</span>
                    </a>


         
                    <a href="${pageContext.request.contextPath}/ventasServlet"
                       class="quick-link">
                        <span class="quick-icon">↗</span>
                        <span>
                            <strong>Ventas</strong>
                            <small>Registrar y consultar ventas</small>
                        </span>
                        <span class="quick-arrow">→</span>
                    </a>


                    <a href="${pageContext.request.contextPath}/solpedServlet"
                       class="quick-link">
                        <span class="quick-icon">▣</span>
                        <span>
                            <strong>Solicitudes SOLPED</strong>
                            <small>Registrar y consultar solicitudes</small>
                        </span>
                        <span class="quick-arrow">→</span>
                    </a>
            </article>

            <article class="panel activity-panel">
                <div class="panel-heading">
                    <div>
                        <h2>Actividad reciente</h2>
                        <p>Seguimiento de operaciones</p>
                    </div>
                    <span class="activity-icon">◷</span>
                </div>

                <div class="empty-state">
                    <span class="empty-icon">☕</span>
                    <strong>Tu actividad aparecerá aquí</strong>
                    <p>
                        Cuando implementemos los módulos, podrás
                        consultar las operaciones recientes.
                    </p>
                </div>
            </article>
        </section>

        <footer class="footer">
            <span>© OrigenNoble · Gestión de café de especialidad</span>
            <span>Calidad desde el origen.</span>
        </footer>
    </main>
</div>
</body>
</html>
