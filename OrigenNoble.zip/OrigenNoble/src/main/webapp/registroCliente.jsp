<%-- 
    Document   : registroCliente
    Created on : 26 oct. 2026, 05:05:23
    Author     : snay-
--%>


<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%!
    private String escaparHTML(String texto) {
        if (texto == null) return "";
        return texto.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }
%>
<%
    if (session.getAttribute("usuarioId") == null) {
        response.sendRedirect(request.getContextPath() + "/index.jsp");
        return;
    }

    String error = request.getParameter("error");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar cliente | OrigenNoble</title>

    <style>
        :root {
            --verde: #344b36;
            --verde-hover: #263a29;
            --crema: #f7f3e9;
            --fondo: #f4f1e9;
            --marron: #6b4b35;
            --texto: #302d27;
            --borde: #ded8ca;
            --blanco: #ffffff;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 32px 18px;
            background: var(--fondo);
            color: var(--texto);
            font-family: Arial, Helvetica, sans-serif;
        }

        .contenedor {
            width: 100%;
            max-width: 900px;
            margin: 0 auto;
        }

        .encabezado {
            margin-bottom: 24px;
        }

        .marca {
            color: var(--verde);
            font-size: 13px;
            font-weight: bold;
            letter-spacing: 2px;
        }

        h1 {
            margin: 12px 0 8px;
            font-size: clamp(27px, 4vw, 36px);
        }

        .descripcion {
            margin: 0;
            color: #706a5e;
            line-height: 1.6;
        }

        .tarjeta {
            padding: 30px;
            background: var(--blanco);
            border: 1px solid #e8e2d7;
            border-radius: 16px;
            box-shadow: 0 8px 25px rgba(52, 75, 54, 0.06);
        }

        .seccion-titulo {
            margin: 0 0 20px;
            color: var(--verde);
            font-size: 18px;
        }

        .formulario {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 19px;
        }

        .campo {
            display: flex;
            flex-direction: column;
            gap: 8px;
            min-width: 0;
        }

        .completo {
            grid-column: 1 / -1;
        }

        label {
            font-size: 13px;
            font-weight: bold;
        }

        input, select, textarea {
            width: 100%;
            padding: 12px 13px;
            border: 1px solid var(--borde);
            border-radius: 8px;
            background: #fffefa;
            color: var(--texto);
            font: inherit;
            font-size: 14px;
        }

        input:focus, select:focus, textarea:focus {
            outline: 2px solid #a7b69d;
            border-color: var(--verde);
        }

        textarea {
            min-height: 85px;
            resize: vertical;
        }

        .ayuda {
            color: #777064;
            font-size: 12px;
            line-height: 1.5;
        }

        .alerta {
            margin-bottom: 22px;
            padding: 13px 15px;
            border-radius: 8px;
            font-size: 14px;
            line-height: 1.5;
        }

        .alerta-error {
            color: #8a2929;
            background: #fff0ee;
            border: 1px solid #efc7c2;
        }

        .acciones {
            display: flex;
            flex-wrap: wrap;
            justify-content: flex-end;
            gap: 12px;
            margin-top: 28px;
        }

        .boton {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 43px;
            padding: 11px 19px;
            border: 0;
            border-radius: 8px;
            font-size: 14px;
            font-weight: bold;
            text-decoration: none;
            cursor: pointer;
        }

        .boton-secundario {
            color: var(--verde);
            background: var(--crema);
        }

        .boton-principal {
            color: white;
            background: var(--verde);
        }

        .boton-principal:hover {
            background: var(--verde-hover);
        }

        @media (max-width: 600px) {
            body {
                padding: 20px 12px;
            }

            .tarjeta {
                padding: 20px 16px;
            }

            .formulario {
                grid-template-columns: 1fr;
            }

            .completo {
                grid-column: auto;
            }

            .acciones {
                flex-direction: column-reverse;
            }

            .boton {
                width: 100%;
            }
        }
    </style>
</head>

<body>
<div class="contenedor">

    <header class="encabezado">
        <div class="marca">ORIGENNOBLE · GESTIÓN DE CLIENTES</div>
        <h1>Registrar cliente</h1>
        <p class="descripcion">
            Registra los datos de una persona o empresa para mantener
            organizada la información comercial.
        </p>
    </header>

    <main class="tarjeta">

        <% if ("duplicado".equals(error)) { %>
            <div class="alerta alerta-error">
                Ya existe un cliente con ese número de documento.
                Verifica los datos e inténtalo nuevamente.
            </div>
        <% } else if ("datos".equals(error)) { %>
            <div class="alerta alerta-error">
                Algunos datos no son válidos o superan la longitud permitida.
                Revisa el formulario e inténtalo nuevamente.
            </div>
        <% } else if ("general".equals(error)) { %>
            <div class="alerta alerta-error">
                No se pudo registrar el cliente por un error interno.
                Inténtalo nuevamente.
            </div>
        <% } %>

        <h2 class="seccion-titulo">Información del cliente</h2>

        <form action="<%= request.getContextPath() %>/registroClienteServlet"
              method="post">

            <div class="formulario">

                <div class="campo">
                    <label for="tipoDocumento">Tipo de documento</label>
                    <select id="tipoDocumento" name="tipoDocumento">
                        <option value="">Seleccionar...</option>
                        <option value="DNI">DNI</option>
                        <option value="RUC">RUC</option>
                        <option value="CE">Carné de extranjería</option>
                        <option value="OTRO">Otro</option>
                    </select>
                </div>

                <div class="campo">
                    <label for="numeroDocumento">Número de documento</label>
                    <input type="text" id="numeroDocumento"
                           name="numeroDocumento" maxlength="20"
                           autocomplete="off">
                    <span class="ayuda">
                        Si ingresas un número, selecciona también su tipo.
                    </span>
                </div>

                <div class="campo">
                    <label for="nombres">Nombres</label>
                    <input type="text" id="nombres" name="nombres"
                           maxlength="100" autocomplete="given-name">
                </div>

                <div class="campo">
                    <label for="apellidos">Apellidos</label>
                    <input type="text" id="apellidos" name="apellidos"
                           maxlength="100" autocomplete="family-name">
                </div>

                <div class="campo completo">
                    <label for="razonSocial">Razón social</label>
                    <input type="text" id="razonSocial" name="razonSocial"
                           maxlength="150" autocomplete="organization">
                    <span class="ayuda">
                        Para una empresa, ingresa su razón social.
                        Registra nombres y apellidos para una persona.
                    </span>
                </div>

                <div class="campo">
                    <label for="telefono">Teléfono</label>
                    <input type="tel" id="telefono" name="telefono"
                           maxlength="20" autocomplete="tel">
                </div>

                <div class="campo">
                    <label for="email">Correo electrónico</label>
                    <input type="email" id="email" name="email"
                           maxlength="150" autocomplete="email">
                </div>

                <div class="campo completo">
                    <label for="direccion">Dirección</label>
                    <textarea id="direccion" name="direccion"
                              maxlength="200"
                              autocomplete="street-address"></textarea>
                </div>

            </div>

            <div class="acciones">
                <a class="boton boton-secundario"
                   href="<%= request.getContextPath() %>/clientesServlet">
                    Cancelar
                </a>

                <button type="submit" class="boton boton-principal">
                    Guardar cliente
                </button>
            </div>

        </form>
    </main>
</div>
</body>
</html>
